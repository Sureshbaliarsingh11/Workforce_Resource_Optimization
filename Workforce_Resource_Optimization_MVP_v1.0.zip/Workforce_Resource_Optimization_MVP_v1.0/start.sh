#!/usr/bin/env bash
# One-command startup: sets up and runs both backend and frontend locally.
# No cloud services, no external databases - everything runs on this machine.
set -e

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

echo "== Workforce Optimizer - local startup =="

echo "[1/5] Setting up Python virtual environment..."
cd "$ROOT_DIR/backend"
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi
source venv/bin/activate

echo "[2/5] Installing backend dependencies..."
pip install -q -r requirements.txt

echo "[3/5] Installing frontend dependencies..."
cd "$ROOT_DIR/frontend"
if [ ! -d "node_modules" ]; then
  npm install --silent
fi

echo "[4/5] Starting backend (http://localhost:8877)..."
cd "$ROOT_DIR/backend"
source venv/bin/activate
nohup uvicorn app.main:app --host 0.0.0.0 --port 8877 > "$ROOT_DIR/backend.log" 2>&1 &
echo $! > "$ROOT_DIR/.backend.pid"
sleep 2

echo "[5/5] Starting frontend (http://localhost:5173)..."
cd "$ROOT_DIR/frontend"
nohup npm run dev -- --port 5173 --host 0.0.0.0 > "$ROOT_DIR/frontend.log" 2>&1 &
echo $! > "$ROOT_DIR/.frontend.pid"
sleep 2

echo ""
echo "Backend:  http://localhost:8877  (docs at /docs)"
echo "Frontend: http://localhost:5173"
echo ""
echo "Open the frontend, click 'Generate sample data' on the Dashboard, then explore Forecast and Workforce."
echo "Logs: backend.log, frontend.log"
echo "To stop: ./stop.sh"
