# Architecture

## Overview

A self-contained, locally-run web application. No component talks to the
internet during normal use, and no external service of any kind is
required.

```
┌─────────────────────┐         ┌──────────────────────────┐
│  Frontend (React)   │  HTTP   │   Backend (FastAPI)      │
│  localhost:5173     │ ──────► │   localhost:8877         │
│                      │ ◄────── │                          │
│  Display, filtering, │  JSON   │  All business logic:      │
│  interaction only    │         │  forecasting, requirement,│
└─────────────────────┘         │  optimization, scenarios, │
                                  │  dashboard, import/export │
                                  └────────────┬─────────────┘
                                               │
                                               ▼
                                  ┌──────────────────────────┐
                                  │  SQLite                  │
                                  │  backend/data/workforce.db│
                                  │  (single local file)      │
                                  └──────────────────────────┘
```

## Design principle: single source of truth per calculation

Every business calculation exists in exactly one place in the backend. The
frontend never recomputes a business number — it only displays what the
backend returns. Later phases reuse earlier phases' calculations rather
than duplicating them (e.g. the executive dashboard's coverage numbers are
the same coverage array the optimizer already computed, not a
recalculation).

## Data flow (the core pipeline)

```
Historical Demand (generated or imported)
        │
        ▼
Demand Forecasting  ── 3 models backtested, best one selected by WAPE
        │
        ▼
Workforce Requirement  ── forecast → required headcount, via productivity + shrinkage
        │
        ▼
Optimization (Google OR-Tools CP-SAT)  ── required headcount → actual employee schedule
        │
        ▼
Manager Schedule Editing  ── validated manual edits on top of the solver's output
        │
        ▼
What-If Scenarios  ── perturbs inputs, re-runs the real requirement + solver, never mutates the live schedule
        │
        ▼
Executive Dashboard  ── aggregates all of the above; computes nothing new itself
```

## Backend structure

```
backend/
  app/
    main.py              FastAPI app and all API routes
    database.py            SQLAlchemy engine/session setup (SQLite)
    models.py                ORM models — the full database schema
    schemas.py                Pydantic request/response models
    services/
      data_generator.py         Synthetic demo data generation
      data_import.py              CSV/Excel import: validate, map, commit
      data_export.py                CSV export of every artifact
      dashboard.py                   Basic operational KPI aggregation
      forecasting.py                   Forecast models, metrics, backtesting
      forecast_service.py               DB orchestration for forecasting
      workforce_requirement.py            Pure headcount calculation
      workforce_requirement_service.py      DB orchestration for requirement
      optimization.py                        OR-Tools model + independent validator
      optimization_service.py                  DB orchestration for scheduling
      schedule_editor.py                         Manual edits, staged drafts, undo
      scenario_engine.py                           What-if perturbation + comparison
      executive_dashboard.py                         Read-only aggregation layer
  tests/                    166 automated tests, one file per service area
  data/                     workforce.db lives here (created automatically)
```

## Frontend structure

```
frontend/
  src/
    pages/            One file per screen: Dashboard, Forecast, Workforce,
                        Schedule, Scenarios, DataManagement
    components/       Shared UI pieces: KpiCard, HeatStrip, ComingSoon
    lib/api.ts          Typed client — every backend call goes through here
    App.tsx               Navigation and routing
    styles.css              Design tokens (the "control tower" visual theme)
```

## Why these technology choices

- **FastAPI** — lightweight, fast to iterate on, automatic interactive API
  docs at `/docs`, strong typing via Pydantic.
- **SQLite** — zero-configuration, single-file database; no server process
  to install, run, or manage. Swappable for PostgreSQL later without
  application code changes if ever needed at larger scale (out of scope for
  this MVP).
- **Google OR-Tools (CP-SAT)** — a real, production-grade constraint solver
  that runs as a plain local Python library. No external optimization
  service, no API calls, no license server.
- **React + TypeScript + Vite** — standard, well-supported frontend
  tooling; Vite gives fast local dev startup.
- **pandas / statsmodels** — standard, mature Python libraries for the
  forecasting math and CSV/Excel handling.

## The optimizer's independent validation layer

The OR-Tools solver is asked only for raw yes/no assignment decisions
(which employee works which shift on which day). Cost, overtime
attribution, and coverage are recomputed from scratch in plain Python from
those raw decisions — never read from the solver's internal working
variables. This means a bug in the solver's objective function would still
surface as a visibly wrong number when independently recomputed, rather
than being silently trusted.

## Infeasibility handling

If there's genuinely no way to satisfy the hard constraints (employee
availability, skills, hour limits) for the current requirement, the
application reports "No feasible schedule exists" with a specific reason.
It never fabricates a schedule that violates a hard constraint to avoid
showing this message.

## Testing

166 tests across 10 files, organized by service area (one test file roughly
per `services/*.py` module). Tests cover calculation correctness (hand-
verified worked examples), edge cases (zero demand, impossible constraints,
missing data), non-mutation guarantees (e.g. scenarios never touch the live
schedule), and full end-to-end pipelines.
