# Roadmap

## Shipped

**Phase 1 — Application Foundation** ✅
- FastAPI backend, SQLite database, auto-initializing schema
- Synthetic data generator: 2 locations, 3 departments, 30 employees, 90 days hourly demand
- Endpoints: health, data generation, locations, departments, employees, demand, dashboard
- React + TypeScript frontend with navigation shell and a live Dashboard (real KPIs, real chart, real heat-strip — no fabricated numbers)
- 7 automated backend tests covering generation correctness, idempotency, edge cases (empty DB, unknown IDs)

**Phase 2 — Demand Forecasting** ✅
- 3 models: Seasonal Naive, seasonal Moving Average (4-week), Holt-Winters Exponential Smoothing
- Walk-forward / rolling-window backtesting (never a random split) — verified by tests that check training data always precedes test data
- Metrics: WAPE (primary), MAPE (zero-actual points excluded, not divided-by-zero), MAE, RMSE, Bias (signed)
- Automatic model selection by lowest average WAPE across folds, with an MAE fallback
- Persisted model-comparison table (`ForecastModelRun`) so results reload without recomputation
- Endpoints: `POST /api/forecast` (backtest + generate), `GET /api/forecast/results`
- Frontend Forecast workspace: location/department/horizon controls, model comparison table with rank highlighting, actual-vs-forecast chart with a "now" boundary line
- 23 new tests (17 engine-level, 6 API-level) — 30/30 passing across the whole suite

**Phase 3 — Workforce Requirement Engine** ✅
- Converts the *real stored forecast* (not hardcoded/mock data) into hourly required headcount
- Transparent formula: `base = ceil(demand / productivity)`, `required = ceil(base / (1 - total_shrinkage))`
- Configurable productivity (defaults to department's baseline) and 4 shrinkage components (absence, breaks, training, other)
- Strict validation: productivity must be > 0, total shrinkage must be < 100% (rejected with a clear error, not a divide-by-zero)
- Persisted (`WorkforceRequirement` table) and reloadable via `GET /api/workforce/requirement/results`
- Frontend Workforce page: editable assumptions, live peak/avg headcount + labor hours KPIs, demand-vs-headcount chart, hourly breakdown table
- 18 new tests (11 pure-calculation, 7 API-level) — includes the exact worked example from the spec (500 demand / 10 productivity / 13% shrinkage → 58 required) — 49/49 passing across the whole suite
- Fixed a real bug found while testing: the data generator wasn't wiping `ForecastModelRun`/`WorkforceRequirement` on regenerate, which could leak stale results onto a fresh dataset via SQLite's ID recycling. Caught by a regression test, not by inspection.

**Phase 4 — Optimization Engine (Google OR-Tools CP-SAT)** ✅
- Real constraint-programming solver, not a heuristic stand-in — installed as a plain local Python dependency (`ortools` in `requirements.txt`), no external service
- Consumes the *real* `WorkforceRequirement` rows from Phase 3 as the single source of truth for required headcount — the optimizer has no headcount calculation of its own
- Hard constraints: employee availability (day/hour window), required department skill, shift length vs. max daily hours, at most one shift per employee per day (rules out overlaps), max weekly hours
- Soft/objective-driven: labor cost, overtime premium (configurable threshold + multiplier), understaffing/overstaffing penalties, shift-preference matching
- **Independent validation layer**: the solver is only asked for raw yes/no assignment decisions. Cost, overtime attribution (chronological, per employee per week), and coverage are recomputed from scratch in plain Python afterward — never read from the solver's internal auxiliary variables. A wiring bug in the objective would still surface as a wrong displayed number.
- Genuine infeasibility handling: zero employees, zero skilled/available employees, or a validation failure all report "No feasible schedule" with a real reason — never a fabricated result
- Persisted to the existing `Schedule`/`ScheduleAssignment` tables (one Schedule row per date), reloadable via `GET /api/schedule/results`
- Frontend Schedule page: overtime settings, feasible/infeasible banner (infeasible shown honestly, not hidden), KPIs, per-hour coverage strip color-coded by under/on-target/overstaffed, per-day assignment table
- Made the skill constraint meaningful: each department now has a designated primary skill; ~85% of employees hold it, ~15% don't (e.g. still in training) — so "required skills" is a real, testable constraint rather than a rubber stamp
- 23 new tests (14 engine-level — feasibility, each hard constraint individually, independent cost/overtime/coverage recomputation — plus 9 API-level covering the full pipeline and a genuine zero-employee infeasibility case) — 72/72 passing across the whole suite
- Upgraded numpy 1.26.4 → 2.2.6 to satisfy both `scipy` (<2.3) and `ortools` (>=2.0.2); re-ran the entire existing suite to confirm the version bump didn't change any forecasting/requirement numbers

**Phase 5 — Manager Schedule Experience** ✅
- Editable schedule grid (per date, filterable by employee name) that operates on the real Phase 4 solver output — no mock schedule data
- Every edit (change shift / remove assignment) is dry-run validated first (`POST /api/schedule/validate-change`) showing a before/after impact panel (labor cost, coverage, overtime, understaffed hours), then committed only on manager confirmation (`PUT /api/schedule/assignment`)
- All hard-constraint checks reuse the exact same `EmployeeDef`/`ShiftDef`/`compute_schedule_details` machinery from Phase 4 — no duplicated validation logic. Rejections return spec-style messages ("Cannot assign employee: exceeds weekly hour limit.", "...unavailable during this period.", "...does not have the required skill.")
- Single-level Undo (`POST /api/schedule/undo`) and full Revert to Optimized (`POST /api/schedule/revert`, restored from a persisted solver-output snapshot, not by re-solving)
- Re-optimize as preview-then-confirm (`POST /api/schedule/reoptimize-preview` never mutates the persisted schedule; applying it reuses the existing `POST /api/schedule/generate`)
- Schedule status tracking: `optimized` vs `modified`, shown as a pill in the UI, flips back to `optimized` on generate/revert
- Employee detail view (`GET /api/schedule/employee/{id}`): skills, availability, assigned shifts, total hours/cost/overtime, preference conflicts — all computed from the same independent recompute layer, not stored redundantly
- 16 new tests (retrieval, employee detail, valid/invalid edits — availability/skill/weekly-hours/overlap, dry-run vs commit isolation, undo, revert, reoptimize preview non-mutation, full end-to-end manager workflow) — 88/88 passing across the whole suite
- No new dependencies — `start.sh`/`start.bat` unchanged and re-verified from a clean environment

**Phase 5 gap-closing: soft-constraint warnings + batch Save/Cancel** ✅
- `compute_soft_constraint_warnings()` generates non-blocking, informational messages matching the spec's examples exactly ("Employee preference violated...", "Overtime increased/decreased by N hours.", "Labor cost increased/decreased by $X.XX.", "Coverage improved but overstaffing increased.") — returned alongside every validate/stage/commit response, never blocking the change
- Real batch staging: a new `ScheduleDraft` table holds a manager's in-progress edits (validated and persisted to SQLite immediately — never held only in frontend memory) without touching the live `Schedule`/`ScheduleAssignment` tables until explicitly saved
- `POST /api/schedule/stage-change` — validate + stage one edit, returns before/after impact and warnings for that incremental step
- `GET /api/schedule/draft` — cumulative baseline-vs-working summary plus the ordered list of staged changes
- `POST /api/schedule/save-draft` — atomically commits the whole batch, snapshots the pre-batch state into the undo buffer, clears the draft
- `POST /api/schedule/cancel-draft` — discards the draft with zero effect on the live schedule
- Verified live: staged a removal + a reassignment, confirmed the live schedule was byte-for-byte unchanged while the draft was pending (38 assignments, status `optimized`), then `save-draft` atomically applied both (37 assignments, status `modified`)
- Frontend `Schedule.tsx` rewritten to stage edits inline (grid shows a "Staged" badge on pending rows) with a cumulative baseline-vs-working diff panel and Save changes/Cancel changes buttons
- 17 new tests (`test_schedule_gaps.py`) — 105/105 passing across the whole suite
- Fixed a real bug found during this work: the `stage-change` endpoint's response model was missing `has_unsaved_changes`, so FastAPI was silently stripping it from every response before the frontend ever saw it

**Phase 6 — What-If Scenario Engine** ✅
- Perturbs real inputs and re-runs the real Phase 3 requirement math and Phase 4 OR-Tools solver — never a separate scenario-specific calculation
- Four levers: demand %, absenteeism (percentage points added to shrinkage), productivity %, labor cost %
- "Base case" uses the actual persisted schedule when one exists; falls back to a one-off ephemeral solve (never persisted) if no schedule has been generated yet, so scenarios work at any pipeline stage
- Scenarios never mutate the live schedule — verified by a dedicated test comparing `/api/schedule/results` before and after running a scenario
- Real, dynamically-generated executive summary sentence built from the actual delta numbers (never a canned template with blanks filled in)
- Invalid perturbations (e.g. absenteeism pushing total shrinkage ≥100%, productivity ≤0) are rejected with a clear 422 error, reusing Phase 3's `validate_assumptions` — no duplicate validation logic
- Scenario runs persist to the `Scenario` table (already present in the schema since Phase 1) for history/audit, listed via `GET /api/scenario/results`
- **Honest capacity-constraint finding, documented rather than hidden**: when the optimizer can't schedule beyond the existing employee pool, `additional_labor_cost` correctly comes back as $0 even though `additional_headcount` is positive — the tool tells you "you'd need to hire," not a fabricated cost number for capacity that doesn't exist. The UI surfaces this as an explanatory note rather than a bug.
- Frontend Scenarios page: quick presets (Demand +10/20/-10%, Absenteeism +10%, Productivity -10%, Cost +5%), custom inputs, live before/after/delta table, and a scenario history list
- 16 new tests (headcount-direction correctness per lever, base-uses-real-schedule, live-schedule-never-mutated, invalid-input handling, persistence/listing, regenerate clears stale scenarios, end-to-end) — 121/121 passing across the whole suite

**Phase 7 — Executive Dashboard v2** ✅
- Pure aggregation layer (`app/services/executive_dashboard.py`) over Phases 2-6 — computes nothing a lower phase doesn't already compute; every KPI is read or simply derived (e.g. cost-per-hour = total cost / total hours) from data those phases produced
- Single endpoint (`GET /api/executive/dashboard`) powers the whole page in one call, per the spec's performance guidance — no new API surface duplicated per widget
- Executive KPI layer: forecast accuracy, WAPE, required/scheduled/available headcount, coverage %, understaffed/overstaffed hours, labor cost, overtime hours, estimated savings — each individually null-safe ("—" in the UI) rather than fabricated when a lower phase hasn't been run yet
- Demand outlook: merges real actual + forecast series, with a dynamically-generated insight sentence (% change vs. the most recent comparable period, and the specific hour window with the largest swing)
- Workforce capacity: reuses the exact same coverage array Phase 4/5 already computes — no duplicate coverage math
- Labor cost: current cost, **real** overtime cost (computed per-assignment as `stored_cost − hours × employee's base rate`, not an estimate), cost per hour, cost per transaction, and a real daily cost trend read straight from `Schedule.total_cost` rows
- Optimization impact: compares the live schedule against the persisted `ScheduleOptimizedSnapshot` **only when a manager has actually modified the schedule** — otherwise honestly returns "Baseline unavailable" rather than inventing a before-state, per the spec's explicit instruction
- What-if summary: surfaces the most recently run scenario's already-computed baseline→scenario comparison (from Phase 6) — no recomputation
- Deterministic, rule-based alerts (understaffed/overstaffed contiguous-window detection, overtime-threshold, forecast-bias) and recommendations (shift coverage between over/understaffed windows, flag the peak-requirement weekday) — no external AI call, thresholds documented as named constants in the module
- 21 new tests (KPI cross-checks against source endpoints, overtime-cost-split correctness, optimization-impact availability logic in all three states, alert/recommendation rule correctness, filtering, end-to-end) — 143/143 passing, **plus 1 regression test added after finding and fixing a real bug during verification**
- **Bug found and fixed live**: the demand-insight sentence used one "direction" word for both the overall trend and the peak-swing window, so it could say "expected to increase... with the largest increase" when the peak window was actually a decrease relative to its own hour-of-day baseline (overall trend and a specific hour's trend can point opposite ways). Fixed to describe each clause with its own sign; regression test added; final count **144/144 passing**.
- **Formatting fix**: a full-day understaffed/overstaffed window rendered as "00:00–24:00"; changed to read "all day" for executive readability.
- Rewrote the existing Dashboard page in place as the Executive Dashboard v2 (rather than adding a competing page) — the "Generate sample data" onboarding flow is preserved unchanged for when no data exists yet
- No new dependencies, no new database tables — `start.sh`/`start.bat` re-verified from a clean environment

**Phase 8 — Polish & Demo Readiness** ✅
- Real CSV/Excel import for demand, employees, availability, skills, and productivity assumptions — `pandas`/`openpyxl` parse both formats identically; a preview-then-commit flow means nothing is written to the database until the user confirms
- Validation report (valid rows / warnings / errors) shared between preview and commit via one implementation, so they can never disagree — covers unparseable dates, negative demand, duplicate employee IDs, missing required fields, and unknown employee references in availability/skills uploads
- Simple column-mapping UI with name-based auto-suggestion (e.g. "Store" → location, "Volume" → demand), editable before committing
- Added `Employee.external_id` so availability/skills files can reference employees by their source system's ID rather than an internal database key
- Demo data explicitly preserved: **Load Demo Data** and **Reset Demo Data** (with a confirmation prompt, since it's destructive) sit alongside the upload flow on a new Data Management page
- CSV export for every artifact: forecast, workforce requirement, schedule, an individual scenario, and the executive KPI summary — plain `GET` endpoints returning `text/csv`, no external service
- Global unhandled-exception handler: no Python traceback is ever sent to the client; the real error is logged server-side and the client gets a plain, actionable message
- 22 new tests (mapping suggestion, preview-never-persists, validation correctness per data type, commit correctness including the employee→availability external-ID linkage, Excel-vs-CSV parity, all-invalid-rows imports nothing, every export type, export-without-data returns 404 not a crash) — 166/166 passing across the whole suite
- **Full end-to-end business workflow verified live against a running server**: load demo data → forecast → requirement → OR-Tools schedule → manually edit and save a shift → run a what-if scenario → confirm the executive dashboard's `estimated_savings` KPI exactly reflects the edit just made → export forecast/schedule/executive-summary CSVs and confirm real rows in each
- Mandated clean-environment validation re-run from a genuinely fresh state (no `venv`, no `node_modules`, no database, no logs, no pid files) — `start.sh` auto-installed everything including the two new dependencies (`openpyxl`, `python-multipart`) with no manual steps
- Dependency audit written (`docs/dependency-audit.md`): every dependency listed with its purpose, required vs. explicitly-not-required drawn as a hard line, Docker documented as optional-and-unused rather than a requirement
- README fully rewritten for a non-technical audience: what the app does, how to start/stop, how to use every feature, troubleshooting, architecture — replacing the developer-oriented version from earlier phases

## Next phases

None currently planned — Phase 8 was the last item on the original phased build plan. Any further work (multi-level undo/redo, forecast confidence intervals, external demand regressors, Docker packaging for those who want it) is optional polish, not a gap in the MVP.

## Explicitly deferred beyond this prototype

PostgreSQL, enterprise auth/SSO/RBAC, audit logging, PII governance, model registry
and champion/challenger infrastructure, real-time streaming demand, Redis, Kubernetes,
multi-region deployment, payroll/HRIS/WFM/POS/CRM integrations, an AI planning copilot.

## Known limitations to revisit

- Forecast confidence intervals (`lower_bound`/`upper_bound` columns exist in the schema but aren't populated yet).
- External regressors (`is_promotion`, `is_holiday` flags exist in the demand data) aren't consumed by any model yet — a natural Phase 2.1 addition alongside SARIMAX.
- **Default demo dataset is intentionally understaffed relative to peak demand.** With the spec's target scale (~30 employees split across 2 locations × 3 departments) and demand peaks requiring 15-22 required headcount in a single department/hour, a fresh demo schedule often shows real coverage in the 15-30% range - this is the solver's honest answer against a genuinely small employee pool, not a bug. It's arguably a good demo narrative ("here's what happens if you're understaffed"), but if you want a fuller-looking default schedule, the fix is recalibrating the demand generator's volume or the department productivity defaults in Phase 8 polish, not touching the optimizer.
- Multi-level undo/redo across a saved batch isn't implemented — Undo restores the single state immediately before the most recent *saved* batch, not a full history stack.
