# Demo Guide

A suggested walkthrough for demonstrating the application, plus an
important note on how to interpret the built-in demo dataset honestly.

## Important: why the demo shows understaffing

The built-in synthetic dataset intentionally uses a **small employee pool**
(~30 employees split across 2 locations × 3 departments) relative to
**realistic peak demand** (which can require 15–22 people in a single
department during a busy hour). This means a freshly generated schedule
will often show real, visible understaffing — typically 15–40% coverage in
a busy department, depending on random seed and settings.

**This is not a bug, and it is not being hidden.** It is a deliberate
scale choice, documented from the point the optimizer was built, for two
reasons:

1. It proves every number in the app is real. If the demo were artificially
   well-staffed, you'd have no way to tell whether the "understaffed hours"
   and "coverage %" figures were actually being computed, or just always
   showing a reassuring green number.
2. It makes the tool's actual value obvious: this is exactly the situation
   a real operations leader faces, and exactly the kind of gap this tool
   is built to surface and help you close (via the What-If scenario engine,
   for example — model what it would take to fix the gap before deciding
   whether to hire).

If you want a better-covered schedule for a specific demonstration, either
increase `employees_per_location_dept` when generating data (via the API,
or ask for a larger dataset), or use the Workforce Requirement page to
lower the productivity assumption's demand on staffing, or narrow the
scenario to a smaller department. The point is: whatever number you see is
real, and you're in control of the inputs.

## Suggested walkthrough (10–15 minutes)

### 1. Load the data (1 minute)
Open the app, go to **Data**, click **Load Demo Data**. Mention: "This
generates realistic hourly demand with actual seasonality — busier midday,
quieter overnight, quieter on weekends, occasional promotional spikes."

### 2. Forecast (2 minutes)
Go to **Forecast**, select a location/department, click **Generate
forecast**. Point out the model comparison table: "The system doesn't
assume one model is best — it backtests three approaches against real
history and picks the winner by WAPE. In this run, [X] won because [Y]
underperformed for a specific, explainable reason (e.g. exponential
smoothing's daily seasonality assumption fights the actual weekly pattern
in this data)."

### 3. Workforce Requirement (1 minute)
Go to **Workforce**, click **Calculate requirement**. Show the transparent
math: forecast demand → productivity → shrinkage → required headcount, all
visible, all adjustable.

### 4. Optimization (2 minutes)
Go to **Schedule**, click **Generate optimized schedule**. This is the
moment to say: "This isn't a rule-of-thumb scheduler — it's a real
constraint solver evaluating every legal combination of employee, shift,
and day against availability, skills, and hour limits, and minimizing
cost." Point at the coverage KPI and explain the understaffing honestly (see
above) if it's a busy department.

### 5. Manual edit (2 minutes)
Change one employee's shift in the grid. Show the before/after impact panel
appearing instantly — cost, coverage, overtime — before you've saved
anything. Try an invalid change (e.g. assign someone already at their
weekly hour limit) and show the clear rejection message. Save the valid
change, then show **Revert to Optimized** restoring the original.

### 6. What-If Scenario (2 minutes)
Go to **Scenarios**, click the "Demand +20%" preset, run it. Read the
generated executive summary sentence aloud — it's built from the actual
numbers, not a template with blanks filled in. If the optimizer can't
schedule beyond the current employee pool, point out that the tool says so
honestly (additional cost may show as $0 even though additional headcount
is positive) rather than fabricating a hiring-cost estimate it can't back up.

### 7. Executive Dashboard (2 minutes)
Go to **Dashboard**. This is the "step back and look at the whole picture"
moment: KPIs, demand outlook with its own generated insight sentence,
labor cost trend, the optimization impact of the edit you just made, the
scenario you just ran, and the alerts/recommendations — all computed from
what you just did, live.

### 8. Export (30 seconds)
Go to **Data**, export the schedule or executive summary as a CSV to show
it's not locked into the app.

## Resetting between demos

Use **Reset Demo Data** on the Data page (confirms before proceeding) to
generate a fresh synthetic dataset with a new random seed, giving you
different specific numbers for a repeat demonstration without ever reusing
the exact same run.
