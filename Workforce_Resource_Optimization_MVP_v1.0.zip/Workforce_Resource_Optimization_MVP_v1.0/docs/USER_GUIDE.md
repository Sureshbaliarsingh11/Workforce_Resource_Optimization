# User Guide

This guide walks through every screen in the application, in the order a
first-time user would naturally move through them.

## Navigation

The sidebar has seven pages: **Dashboard**, **Forecast**, **Workforce**,
**Schedule**, **Scenarios**, **Data**, and (a couple of pages still marked
"Coming Soon" for future work beyond this MVP). The natural workflow runs
left to right through these in the order listed below.

## 1. Data — load or upload your data

Start here. You have two choices:

- **Load Demo Data** — generates a realistic synthetic dataset (2 locations,
  3 departments, ~30 employees, 90 days of hourly demand) so you can explore
  every feature immediately.
- **Upload real data** — choose a data type (Historical Demand, Employees,
  Employee Availability, Employee Skills, or Productivity Assumptions),
  select a CSV or Excel file, and click **Validate**. You'll see a report of
  how many rows are valid, plus any warnings or errors, before anything is
  imported. Adjust the column mapping if your file's headers don't match
  exactly, then click **Import**.

**Reset Demo Data** wipes everything and reloads a fresh synthetic dataset —
it asks for confirmation first since it's destructive.

Recommended upload order: Employees → Availability/Skills → Demand →
Productivity Assumptions.

## 2. Forecast — predict demand

Pick a **Location**, **Department**, and **horizon** (7 or 14 days), then
click **Generate forecast**. The app backtests three models against your
actual history:

- Seasonal Naive
- Moving Average
- Exponential Smoothing

Each is scored with WAPE (Weighted Absolute Percentage Error — lower is
better) and Bias (positive = over-forecasting, negative = under-
forecasting). The best-performing model is automatically selected and
shown on the chart, with the comparison table underneath.

## 3. Workforce — calculate required headcount

Set your **productivity** (units one employee can handle per hour) and
**shrinkage** (absence %, breaks %, training %, other %), then click
**Calculate requirement**. This converts the forecast into "how many people
do I need, hour by hour," with the full math shown transparently (base
headcount → adjusted for shrinkage → final requirement).

## 4. Schedule — generate and edit the optimized schedule

Click **Generate optimized schedule**. This runs a real constraint solver
(Google OR-Tools) against your actual employees — their availability,
skills, and hour limits — to produce the lowest-cost schedule that covers
as much of the requirement as possible.

**If it says "No feasible schedule exists"**, that's an honest answer: your
current employee pool genuinely can't be arranged to meet the hard
constraints (e.g. not enough people with the right skill). It is never
faked.

**To edit the schedule by hand:**
1. Pick a date, and use the shift dropdown next to any employee to change or
   remove their assignment.
2. You'll see an immediate preview of the impact (cost, coverage, overtime
   change) before anything is saved, plus any soft-constraint warnings
   (e.g. "employee preference violated").
3. Invalid changes (would violate an hour limit, availability, or skill
   requirement) are rejected with a clear reason — nothing invalid is ever
   silently saved.
4. Click **Save Changes** to commit everything you've staged, or **Cancel
   Changes** to discard it.
5. **Undo** reverts your most recent saved edit. **Revert to Optimized**
   discards all manual edits and restores the solver's original result.
6. **Re-optimize** runs the solver fresh and shows you a before/after
   comparison — nothing replaces your current schedule until you confirm.

Click any employee's name to see their full detail: skills, availability,
assigned shifts, total hours, overtime, and cost.

## 5. Scenarios — model "what if"

Pick a preset (Demand +10%/+20%/-10%, Absenteeism +10%, Productivity -10%,
Labor cost +5%) or set your own combination, then click **Run scenario**.
You'll get a real before/after comparison — the app actually re-runs the
requirement calculation and the solver with your adjusted numbers, not an
estimate — plus a plain-English summary sentence. All past scenarios are
kept in a history list you can revisit or export.

## 6. Dashboard — the executive view

The home page. One screen answers the questions leadership cares about:

- **KPIs**: forecast accuracy, required vs. scheduled headcount, coverage
  %, labor cost, overtime hours, estimated savings
- **Demand outlook**: actual vs. forecast, with an automatic insight
  sentence describing the trend and where the biggest swing is expected
- **Workforce capacity**: required vs. scheduled vs. total available staff
- **Labor cost**: current cost, the real overtime cost portion, and a daily
  cost trend
- **Optimization impact**: if you've manually edited the schedule, a real
  before/after comparison against the solver's original result. If you
  haven't, it says so honestly rather than inventing a comparison.
- **Latest scenario**: your most recent what-if result
- **Alerts**: specific, data-driven warnings such as "understaffed by 4
  employees between 14:00–16:00" — never generic or made up
- **Recommendations**: concrete, explainable suggestions (e.g. shifting
  coverage from an overstaffed window to an understaffed one)

Any section without enough data yet says so plainly instead of showing
something misleading.

## Exporting results

From the Data page (or per-scenario on the Scenarios page), export a CSV of
the forecast, workforce requirement, schedule, an individual scenario, or
the executive KPI summary — for use in a spreadsheet, a slide deck, or
anywhere else.

## A note on the demo dataset

The built-in demo data is intentionally scaled so that a fresh schedule
often shows real understaffing (the solver's honest answer against a
deliberately small ~30-person employee pool relative to demand). This is
not a bug — it's what lets you see the optimization and what-if scenario
features do meaningful, visible work. See `docs/DEMO_GUIDE.md` for a
suggested walkthrough.
