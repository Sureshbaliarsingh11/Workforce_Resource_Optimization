# Dependency Audit

This document lists every software dependency the application uses, and
draws a clear line between what's **required** (installed automatically by
`start.sh`/`start.bat`, all running locally on your machine) and what's
**explicitly not required** at any point.

## Required local dependencies

Everything below is a plain software library or runtime that installs onto
your own computer. None of it talks to the internet during normal use, and
none of it requires an account, API key, or subscription.

### Backend (Python)

| Package | Purpose |
|---|---|
| fastapi | Web API framework |
| uvicorn | Local web server that runs the API |
| sqlalchemy | Database ORM (talks to the local SQLite file) |
| pydantic | Request/response data validation |
| numpy | Numerical computing (used by pandas/statsmodels/OR-Tools) |
| pandas | Tabular data handling, CSV/Excel import & export |
| openpyxl | Reads/writes `.xlsx` Excel files |
| python-multipart | Lets the API accept file uploads |
| python-dateutil | Date parsing utilities |
| statsmodels | Exponential Smoothing forecasting model |
| scipy | Required by statsmodels |
| ortools | Google's open-source constraint solver - runs the schedule optimizer entirely on your machine |
| pytest | Runs the automated test suite (development only, not needed to use the app) |
| httpx | Used by the test suite to call the API in-process (development only) |

All of these install automatically via `pip install -r backend/requirements.txt`,
which both `start.sh` and `start.bat` run every time you start the app.

### Frontend (Node.js / npm)

| Package | Purpose |
|---|---|
| react, react-dom | UI framework |
| react-router-dom | Page navigation |
| recharts | Charts |
| vite | Local dev server and build tool |
| typescript | Type-checking during build |

All of these install automatically via `npm install`, which both startup
scripts run every time you start the app (skipped if `node_modules` already
exists, to save time on repeat launches).

### Database

**SQLite** - not a separate package to install; Python's standard library
includes it, and SQLAlchemy talks to it as a single file
(`backend/data/workforce.db`) that's created automatically on first run.
No database server, no separate installation, no configuration.

## Explicitly NOT required

The application will run correctly, from a completely offline machine, with
none of the following:

- Docker or any container runtime
- PostgreSQL, MySQL, or any external/networked database
- Redis or any caching layer
- Any cloud provider (AWS, Azure, GCP)
- OpenAI, Claude, Gemini, or any other AI API
- Any external forecasting or optimization service
- Any external authentication or identity provider
- Any SaaS analytics or BI platform (Power BI, Tableau, etc.)
- An internet connection, once dependencies are installed

Every calculation in the app - forecasting, workforce requirement math,
schedule optimization, scenario modeling, and the executive dashboard - runs
in the local Python process using the libraries listed above.

## Optional (not required, documented for completeness)

- **Docker**: not part of the standard startup flow and never required. If
  you prefer container-based deployment for your own infrastructure, you
  could write a Dockerfile around the existing `backend/` and `frontend/`
  folders, but the project does not include or depend on one, and none of
  the setup, testing, or verification for this application has used Docker
  at any point.
