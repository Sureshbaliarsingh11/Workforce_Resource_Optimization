# Installation Guide

## Requirements

Before extracting this package, make sure your computer has:

- **Python 3.10 or newer** — check with `python --version` (Windows) or
  `python3 --version` (Mac/Linux). Get it from https://python.org if missing.
- **Node.js 18 or newer** — check with `node --version`. Get it from
  https://nodejs.org if missing.

That's it. No Docker, no database server, no cloud account, no API keys.
Everything else installs automatically in the next step.

## Windows

1. Extract the ZIP file to a folder of your choice (e.g. `C:\WorkforceOptimizer`).
2. Double-click **`start.bat`**.
3. Two terminal windows will open. The first run takes a minute or two while
   it downloads and installs dependencies (Python packages including the
   OR-Tools solver, and Node packages for the web interface) — this only
   happens once.
4. When both windows show "running", open your browser to
   **http://localhost:5173**.

To stop: run **`stop.bat`**, or simply close both terminal windows.

## Mac / Linux

1. Extract the ZIP file to a folder of your choice.
2. Open a terminal in that folder.
3. Make the scripts executable (first time only):
   ```bash
   chmod +x start.sh stop.sh
   ```
4. Run:
   ```bash
   ./start.sh
   ```
5. Open your browser to **http://localhost:5173**.

To stop:
```bash
./stop.sh
```

## What the startup script does automatically

1. Creates a Python virtual environment inside `backend/venv` (if it doesn't
   already exist)
2. Installs every Python dependency listed in `backend/requirements.txt`
3. Installs every Node dependency listed in `frontend/package.json`
   (skipped if `frontend/node_modules` already exists, to save time)
4. Initializes the local SQLite database automatically on first backend
   request — no manual database setup of any kind
5. Starts the backend API on port **8877**
6. Starts the frontend web interface on port **5173**

## Verifying it worked

- Backend health check: open **http://localhost:8877/api/health** — you
  should see `{"status":"ok", ...}`
- Backend API docs: **http://localhost:8877/docs**
- Frontend: **http://localhost:5173** should show the application

## Common issues

**"python is not recognized" / "python3: command not found"** — Python
isn't installed or isn't on your system PATH. Reinstall from
https://python.org and make sure to check "Add Python to PATH" during
Windows installation.

**"npm is not recognized" / "node: command not found"** — Node.js isn't
installed. Install from https://nodejs.org.

**Ports already in use** — another application is using port 8877 or 5173.
Close it, or edit the port numbers in `start.sh`/`start.bat` and
`frontend/vite.config.ts` to use different ports.

**First run seems slow** — installing the OR-Tools solver package can take
a minute or two depending on your internet connection. This only happens on
the very first run; subsequent launches are fast.

**Starting fresh** — stop the app, delete `backend/data/workforce.db`
(if it exists), and start again. The database recreates itself
automatically with no data — click "Load Demo Data" once the app is open.
