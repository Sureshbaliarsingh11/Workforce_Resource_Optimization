import { DemandPoint } from "../lib/api";

function colorFor(ratio: number): string {
  // ratio 0..1 of value vs max. Teal (low) -> amber (mid) -> red (high)
  if (ratio < 0.4) {
    const t = ratio / 0.4;
    return mix("#161d22", "#2bc8a8", t);
  } else if (ratio < 0.75) {
    const t = (ratio - 0.4) / 0.35;
    return mix("#2bc8a8", "#eea23c", t);
  } else {
    const t = (ratio - 0.75) / 0.25;
    return mix("#eea23c", "#ef5c4a", Math.min(1, t));
  }
}

function mix(hexA: string, hexB: string, t: number): string {
  const a = hexToRgb(hexA);
  const b = hexToRgb(hexB);
  const r = Math.round(a[0] + (b[0] - a[0]) * t);
  const g = Math.round(a[1] + (b[1] - a[1]) * t);
  const bl = Math.round(a[2] + (b[2] - a[2]) * t);
  return `rgb(${r},${g},${bl})`;
}

function hexToRgb(hex: string): [number, number, number] {
  const v = hex.replace("#", "");
  return [parseInt(v.slice(0, 2), 16), parseInt(v.slice(2, 4), 16), parseInt(v.slice(4, 6), 16)];
}

export default function HeatStrip({ points }: { points: DemandPoint[] }) {
  if (points.length === 0) return null;
  const max = Math.max(...points.map((p) => p.demand), 1);
  return (
    <div>
      <div className="heat-strip">
        {points.map((p, i) => (
          <div
            key={i}
            className="heat-cell"
            title={`${new Date(p.timestamp).toLocaleString()} — ${p.demand.toFixed(0)} demand`}
            style={{ background: colorFor(p.demand / max) }}
          />
        ))}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
        <span className="faint-text mono" style={{ fontSize: 10 }}>
          {new Date(points[0].timestamp).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
        </span>
        <span className="faint-text mono" style={{ fontSize: 10 }}>
          {new Date(points[points.length - 1].timestamp).toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
          })}
        </span>
      </div>
    </div>
  );
}
