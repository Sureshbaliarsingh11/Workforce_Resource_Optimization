import { ReactNode } from "react";

export default function KpiCard({
  label,
  value,
  sub,
  muted,
}: {
  label: string;
  value: string;
  sub?: ReactNode;
  muted?: boolean;
}) {
  return (
    <div className="kpi-card">
      <div className="kpi-label">{label}</div>
      <div className={`kpi-value ${muted ? "muted" : ""}`}>{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}
