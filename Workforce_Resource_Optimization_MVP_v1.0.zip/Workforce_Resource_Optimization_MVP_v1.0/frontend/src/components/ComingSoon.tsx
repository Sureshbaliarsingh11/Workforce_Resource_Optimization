export default function ComingSoon({ moduleName, phase }: { moduleName: string; phase: number }) {
  return (
    <div className="panel">
      <div className="empty-state">
        <div className="icon-mark">···</div>
        <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
          {moduleName} — Coming in Phase {phase}
        </div>
        <div style={{ fontSize: 13 }}>
          This module isn't built yet. It's on the roadmap and will be functional,
          not a mockup, when its phase ships.
        </div>
      </div>
    </div>
  );
}
