import { NavLink, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Forecast from "./pages/Forecast";
import Workforce from "./pages/Workforce";
import Schedule from "./pages/Schedule";
import Scenarios from "./pages/Scenarios";
import DataManagement from "./pages/DataManagement";
import ComingSoon from "./components/ComingSoon";

const NAV = [
  { to: "/", label: "Dashboard", exact: true },
  { to: "/forecast", label: "Forecast" },
  { to: "/workforce", label: "Workforce" },
  { to: "/schedule", label: "Schedule" },
  { to: "/scenarios", label: "Scenarios" },
  { to: "/performance", label: "Performance" },
  { to: "/data", label: "Data" },
];

export default function App() {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">WFX · v0.1</div>
          <div className="brand-title">Workforce Optimizer</div>
        </div>
        <ul className="nav-list">
          {NAV.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                end={item.exact}
                className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
              >
                <span className="dot" />
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
        <div className="nav-phase-tag">PHASE 8 — POLISH &amp; DEMO READY</div>
      </aside>
      <main className="main">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/forecast" element={<Forecast />} />
          <Route path="/workforce" element={<Workforce />} />
          <Route path="/schedule" element={<Schedule />} />
          <Route path="/scenarios" element={<Scenarios />} />
          <Route path="/performance" element={<ComingSoon moduleName="Performance & Continuous Learning" phase={7} />} />
          <Route path="/data" element={<DataManagement />} />
        </Routes>
      </main>
    </div>
  );
}
