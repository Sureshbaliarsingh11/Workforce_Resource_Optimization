import { useEffect, useState } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";
import { api, ApiError, Location, Department, DemandPoint, ForecastResult } from "../lib/api";

const MODEL_LABELS: Record<string, string> = {
  seasonal_naive: "Seasonal Naive",
  moving_average: "Moving Average (4wk)",
  exponential_smoothing: "Exponential Smoothing",
};

export default function Forecast() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedLoc, setSelectedLoc] = useState<number | null>(null);
  const [selectedDept, setSelectedDept] = useState<number | null>(null);
  const [horizon, setHorizon] = useState<7 | 14>(7);

  const [result, setResult] = useState<ForecastResult | null>(null);
  const [history, setHistory] = useState<DemandPoint[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [noDataYet, setNoDataYet] = useState(false);

  useEffect(() => {
    Promise.all([api.locations(), api.departments()])
      .then(([locs, depts]) => {
        setLocations(locs);
        setDepartments(depts);
        if (locs.length && depts.length) {
          setSelectedLoc(locs[0].id);
          setSelectedDept(depts[0].id);
        }
      })
      .catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    if (selectedLoc && selectedDept) {
      loadExisting();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLoc, selectedDept]);

  async function loadExisting() {
    if (!selectedLoc || !selectedDept) return;
    setLoading(true);
    setError(null);
    setNoDataYet(false);
    try {
      const [hist, fc] = await Promise.all([
        api.demand(selectedLoc, selectedDept, 14),
        api.forecastResults(selectedLoc, selectedDept).catch((e) => {
          if (e instanceof ApiError && e.status === 404) return null;
          throw e;
        }),
      ]);
      setHistory(hist);
      setResult(fc);
      if (fc) setHorizon(fc.horizon_days as 7 | 14);
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 404) {
        setNoDataYet(true);
      } else {
        setError(e.message);
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleGenerate() {
    if (!selectedLoc || !selectedDept) return;
    setGenerating(true);
    setError(null);
    try {
      const fc = await api.generateForecast(selectedLoc, selectedDept, horizon);
      setResult(fc);
      const hist = await api.demand(selectedLoc, selectedDept, 14);
      setHistory(hist);
      setNoDataYet(false);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setGenerating(false);
    }
  }

  const chartData = (() => {
    const map = new Map<string, { time: string; actual?: number; forecast?: number }>();
    for (const h of history) {
      map.set(h.timestamp, { time: h.timestamp, actual: h.demand });
    }
    if (result) {
      for (const p of result.forecast_points) {
        const existing = map.get(p.timestamp) ?? { time: p.timestamp };
        existing.forecast = p.predicted_demand;
        map.set(p.timestamp, existing);
      }
    }
    return Array.from(map.values())
      .sort((a, b) => a.time.localeCompare(b.time))
      .map((d) => ({
        ...d,
        label: new Date(d.time).toLocaleString(undefined, {
          month: "short",
          day: "numeric",
          hour: "numeric",
        }),
      }));
  })();

  const boundaryLabel = history.length
    ? new Date(history[history.length - 1].timestamp).toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
      })
    : undefined;

  if (locations.length === 0 && !loading) {
    return (
      <div>
        <div className="page-header">
          <div>
            <div className="page-eyebrow">Demand Intelligence</div>
            <h1 className="page-title">Forecast Workspace</h1>
          </div>
        </div>
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">◇</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
              No data yet
            </div>
            <div style={{ fontSize: 13 }}>Generate sample data from the Dashboard first, then come back here.</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Demand Intelligence</div>
          <h1 className="page-title">Forecast Workspace</h1>
        </div>
      </div>

      <div className="panel">
        <div style={{ display: "flex", gap: 20, alignItems: "flex-end", flexWrap: "wrap" }}>
          <div className="field-group">
            <label className="field-label" htmlFor="loc-select">Location</label>
            <select id="loc-select" value={selectedLoc ?? ""} onChange={(e) => setSelectedLoc(Number(e.target.value))}>
              {locations.map((l) => (
                <option key={l.id} value={l.id}>{l.name}</option>
              ))}
            </select>
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="dept-select">Department</label>
            <select id="dept-select" value={selectedDept ?? ""} onChange={(e) => setSelectedDept(Number(e.target.value))}>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="horizon-select">Forecast horizon</label>
            <select id="horizon-select" value={horizon} onChange={(e) => setHorizon(Number(e.target.value) as 7 | 14)}>
              <option value={7}>7 days</option>
              <option value={14}>14 days</option>
            </select>
          </div>
          <button className="btn btn-primary" onClick={handleGenerate} disabled={generating}>
            {generating ? "Backtesting models\u2026" : "Generate forecast"}
          </button>
        </div>
      </div>

      {error && (
        <div className="panel" style={{ borderColor: "var(--signal-red)" }}>
          <span style={{ color: "var(--signal-red)" }}>Error: {error}</span>
        </div>
      )}

      {noDataYet && !result && (
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">~</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
              No forecast generated yet
            </div>
            <div style={{ fontSize: 13 }}>
              Click "Generate forecast" to backtest 3 models (Seasonal Naive, Moving Average,
              Exponential Smoothing) via walk-forward validation and select the best performer by WAPE.
            </div>
          </div>
        </div>
      )}

      {result && (
        <>
          <div className="panel">
            <div className="panel-title-row">
              <div className="panel-title">Model comparison — walk-forward backtest</div>
              <span className="faint-text mono" style={{ fontSize: 11 }}>
                {result.folds_evaluated} rolling folds evaluated
              </span>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Model</th>
                  <th>WAPE</th>
                  <th>MAE</th>
                  <th>RMSE</th>
                  <th>Bias</th>
                </tr>
              </thead>
              <tbody>
                {[...result.model_comparison]
                  .sort((a, b) => (a.rank ?? 99) - (b.rank ?? 99))
                  .map((m) => (
                    <tr key={m.model_name} className={m.is_best ? "best-row" : ""}>
                      <td>
                        {m.rank ? (
                          <span className={`rank-badge ${m.rank === 1 ? "rank-1" : ""}`}>{m.rank}</span>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td style={{ fontFamily: "var(--font-display)" }}>
                        {MODEL_LABELS[m.model_name] ?? m.model_name}
                        {m.is_best && (
                          <span className="status-pill healthy" style={{ marginLeft: 8 }}>Selected</span>
                        )}
                      </td>
                      <td>{m.wape !== null ? `${(m.wape * 100).toFixed(1)}%` : "—"}</td>
                      <td>{m.mae !== null ? m.mae.toFixed(1) : "—"}</td>
                      <td>{m.rmse !== null ? m.rmse.toFixed(1) : "—"}</td>
                      <td>
                        {m.bias !== null
                          ? `${m.bias > 0 ? "+" : ""}${(m.bias * 100).toFixed(1)}%`
                          : "—"}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
            <div className="muted-text" style={{ fontSize: 11.5, marginTop: 12 }}>
              WAPE = weighted absolute percentage error (primary selection metric). Bias: positive means
              over-forecasting, negative means under-forecasting. Lower WAPE/MAE/RMSE and bias near 0% are better.
            </div>
          </div>

          <div className="panel">
            <div className="panel-title-row">
              <div className="panel-title">Actual vs forecast</div>
              <span className="faint-text mono" style={{ fontSize: 11 }}>
                {MODEL_LABELS[result.best_model ?? ""] ?? result.best_model} — next {result.horizon_days} days
              </span>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <ComposedChart data={chartData}>
                <CartesianGrid stroke="#262f36" strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: "#7c8b93", fontSize: 10 }}
                  interval={Math.max(1, Math.floor(chartData.length / 8))}
                  axisLine={{ stroke: "#262f36" }}
                  tickLine={false}
                />
                <YAxis tick={{ fill: "#7c8b93", fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: "#1b2329", border: "1px solid #262f36", borderRadius: 6, fontSize: 12 }}
                  labelStyle={{ color: "#e8edf0" }}
                />
                {boundaryLabel && (
                  <ReferenceLine
                    x={boundaryLabel}
                    stroke="#7c8b93"
                    strokeDasharray="2 2"
                    label={{ value: "now", position: "insideTopLeft", fill: "#7c8b93", fontSize: 10 }}
                  />
                )}
                <Line type="monotone" dataKey="actual" stroke="#5b8def" strokeWidth={2} dot={false} name="Actual" />
                <Line
                  type="monotone"
                  dataKey="forecast"
                  stroke="#2bc8a8"
                  strokeWidth={2}
                  strokeDasharray="5 3"
                  dot={false}
                  name="Forecast"
                />
              </ComposedChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", gap: 16, marginTop: 10, fontSize: 12 }}>
              <span><span style={{ display: "inline-block", width: 10, height: 2, background: "#5b8def", marginRight: 6 }} />Actual (last 14 days)</span>
              <span><span style={{ display: "inline-block", width: 10, height: 2, background: "#2bc8a8", marginRight: 6 }} />Forecast (best model)</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
