import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  api,
  ApiError,
  Location,
  Department,
  ScheduleResult,
  ScheduleSummary,
  EmployeeDetail,
  ReoptimizePreview,
  DraftStatus,
} from "../lib/api";
import KpiCard from "../components/KpiCard";

const SHIFT_OPTIONS = [
  { id: 1, name: "Morning", label: "Morning (6-14)" },
  { id: 2, name: "Day", label: "Day (8-16)" },
  { id: 3, name: "Evening", label: "Evening (14-22)" },
  { id: 4, name: "Part-time", label: "Part-time (10-14)" },
];

function diffLine(label: string, before: number, after: number, lowerIsBetter = true, isCurrency = false, isPct = false) {
  const fmt = (v: number) => (isCurrency ? `$${v.toLocaleString()}` : isPct ? `${v.toFixed(1)}%` : v.toLocaleString());
  const changed = before !== after;
  const better = lowerIsBetter ? after < before : after > before;
  const color = !changed ? "var(--text-secondary)" : better ? "var(--signal-teal)" : "var(--signal-red)";
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", fontSize: 13 }}>
      <span className="muted-text">{label}</span>
      <span className="mono" style={{ color }}>
        {fmt(before)} {changed ? "→" : ""} {changed ? fmt(after) : ""}
      </span>
    </div>
  );
}

export default function Schedule() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedLoc, setSelectedLoc] = useState<number | null>(null);
  const [selectedDept, setSelectedDept] = useState<number | null>(null);

  const [hasRequirement, setHasRequirement] = useState<boolean | null>(null);
  const [result, setResult] = useState<ScheduleResult | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const [employeeFilter, setEmployeeFilter] = useState("");
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<number | null>(null);
  const [employeeDetail, setEmployeeDetail] = useState<EmployeeDetail | null>(null);

  // Local optimistic view of "which shift is this employee working on this date",
  // seeded from the persisted schedule and updated as staged edits are accepted.
  // Authoritative numbers (cost/coverage/overtime) always come from the backend's
  // draft baseline/working summaries, never recomputed here.
  const [effectiveShift, setEffectiveShift] = useState<Map<string, number | null>>(new Map());
  const [draft, setDraft] = useState<DraftStatus | null>(null);
  const [lastStageWarnings, setLastStageWarnings] = useState<string[]>([]);
  const [editErrors, setEditErrors] = useState<string[]>([]);

  const [reoptimizePreview, setReoptimizePreview] = useState<ReoptimizePreview | null>(null);

  const [generating, setGenerating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.locations(), api.departments()])
      .then(([locs, depts]) => {
        setLocations(locs);
        setDepartments(depts);
        if (locs.length && depts.length) {
          setSelectedLoc(locs[0].id);
          setSelectedDept(depts[0].id);
        }
      })
      .catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    if (selectedLoc && selectedDept) loadExisting();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLoc, selectedDept]);

  function keyFor(employeeId: number, date: string) {
    return `${employeeId}|${date}`;
  }

  async function loadExisting() {
    if (!selectedLoc || !selectedDept) return;
    setError(null);
    setResult(null);
    setReoptimizePreview(null);
    setSelectedEmployeeId(null);
    setEmployeeDetail(null);
    setEditErrors([]);
    setLastStageWarnings([]);
    try {
      await api.workforceRequirementResults(selectedLoc, selectedDept);
      setHasRequirement(true);
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 404) {
        setHasRequirement(false);
        return;
      }
      setError(e.message);
      return;
    }
    try {
      const sched = await api.scheduleResults(selectedLoc, selectedDept);
      setResult(sched);
      if (sched.coverage.length) setSelectedDate(sched.coverage[0].date);

      const map = new Map<string, number | null>();
      sched.assignments.forEach((a) => map.set(keyFor(a.employee_id, a.date), a.shift_id));

      const draftStatus = await api.draftStatus(selectedLoc, selectedDept);
      setDraft(draftStatus);
      if (draftStatus.has_unsaved_changes) {
        for (const c of draftStatus.changes) {
          map.set(keyFor(c.employee_id, c.date), c.new_shift_id);
        }
      }
      setEffectiveShift(map);
    } catch (e: any) {
      if (!(e instanceof ApiError && e.status === 404)) setError(e.message);
    }
  }

  async function handleGenerate() {
    if (!selectedLoc || !selectedDept) return;
    setGenerating(true);
    setError(null);
    try {
      const sched = await api.generateSchedule({
        location_id: selectedLoc, department_id: selectedDept,
        overtime_threshold_hours_per_week: 32, overtime_multiplier: 1.5,
      });
      setResult(sched);
      if (sched.coverage.length) setSelectedDate(sched.coverage[0].date);
      setReoptimizePreview(null);
      await loadExisting();
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setGenerating(false);
    }
  }

  const dateOptions = useMemo(() => {
    if (!result) return [];
    return Array.from(new Set(result.coverage.map((c) => c.date))).sort();
  }, [result]);

  const employeeIds = useMemo(() => {
    if (!result) return [];
    return Array.from(new Set(result.assignments.map((a) => a.employee_id)));
  }, [result]);

  const employeeNameById = useMemo(() => {
    const m = new Map<number, string>();
    result?.assignments.forEach((a) => m.set(a.employee_id, a.employee_name));
    return m;
  }, [result]);

  const filteredEmployeeIds = useMemo(() => {
    const q = employeeFilter.trim().toLowerCase();
    if (!q) return employeeIds;
    return employeeIds.filter((id) => (employeeNameById.get(id) ?? "").toLowerCase().includes(q));
  }, [employeeIds, employeeFilter, employeeNameById]);

  const dayCoverage = useMemo(() => {
    if (!result || !selectedDate) return [];
    return result.coverage.filter((c) => c.date === selectedDate).sort((a, b) => a.hour - b.hour);
  }, [result, selectedDate]);

  const gridRows = useMemo(() => {
    if (!result || !selectedDate) return [];
    return filteredEmployeeIds.map((eid) => {
      const shiftId = effectiveShift.get(keyFor(eid, selectedDate)) ?? null;
      const committedAssignment = result.assignments.find((a) => a.employee_id === eid && a.date === selectedDate);
      const isStaged = draft?.has_unsaved_changes && draft.changes.some((c) => c.employee_id === eid && c.date === selectedDate);
      return { employeeId: eid, name: employeeNameById.get(eid) ?? "Unknown", shiftId, committedAssignment, isStaged };
    });
  }, [result, selectedDate, filteredEmployeeIds, employeeNameById, effectiveShift, draft]);

  function coverageColor(c: { required: number; scheduled: number }) {
    if (c.required === 0) return "var(--panel-raised)";
    if (c.scheduled === 0) return "var(--signal-red)";
    const ratio = c.scheduled / c.required;
    if (ratio < 0.6) return "var(--signal-red)";
    if (ratio < 0.95) return "var(--signal-amber)";
    if (ratio <= 1.25) return "var(--signal-teal)";
    return "var(--accent-blue)";
  }

  async function handleShiftChange(employeeId: number, date: string, newShiftIdRaw: string) {
    if (!selectedLoc || !selectedDept) return;
    const newShiftId = newShiftIdRaw === "" ? null : Number(newShiftIdRaw);
    setBusy(true);
    setEditErrors([]);
    setLastStageWarnings([]);
    setError(null);
    try {
      const res = await api.stageChange({
        location_id: selectedLoc, department_id: selectedDept,
        employee_id: employeeId, date, shift_id: newShiftId,
      });
      if (!res.valid) {
        setEditErrors(res.errors);
        return;
      }
      setLastStageWarnings(res.warnings);
      setEffectiveShift((prev) => {
        const next = new Map(prev);
        next.set(keyFor(employeeId, date), newShiftId);
        return next;
      });
      const draftStatus = await api.draftStatus(selectedLoc, selectedDept);
      setDraft(draftStatus);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleSaveChanges() {
    if (!selectedLoc || !selectedDept) return;
    setBusy(true);
    setError(null);
    try {
      await api.saveDraft(selectedLoc, selectedDept);
      setLastStageWarnings([]);
      await loadExisting();
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleCancelChanges() {
    if (!selectedLoc || !selectedDept) return;
    setBusy(true);
    setError(null);
    try {
      await api.cancelDraft(selectedLoc, selectedDept);
      setLastStageWarnings([]);
      await loadExisting();
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleUndo() {
    if (!selectedLoc || !selectedDept) return;
    setBusy(true);
    setError(null);
    try {
      await api.undoScheduleChange(selectedLoc, selectedDept);
      await loadExisting();
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleRevert() {
    if (!selectedLoc || !selectedDept) return;
    setBusy(true);
    setError(null);
    try {
      await api.revertSchedule(selectedLoc, selectedDept);
      await loadExisting();
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handlePreviewReoptimize() {
    if (!selectedLoc || !selectedDept) return;
    setBusy(true);
    setError(null);
    try {
      const preview = await api.reoptimizePreview(selectedLoc, selectedDept);
      setReoptimizePreview(preview);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  async function openEmployeeDetail(employeeId: number) {
    if (!selectedLoc || !selectedDept) return;
    setSelectedEmployeeId(employeeId);
    setEmployeeDetail(null);
    try {
      const detail = await api.employeeDetail(employeeId, selectedLoc, selectedDept);
      setEmployeeDetail(detail);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    }
  }

  if (locations.length === 0) {
    return (
      <div>
        <div className="page-header">
          <div>
            <div className="page-eyebrow">Optimization</div>
            <h1 className="page-title">Manager Schedule</h1>
          </div>
        </div>
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">&#9671;</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>No data yet</div>
            <div style={{ fontSize: 13 }}>Generate sample data from the Dashboard first.</div>
          </div>
        </div>
      </div>
    );
  }

  const hasUnsaved = draft?.has_unsaved_changes ?? false;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Optimization</div>
          <h1 className="page-title">Manager Schedule</h1>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {hasUnsaved && <span className="status-pill critical">Unsaved changes</span>}
          {result?.feasible && !hasUnsaved && (
            <span className={`status-pill ${result.schedule_status === "modified" ? "attention" : "healthy"}`}>
              {result.schedule_status === "modified" ? "Modified" : "Optimized"}
            </span>
          )}
        </div>
      </div>

      <div className="panel">
        <div style={{ display: "flex", gap: 16, alignItems: "flex-end", flexWrap: "wrap" }}>
          <div className="field-group">
            <label className="field-label" htmlFor="loc-select">Location</label>
            <select id="loc-select" value={selectedLoc ?? ""} onChange={(e) => setSelectedLoc(Number(e.target.value))}>
              {locations.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
            </select>
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="dept-select">Department</label>
            <select id="dept-select" value={selectedDept ?? ""} onChange={(e) => setSelectedDept(Number(e.target.value))}>
              {departments.map((d) => (<option key={d.id} value={d.id}>{d.name}</option>))}
            </select>
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="date-select">Date</label>
            <select id="date-select" value={selectedDate ?? ""} onChange={(e) => setSelectedDate(e.target.value)}>
              {dateOptions.map((d) => (<option key={d} value={d}>{d}</option>))}
            </select>
          </div>
          <div className="field-group" style={{ flex: 1, minWidth: 160 }}>
            <label className="field-label" htmlFor="emp-search">Search employee</label>
            <input
              id="emp-search" type="text" placeholder="Type a name…" value={employeeFilter}
              onChange={(e) => setEmployeeFilter(e.target.value)}
              style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: "100%" }}
            />
          </div>
          <button className="btn btn-primary" onClick={handleGenerate} disabled={generating || hasRequirement === false}>
            {generating ? "Solving…" : "Generate optimized schedule"}
          </button>
        </div>
      </div>

      {error && (
        <div className="panel" style={{ borderColor: "var(--signal-red)" }}>
          <span style={{ color: "var(--signal-red)" }}>Error: {error}</span>
        </div>
      )}

      {hasRequirement === false && (
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">~</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
              No workforce requirement yet for this location/department
            </div>
            <div style={{ fontSize: 13, marginBottom: 14 }}>
              The optimizer schedules against required headcount by hour — generate that first.
            </div>
            <Link to="/workforce" className="btn btn-primary">Go to Workforce Requirement →</Link>
          </div>
        </div>
      )}

      {result && !result.feasible && (
        <div className="panel" style={{ borderColor: "var(--signal-red)" }}>
          <span className="status-pill critical">No feasible schedule</span>
          <div style={{ marginTop: 10, fontSize: 13.5 }}>{result.infeasibility_reason}</div>
          <div className="muted-text" style={{ fontSize: 11.5, marginTop: 10 }}>
            Status: {result.status}. No schedule was fabricated — this is the solver's honest answer.
          </div>
        </div>
      )}

      {result && result.feasible && result.summary && (
        <>
          <div className="kpi-row">
            <KpiCard label="Scheduled employees" value={String(employeeIds.length)} />
            <KpiCard label="Total labor cost" value={`$${result.summary.total_labor_cost.toLocaleString()}`} />
            <KpiCard label="Total shifts" value={String(result.summary.total_shifts)} />
            <KpiCard label="Overtime hours" value={String(result.summary.overtime_hours)} />
            <KpiCard label="Avg coverage" value={`${result.summary.avg_coverage_pct.toFixed(1)}%`} />
            <KpiCard label="Understaffed hours" value={String(result.summary.understaffed_hours)} />
          </div>

          <div className="panel">
            <div className="panel-title-row">
              <div className="panel-title">Hourly coverage — {selectedDate}</div>
            </div>
            <div style={{ display: "flex", gap: 1, height: 40, borderRadius: 6, overflow: "hidden" }}>
              {dayCoverage.map((c) => (
                <div key={c.hour} title={`${c.hour}:00 — required ${c.required}, scheduled ${c.scheduled}`}
                  style={{ flex: 1, background: coverageColor(c) }} />
              ))}
            </div>
            <div style={{ display: "flex", gap: 16, marginTop: 10, fontSize: 11.5 }}>
              <span><span style={{ display: "inline-block", width: 10, height: 10, background: "var(--signal-red)", marginRight: 6, borderRadius: 2 }} />Understaffed</span>
              <span><span style={{ display: "inline-block", width: 10, height: 10, background: "var(--signal-amber)", marginRight: 6, borderRadius: 2 }} />Slightly under</span>
              <span><span style={{ display: "inline-block", width: 10, height: 10, background: "var(--signal-teal)", marginRight: 6, borderRadius: 2 }} />On target</span>
              <span><span style={{ display: "inline-block", width: 10, height: 10, background: "var(--accent-blue)", marginRight: 6, borderRadius: 2 }} />Overstaffed</span>
            </div>
          </div>

          <div className="panel">
            <div className="panel-title-row">
              <div className="panel-title">Editable schedule grid — {selectedDate}</div>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn" onClick={handleUndo} disabled={busy}>Undo last saved edit</button>
                <button className="btn" onClick={handleRevert} disabled={busy}>Revert to optimized</button>
                <button className="btn" onClick={handlePreviewReoptimize} disabled={busy}>Re-optimize (preview)</button>
              </div>
            </div>

            {editErrors.length > 0 && (
              <div style={{ marginBottom: 12, padding: 10, borderRadius: 6, background: "var(--signal-red-dim)" }}>
                {editErrors.map((e, i) => (
                  <div key={i} style={{ fontSize: 12.5, color: "var(--signal-red)" }}>{e}</div>
                ))}
              </div>
            )}
            {lastStageWarnings.length > 0 && (
              <div style={{ marginBottom: 12, padding: 10, borderRadius: 6, background: "var(--signal-amber-dim)" }}>
                {lastStageWarnings.map((w, i) => (
                  <div key={i} style={{ fontSize: 12.5, color: "var(--signal-amber)" }}>⚠ {w}</div>
                ))}
              </div>
            )}

            <table className="data-table">
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Shift</th>
                  <th>Hours</th>
                  <th>Cost</th>
                  <th>Overtime</th>
                </tr>
              </thead>
              <tbody>
                {gridRows.map((row) => {
                  const shiftDef = SHIFT_OPTIONS.find((s) => s.id === row.shiftId);
                  return (
                    <tr key={row.employeeId} style={row.isStaged ? { background: "var(--signal-amber-dim)" } : undefined}>
                      <td>
                        <button
                          onClick={() => openEmployeeDetail(row.employeeId)}
                          style={{ background: "none", border: "none", color: "var(--accent-blue)", cursor: "pointer", padding: 0, fontFamily: "var(--font-display)", fontSize: 13 }}
                        >
                          {row.name}
                        </button>
                        {row.isStaged && <span className="status-pill attention" style={{ marginLeft: 8 }}>Staged</span>}
                      </td>
                      <td>
                        <select
                          value={row.shiftId ?? ""}
                          disabled={busy}
                          onChange={(e) => handleShiftChange(row.employeeId, selectedDate!, e.target.value)}
                        >
                          <option value="">— Off —</option>
                          {SHIFT_OPTIONS.map((s) => (
                            <option key={s.id} value={s.id}>{s.label}</option>
                          ))}
                        </select>
                      </td>
                      <td>{shiftDef ? shiftDef.label.match(/\((\d+)-(\d+)\)/) ? Number(shiftDef.label.match(/\((\d+)-(\d+)\)/)![2]) - Number(shiftDef.label.match(/\((\d+)-(\d+)\)/)![1]) : "—" : "—"}</td>
                      <td className="muted-text" style={{ fontSize: 11.5 }}>
                        {row.isStaged ? "pending save" : row.committedAssignment ? `$${row.committedAssignment.cost.toFixed(2)}` : "—"}
                      </td>
                      <td>{row.committedAssignment?.is_overtime && !row.isStaged ? <span className="status-pill attention">OT</span> : "—"}</td>
                    </tr>
                  );
                })}
                {gridRows.length === 0 && (
                  <tr><td colSpan={5} className="muted-text">No employees match this filter.</td></tr>
                )}
              </tbody>
            </table>
          </div>

          {hasUnsaved && draft && draft.baseline && draft.working && (
            <div className="panel" style={{ borderColor: "var(--signal-amber)" }}>
              <div className="panel-title-row">
                <div className="panel-title">Unsaved changes — {draft.changes.length} staged edit(s)</div>
              </div>
              {diffLine("Labor cost", draft.baseline.total_labor_cost, draft.working.total_labor_cost, true, true)}
              {diffLine("Coverage", draft.baseline.avg_coverage_pct, draft.working.avg_coverage_pct, false, false, true)}
              {diffLine("Overtime hours", draft.baseline.overtime_hours, draft.working.overtime_hours, true)}
              {diffLine("Understaffed hours", draft.baseline.understaffed_hours, draft.working.understaffed_hours, true)}
              <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                <button className="btn btn-primary" onClick={handleSaveChanges} disabled={busy}>Save changes</button>
                <button className="btn" onClick={handleCancelChanges} disabled={busy}>Cancel changes</button>
              </div>
            </div>
          )}

          {reoptimizePreview && (
            <div className="panel" style={{ borderColor: "var(--accent-blue)" }}>
              <div className="panel-title-row">
                <div className="panel-title">Re-optimize preview: current vs. proposed</div>
              </div>
              {reoptimizePreview.feasible && reoptimizePreview.current && reoptimizePreview.proposed ? (
                <>
                  {diffLine("Labor cost", reoptimizePreview.current.total_labor_cost, reoptimizePreview.proposed.total_labor_cost, true, true)}
                  {diffLine("Coverage", reoptimizePreview.current.avg_coverage_pct, reoptimizePreview.proposed.avg_coverage_pct, false, false, true)}
                  {diffLine("Overtime hours", reoptimizePreview.current.overtime_hours, reoptimizePreview.proposed.overtime_hours, true)}
                  {diffLine("Understaffed hours", reoptimizePreview.current.understaffed_hours, reoptimizePreview.proposed.understaffed_hours, true)}
                  <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                    <button className="btn btn-primary" onClick={handleGenerate} disabled={busy}>Replace with re-optimized schedule</button>
                    <button className="btn" onClick={() => setReoptimizePreview(null)} disabled={busy}>Keep current</button>
                  </div>
                </>
              ) : (
                <div style={{ fontSize: 13, color: "var(--signal-red)" }}>{reoptimizePreview.infeasibility_reason}</div>
              )}
            </div>
          )}

          {selectedEmployeeId && (
            <div className="panel" style={{ borderColor: "var(--border-strong)" }}>
              <div className="panel-title-row">
                <div className="panel-title">Employee detail</div>
                <button className="btn" onClick={() => setSelectedEmployeeId(null)}>Close</button>
              </div>
              {!employeeDetail ? (
                <div className="muted-text">Loading…</div>
              ) : (
                <div>
                  <div style={{ display: "flex", gap: 24, marginBottom: 14, flexWrap: "wrap" }}>
                    <div><div className="field-label">Name</div><div>{employeeDetail.name}</div></div>
                    <div><div className="field-label">Type</div><div>{employeeDetail.employment_type}</div></div>
                    <div><div className="field-label">Hourly cost</div><div>${employeeDetail.hourly_cost.toFixed(2)}</div></div>
                    <div><div className="field-label">Max hours</div><div>{employeeDetail.max_daily_hours}/day, {employeeDetail.max_weekly_hours}/wk</div></div>
                    <div><div className="field-label">Preferred shift</div><div>{employeeDetail.preferred_shift ?? "—"}</div></div>
                    <div><div className="field-label">Skills</div><div>{employeeDetail.skills.join(", ") || "—"}</div></div>
                  </div>
                  <div className="kpi-row">
                    <KpiCard label="Total hours (horizon)" value={String(employeeDetail.total_hours)} />
                    <KpiCard label="Total cost" value={`$${employeeDetail.total_cost.toFixed(2)}`} />
                    <KpiCard label="Overtime shifts" value={String(employeeDetail.overtime_shifts)} />
                    <KpiCard label="Preference conflicts" value={String(employeeDetail.preference_conflicts)} />
                  </div>
                  <table className="data-table">
                    <thead><tr><th>Date</th><th>Shift</th><th>Hours</th><th>Cost</th><th>OT</th></tr></thead>
                    <tbody>
                      {employeeDetail.assigned_shifts.map((s, i) => (
                        <tr key={i}>
                          <td>{s.date}</td>
                          <td>{s.shift_name} ({s.start_hour}:00–{s.end_hour}:00)</td>
                          <td>{s.hours}</td>
                          <td>${s.cost.toFixed(2)}</td>
                          <td>{s.is_overtime ? <span className="status-pill attention">OT</span> : "—"}</td>
                        </tr>
                      ))}
                      {employeeDetail.assigned_shifts.length === 0 && (
                        <tr><td colSpan={5} className="muted-text">Not scheduled this horizon.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
