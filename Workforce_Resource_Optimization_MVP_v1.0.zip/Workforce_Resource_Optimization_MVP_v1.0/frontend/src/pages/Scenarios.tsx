import { useEffect, useState } from "react";
import { api, ApiError, Location, Department, ScenarioRunResult, ScenarioListEntry } from "../lib/api";
import KpiCard from "../components/KpiCard";

const PRESETS = [
  { label: "Demand +10%", demand: 0.10, absenteeism: 0, productivity: 0, cost: 0 },
  { label: "Demand +20%", demand: 0.20, absenteeism: 0, productivity: 0, cost: 0 },
  { label: "Demand -10%", demand: -0.10, absenteeism: 0, productivity: 0, cost: 0 },
  { label: "Absenteeism +10%", demand: 0, absenteeism: 0.10, productivity: 0, cost: 0 },
  { label: "Productivity -10%", demand: 0, absenteeism: 0, productivity: -0.10, cost: 0 },
  { label: "Labor cost +5%", demand: 0, absenteeism: 0, productivity: 0, cost: 0.05 },
];

function diffRow(label: string, before: number, after: number, opts: { currency?: boolean; pct?: boolean; lowerIsBetter?: boolean } = {}) {
  const { currency, pct, lowerIsBetter = true } = opts;
  const fmt = (v: number) => (currency ? `$${v.toLocaleString()}` : pct ? `${v.toFixed(1)}%` : v.toLocaleString());
  const delta = after - before;
  const changed = Math.abs(delta) > 0.001;
  const better = lowerIsBetter ? delta < 0 : delta > 0;
  const color = !changed ? "var(--text-secondary)" : better ? "var(--signal-teal)" : "var(--signal-red)";
  return (
    <tr>
      <td className="muted-text">{label}</td>
      <td className="mono">{fmt(before)}</td>
      <td className="mono">{fmt(after)}</td>
      <td className="mono" style={{ color }}>{changed ? (delta > 0 ? "+" : "") + fmt(delta) : "—"}</td>
    </tr>
  );
}

export default function Scenarios() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedLoc, setSelectedLoc] = useState<number | null>(null);
  const [selectedDept, setSelectedDept] = useState<number | null>(null);

  const [demandPct, setDemandPct] = useState(0);
  const [absenteeismPct, setAbsenteeismPct] = useState(0);
  const [productivityPct, setProductivityPct] = useState(0);
  const [costPct, setCostPct] = useState(0);
  const [scenarioName, setScenarioName] = useState("");

  const [hasRequirement, setHasRequirement] = useState<boolean | null>(null);
  const [result, setResult] = useState<ScenarioRunResult | null>(null);
  const [history, setHistory] = useState<ScenarioListEntry[]>([]);

  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.locations(), api.departments()])
      .then(([locs, depts]) => {
        setLocations(locs);
        setDepartments(depts);
        if (locs.length && depts.length) {
          setSelectedLoc(locs[0].id);
          setSelectedDept(depts[0].id);
        }
      })
      .catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    if (selectedLoc && selectedDept) loadContext();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLoc, selectedDept]);

  async function loadContext() {
    if (!selectedLoc || !selectedDept) return;
    setError(null);
    setResult(null);
    try {
      await api.workforceRequirementResults(selectedLoc, selectedDept);
      setHasRequirement(true);
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 404) {
        setHasRequirement(false);
        return;
      }
      setError(e.message);
      return;
    }
    try {
      const list = await api.scenarioResults(selectedLoc, selectedDept);
      setHistory(list);
    } catch (e: any) {
      setError(e.message);
    }
  }

  function applyPreset(p: (typeof PRESETS)[number]) {
    setDemandPct(p.demand * 100);
    setAbsenteeismPct(p.absenteeism * 100);
    setProductivityPct(p.productivity * 100);
    setCostPct(p.cost * 100);
    setScenarioName(p.label);
  }

  async function handleRun() {
    if (!selectedLoc || !selectedDept) return;
    setRunning(true);
    setError(null);
    try {
      const res = await api.runScenario({
        location_id: selectedLoc, department_id: selectedDept,
        demand_delta_pct: demandPct / 100, absenteeism_delta_pct: absenteeismPct / 100,
        productivity_delta_pct: productivityPct / 100, cost_delta_pct: costPct / 100,
        name: scenarioName || undefined,
      });
      setResult(res);
      const list = await api.scenarioResults(selectedLoc, selectedDept);
      setHistory(list);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setRunning(false);
    }
  }

  if (locations.length === 0) {
    return (
      <div>
        <div className="page-header">
          <div>
            <div className="page-eyebrow">Planning</div>
            <h1 className="page-title">What-If Scenarios</h1>
          </div>
        </div>
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">&#9671;</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>No data yet</div>
            <div style={{ fontSize: 13 }}>Generate sample data from the Dashboard first.</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Planning</div>
          <h1 className="page-title">What-If Scenarios</h1>
        </div>
      </div>

      <div className="panel">
        <div style={{ display: "flex", gap: 16, alignItems: "flex-end", flexWrap: "wrap", marginBottom: 16 }}>
          <div className="field-group">
            <label className="field-label" htmlFor="loc-select">Location</label>
            <select id="loc-select" value={selectedLoc ?? ""} onChange={(e) => setSelectedLoc(Number(e.target.value))}>
              {locations.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
            </select>
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="dept-select">Department</label>
            <select id="dept-select" value={selectedDept ?? ""} onChange={(e) => setSelectedDept(Number(e.target.value))}>
              {departments.map((d) => (<option key={d.id} value={d.id}>{d.name}</option>))}
            </select>
          </div>
        </div>

        <div className="field-label" style={{ marginBottom: 8 }}>Quick presets</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 }}>
          {PRESETS.map((p) => (
            <button key={p.label} className="btn" onClick={() => applyPreset(p)}>{p.label}</button>
          ))}
        </div>

        <div style={{ display: "flex", gap: 20, flexWrap: "wrap", alignItems: "flex-end" }}>
          <div className="field-group">
            <label className="field-label" htmlFor="demand-input">Demand change (%)</label>
            <input id="demand-input" type="number" step={5} value={demandPct} onChange={(e) => setDemandPct(Number(e.target.value))}
              style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 100, fontFamily: "var(--font-mono)" }} />
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="absenteeism-input">Absenteeism change (pts)</label>
            <input id="absenteeism-input" type="number" step={1} value={absenteeismPct} onChange={(e) => setAbsenteeismPct(Number(e.target.value))}
              style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 100, fontFamily: "var(--font-mono)" }} />
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="productivity-input">Productivity change (%)</label>
            <input id="productivity-input" type="number" step={5} value={productivityPct} onChange={(e) => setProductivityPct(Number(e.target.value))}
              style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 100, fontFamily: "var(--font-mono)" }} />
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="cost-input">Labor cost change (%)</label>
            <input id="cost-input" type="number" step={5} value={costPct} onChange={(e) => setCostPct(Number(e.target.value))}
              style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 100, fontFamily: "var(--font-mono)" }} />
          </div>
          <div className="field-group" style={{ flex: 1, minWidth: 160 }}>
            <label className="field-label" htmlFor="name-input">Scenario name</label>
            <input id="name-input" type="text" placeholder="e.g. Holiday peak" value={scenarioName} onChange={(e) => setScenarioName(e.target.value)}
              style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: "100%" }} />
          </div>
          <button className="btn btn-primary" onClick={handleRun} disabled={running || hasRequirement === false}>
            {running ? "Running scenario…" : "Run scenario"}
          </button>
        </div>
      </div>

      {error && (
        <div className="panel" style={{ borderColor: "var(--signal-red)" }}>
          <span style={{ color: "var(--signal-red)" }}>Error: {error}</span>
        </div>
      )}

      {hasRequirement === false && (
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">~</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
              No workforce requirement yet
            </div>
            <div style={{ fontSize: 13 }}>Scenarios perturb the real requirement/schedule — generate one first.</div>
          </div>
        </div>
      )}

      {result && (
        <>
          <div className="panel" style={{ borderColor: "var(--accent-blue)" }}>
            <div className="panel-title-row">
              <div className="panel-title">{result.name}</div>
            </div>
            <div style={{ fontSize: 14, marginBottom: 16, color: "var(--text-primary)" }}>{result.executive_summary}</div>

            <div className="kpi-row">
              <KpiCard label="Additional headcount" value={`${result.delta.additional_headcount >= 0 ? "+" : ""}${result.delta.additional_headcount}`} />
              <KpiCard label="Additional labor cost" value={`${result.delta.additional_labor_cost >= 0 ? "+" : "-"}$${Math.abs(result.delta.additional_labor_cost).toLocaleString()}`} />
              <KpiCard label="Coverage impact" value={`${result.delta.coverage_pct_delta >= 0 ? "+" : ""}${result.delta.coverage_pct_delta.toFixed(1)}%`} />
              <KpiCard label="Overtime hours impact" value={`${result.delta.overtime_hours_delta >= 0 ? "+" : ""}${result.delta.overtime_hours_delta}`} />
            </div>

            <table className="data-table">
              <thead>
                <tr><th>Metric</th><th>Base case</th><th>Scenario</th><th>Change</th></tr>
              </thead>
              <tbody>
                {diffRow("Peak required headcount", result.base.requirement.peak_required_headcount, result.scenario.requirement.peak_required_headcount)}
                {diffRow("Avg required headcount", result.base.requirement.avg_required_headcount, result.scenario.requirement.avg_required_headcount)}
                {diffRow("Total labor hours needed", result.base.requirement.total_labor_hours, result.scenario.requirement.total_labor_hours)}
                {result.base.schedule && result.scenario.schedule && (
                  <>
                    {diffRow("Labor cost", result.base.schedule.total_labor_cost, result.scenario.schedule.total_labor_cost, { currency: true })}
                    {diffRow("Coverage", result.base.schedule.avg_coverage_pct, result.scenario.schedule.avg_coverage_pct, { pct: true, lowerIsBetter: false })}
                    {diffRow("Overtime hours", result.base.schedule.overtime_hours, result.scenario.schedule.overtime_hours)}
                    {diffRow("Understaffed hours", result.base.schedule.understaffed_hours, result.scenario.schedule.understaffed_hours)}
                    {diffRow("Overstaffed hours", result.base.schedule.overstaffed_hours, result.scenario.schedule.overstaffed_hours)}
                  </>
                )}
              </tbody>
            </table>

            {!result.scenario.feasible && (
              <div style={{ marginTop: 12, padding: 10, borderRadius: 6, background: "var(--signal-red-dim)", fontSize: 12.5, color: "var(--signal-red)" }}>
                Scenario schedule is infeasible: {result.scenario.infeasibility_reason}
              </div>
            )}
            {result.base.schedule && result.scenario.schedule && result.scenario.schedule.total_labor_cost === result.base.schedule.total_labor_cost && result.delta.additional_headcount > 0 && (
              <div className="muted-text" style={{ marginTop: 12, fontSize: 11.5 }}>
                Note: labor cost didn't change because the optimizer can only schedule from the current employee pool —
                meeting the extra {result.delta.additional_headcount} required heads would mean hiring, which this
                comparison doesn't model. The headcount gap above is the real signal to act on.
              </div>
            )}
          </div>
        </>
      )}

      {history.length > 0 && (
        <div className="panel">
          <div className="panel-title-row">
            <div className="panel-title">Scenario history</div>
          </div>
          <table className="data-table">
            <thead>
              <tr><th>Name</th><th>Demand</th><th>Absenteeism</th><th>Productivity</th><th>Cost</th><th>Δ Headcount</th><th>Δ Labor cost</th><th></th></tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.scenario_id}>
                  <td style={{ fontFamily: "var(--font-display)" }}>{h.name}</td>
                  <td>{h.demand_delta_pct !== 0 ? `${(h.demand_delta_pct * 100).toFixed(0)}%` : "—"}</td>
                  <td>{h.absenteeism_delta_pct !== 0 ? `${(h.absenteeism_delta_pct * 100).toFixed(0)}pts` : "—"}</td>
                  <td>{h.productivity_delta_pct !== 0 ? `${(h.productivity_delta_pct * 100).toFixed(0)}%` : "—"}</td>
                  <td>{h.cost_delta_pct !== 0 ? `${(h.cost_delta_pct * 100).toFixed(0)}%` : "—"}</td>
                  <td>{h.delta ? (h.delta.additional_headcount >= 0 ? "+" : "") + h.delta.additional_headcount : "—"}</td>
                  <td>{h.delta ? `${h.delta.additional_labor_cost >= 0 ? "+" : "-"}$${Math.abs(h.delta.additional_labor_cost).toLocaleString()}` : "—"}</td>
                  <td><a className="btn" style={{ padding: "4px 10px", fontSize: 11.5 }} href={api.exportScenarioUrl(h.scenario_id)}>Export</a></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
