import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import {
  api,
  ApiError,
  Location,
  Department,
  ForecastResult,
  WorkforceRequirementResult,
} from "../lib/api";
import KpiCard from "../components/KpiCard";

export default function Workforce() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedLoc, setSelectedLoc] = useState<number | null>(null);
  const [selectedDept, setSelectedDept] = useState<number | null>(null);

  const [forecast, setForecast] = useState<ForecastResult | null>(null);
  const [result, setResult] = useState<WorkforceRequirementResult | null>(null);
  const [noForecast, setNoForecast] = useState(false);

  const [productivity, setProductivity] = useState<number>(8);
  const [absencePct, setAbsencePct] = useState<number>(5);
  const [breaksPct, setBreaksPct] = useState<number>(5);
  const [trainingPct, setTrainingPct] = useState<number>(3);
  const [otherPct, setOtherPct] = useState<number>(0);

  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.locations(), api.departments()])
      .then(([locs, depts]) => {
        setLocations(locs);
        setDepartments(depts);
        if (locs.length && depts.length) {
          setSelectedLoc(locs[0].id);
          setSelectedDept(depts[0].id);
          setProductivity(depts[0].default_productivity_per_hour);
        }
      })
      .catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    if (selectedLoc && selectedDept) {
      loadExisting();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLoc, selectedDept]);

  async function loadExisting() {
    if (!selectedLoc || !selectedDept) return;
    setError(null);
    setNoForecast(false);
    setResult(null);
    try {
      const fc = await api.forecastResults(selectedLoc, selectedDept);
      setForecast(fc);
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 404) {
        setNoForecast(true);
        setForecast(null);
        return;
      }
      setError(e.message);
      return;
    }
    try {
      const wr = await api.workforceRequirementResults(selectedLoc, selectedDept);
      setResult(wr);
    } catch (e: any) {
      if (!(e instanceof ApiError && e.status === 404)) {
        setError(e.message);
      }
    }
  }

  async function handleGenerate() {
    if (!selectedLoc || !selectedDept) return;
    setGenerating(true);
    setError(null);
    try {
      const wr = await api.generateWorkforceRequirement({
        location_id: selectedLoc,
        department_id: selectedDept,
        productivity_per_hour: productivity,
        absence_pct: absencePct / 100,
        breaks_pct: breaksPct / 100,
        training_pct: trainingPct / 100,
        other_pct: otherPct / 100,
      });
      setResult(wr);
    } catch (e: any) {
      if (e instanceof ApiError) {
        setError(e.message);
      } else {
        setError(String(e));
      }
    } finally {
      setGenerating(false);
    }
  }

  const totalShrinkage = absencePct + breaksPct + trainingPct + otherPct;

  const chartData = (result?.points ?? []).map((p) => ({
    label: new Date(p.timestamp).toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "numeric",
    }),
    demand: p.forecast_demand,
    base: p.base_headcount,
    required: p.required_headcount,
  }));

  if (locations.length === 0) {
    return (
      <div>
        <div className="page-header">
          <div>
            <div className="page-eyebrow">Capacity Planning</div>
            <h1 className="page-title">Workforce Requirement</h1>
          </div>
        </div>
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">&#9671;</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
              No data yet
            </div>
            <div style={{ fontSize: 13 }}>Generate sample data from the Dashboard first.</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Capacity Planning</div>
          <h1 className="page-title">Workforce Requirement</h1>
        </div>
      </div>

      <div className="panel">
        <div style={{ display: "flex", gap: 20, alignItems: "flex-end", flexWrap: "wrap" }}>
          <div className="field-group">
            <label className="field-label" htmlFor="loc-select">Location</label>
            <select id="loc-select" value={selectedLoc ?? ""} onChange={(e) => setSelectedLoc(Number(e.target.value))}>
              {locations.map((l) => (
                <option key={l.id} value={l.id}>{l.name}</option>
              ))}
            </select>
          </div>
          <div className="field-group">
            <label className="field-label" htmlFor="dept-select">Department</label>
            <select
              id="dept-select"
              value={selectedDept ?? ""}
              onChange={(e) => {
                const id = Number(e.target.value);
                setSelectedDept(id);
                const dept = departments.find((d) => d.id === id);
                if (dept) setProductivity(dept.default_productivity_per_hour);
              }}
            >
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="panel" style={{ borderColor: "var(--signal-red)" }}>
          <span style={{ color: "var(--signal-red)" }}>Error: {error}</span>
        </div>
      )}

      {noForecast && (
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">~</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
              No forecast yet for this location/department
            </div>
            <div style={{ fontSize: 13, marginBottom: 14 }}>
              Workforce requirement is derived from the demand forecast — generate one first.
            </div>
            <Link to="/forecast" className="btn btn-primary">Go to Forecast →</Link>
          </div>
        </div>
      )}

      {forecast && (
        <div className="panel">
          <div className="panel-title-row">
            <div className="panel-title">Assumptions</div>
            <span className="faint-text mono" style={{ fontSize: 11 }}>
              Forecast: {forecast.horizon_days}-day horizon, {forecast.forecast_points.length} hourly points
            </span>
          </div>
          <div style={{ display: "flex", gap: 24, flexWrap: "wrap", alignItems: "flex-end" }}>
            <div className="field-group">
              <label className="field-label" htmlFor="productivity-input">Productivity (units/employee/hour)</label>
              <input
                id="productivity-input"
                type="number"
                min={0.1}
                step={0.5}
                value={productivity}
                onChange={(e) => setProductivity(Number(e.target.value))}
                style={{
                  background: "var(--panel-raised)", border: "1px solid var(--border)",
                  color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 140,
                  fontFamily: "var(--font-mono)",
                }}
              />
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="absence-input">Absence %</label>
              <input
                id="absence-input" type="number" min={0} max={90} step={1} value={absencePct}
                onChange={(e) => setAbsencePct(Number(e.target.value))}
                style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 90, fontFamily: "var(--font-mono)" }}
              />
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="breaks-input">Breaks %</label>
              <input
                id="breaks-input" type="number" min={0} max={90} step={1} value={breaksPct}
                onChange={(e) => setBreaksPct(Number(e.target.value))}
                style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 90, fontFamily: "var(--font-mono)" }}
              />
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="training-input">Training %</label>
              <input
                id="training-input" type="number" min={0} max={90} step={1} value={trainingPct}
                onChange={(e) => setTrainingPct(Number(e.target.value))}
                style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 90, fontFamily: "var(--font-mono)" }}
              />
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="other-input">Other %</label>
              <input
                id="other-input" type="number" min={0} max={90} step={1} value={otherPct}
                onChange={(e) => setOtherPct(Number(e.target.value))}
                style={{ background: "var(--panel-raised)", border: "1px solid var(--border)", color: "var(--text-primary)", padding: "7px 10px", borderRadius: 6, width: 90, fontFamily: "var(--font-mono)" }}
              />
            </div>
            <div className="field-group">
              <div className="field-label">Total shrinkage</div>
              <div
                className="mono"
                style={{
                  fontSize: 18, fontWeight: 600,
                  color: totalShrinkage >= 100 ? "var(--signal-red)" : "var(--text-primary)",
                }}
              >
                {totalShrinkage.toFixed(0)}%
              </div>
            </div>
            <button className="btn btn-primary" onClick={handleGenerate} disabled={generating || totalShrinkage >= 100}>
              {generating ? "Calculating…" : "Calculate requirement"}
            </button>
          </div>
          {totalShrinkage >= 100 && (
            <div style={{ marginTop: 10, fontSize: 12.5, color: "var(--signal-red)" }}>
              Total shrinkage must be under 100% — at or above that, no finite headcount can cover demand.
            </div>
          )}
          <div className="muted-text" style={{ fontSize: 11.5, marginTop: 12 }}>
            Formula: base = ceil(demand ÷ productivity); required = ceil(base ÷ (1 − total shrinkage)).
          </div>
        </div>
      )}

      {result && (
        <>
          <div className="kpi-row">
            <KpiCard label="Peak required headcount" value={String(result.summary.peak_required_headcount)} />
            <KpiCard label="Avg required headcount" value={result.summary.avg_required_headcount.toFixed(1)} />
            <KpiCard label="Total labor hours" value={result.summary.total_labor_hours.toLocaleString()} />
            <KpiCard label="Hours covered" value={String(result.summary.hours_covered)} />
          </div>

          <div className="panel">
            <div className="panel-title-row">
              <div className="panel-title">Demand vs required headcount</div>
              <span className="faint-text mono" style={{ fontSize: 11 }}>
                productivity {result.productivity_per_hour}/hr · shrinkage {(result.shrinkage_pct * 100).toFixed(0)}%
              </span>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <ComposedChart data={chartData}>
                <CartesianGrid stroke="#262f36" strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: "#7c8b93", fontSize: 10 }}
                  interval={Math.max(1, Math.floor(chartData.length / 8))}
                  axisLine={{ stroke: "#262f36" }}
                  tickLine={false}
                />
                <YAxis yAxisId="left" tick={{ fill: "#7c8b93", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right" tick={{ fill: "#7c8b93", fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: "#1b2329", border: "1px solid #262f36", borderRadius: 6, fontSize: 12 }}
                  labelStyle={{ color: "#e8edf0" }}
                />
                <Area yAxisId="left" type="monotone" dataKey="demand" stroke="#5b8def" fill="#5b8def" fillOpacity={0.12} strokeWidth={1.5} name="Forecast demand" />
                <Line yAxisId="right" type="stepAfter" dataKey="required" stroke="#2bc8a8" strokeWidth={2} dot={false} name="Required headcount" />
              </ComposedChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", gap: 16, marginTop: 10, fontSize: 12 }}>
              <span><span style={{ display: "inline-block", width: 10, height: 2, background: "#5b8def", marginRight: 6 }} />Forecast demand (left axis)</span>
              <span><span style={{ display: "inline-block", width: 10, height: 2, background: "#2bc8a8", marginRight: 6 }} />Required headcount (right axis)</span>
            </div>
          </div>

          <div className="panel">
            <div className="panel-title-row">
              <div className="panel-title">Hourly breakdown (first 24 hours)</div>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Hour</th>
                  <th>Forecast demand</th>
                  <th>Base headcount</th>
                  <th>Required headcount</th>
                </tr>
              </thead>
              <tbody>
                {result.points.slice(0, 24).map((p) => (
                  <tr key={p.timestamp}>
                    <td>{new Date(p.timestamp).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric" })}</td>
                    <td>{p.forecast_demand.toFixed(1)}</td>
                    <td>{p.base_headcount}</td>
                    <td style={{ color: "var(--signal-teal)", fontWeight: 600 }}>{p.required_headcount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
