import { useEffect, useState } from "react";
import { api, ApiError, Location, Department, ImportPreviewResult } from "../lib/api";

const DATA_TYPES = [
  { value: "demand", label: "Historical Demand", hint: "date, location, department, demand" },
  { value: "employees", label: "Employees", hint: "employee_id, name, location, department, hourly_cost" },
  { value: "availability", label: "Employee Availability", hint: "employee_id, day_of_week (0-6), start_hour, end_hour" },
  { value: "skills", label: "Employee Skills", hint: "employee_id, skill" },
  { value: "productivity", label: "Productivity Assumptions", hint: "department, productivity_per_hour" },
];

export default function DataManagement() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedLoc, setSelectedLoc] = useState<number | null>(null);
  const [selectedDept, setSelectedDept] = useState<number | null>(null);

  const [dataType, setDataType] = useState("demand");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<ImportPreviewResult | null>(null);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [previewing, setPreviewing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ imported_rows: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [resetting, setResetting] = useState(false);

  useEffect(() => {
    Promise.all([api.locations(), api.departments()])
      .then(([locs, depts]) => {
        setLocations(locs);
        setDepartments(depts);
        if (locs.length && depts.length) {
          setSelectedLoc(locs[0].id);
          setSelectedDept(depts[0].id);
        }
      })
      .catch(() => { /* fine if empty on first run */ });
  }, []);

  async function handlePreview() {
    if (!file) return;
    setPreviewing(true);
    setError(null);
    setImportResult(null);
    try {
      const result = await api.previewImport(dataType, file);
      setPreview(result);
      setMapping(result.suggested_mapping);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
      setPreview(null);
    } finally {
      setPreviewing(false);
    }
  }

  async function handleReRunPreviewWithMapping() {
    if (!file) return;
    setPreviewing(true);
    setError(null);
    try {
      const result = await api.previewImport(dataType, file, mapping);
      setPreview(result);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setPreviewing(false);
    }
  }

  async function handleCommit() {
    if (!file || !preview) return;
    setImporting(true);
    setError(null);
    try {
      const result = await api.commitImport(dataType, file, mapping);
      setImportResult(result);
      setPreview(null);
      setFile(null);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setImporting(false);
    }
  }

  async function handleLoadDemoData() {
    setResetting(true);
    setError(null);
    try {
      await api.generateData({
        days_of_history: 90, num_locations: 2, num_departments: 3, employees_per_location_dept: 5,
      });
      const [locs, depts] = await Promise.all([api.locations(), api.departments()]);
      setLocations(locs);
      setDepartments(depts);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setResetting(false);
    }
  }

  function handleResetDemoData() {
    if (!window.confirm("This will permanently delete all current data (demand history, employees, forecasts, schedules, scenarios) and replace it with a fresh synthetic demo dataset. This cannot be undone. Continue?")) {
      return;
    }
    handleLoadDemoData();
  }

  const currentTypeInfo = DATA_TYPES.find((t) => t.value === dataType)!;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Data Management</div>
          <h1 className="page-title">Import, Validate &amp; Export</h1>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title-row"><div className="panel-title">Demo data</div></div>
        <div style={{ fontSize: 13, marginBottom: 14, color: "var(--text-secondary)" }}>
          Use the built-in synthetic dataset to try the application immediately, or reset it at any time.
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-primary" onClick={handleLoadDemoData} disabled={resetting}>
            {resetting ? "Loading…" : "Load Demo Data"}
          </button>
          <button className="btn" onClick={handleResetDemoData} disabled={resetting}>
            Reset Demo Data
          </button>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title-row"><div className="panel-title">Upload real data</div></div>
        <div style={{ display: "flex", gap: 16, flexWrap: "wrap", alignItems: "flex-end", marginBottom: 16 }}>
          <div className="field-group">
            <label className="field-label" htmlFor="type-select">Data type</label>
            <select id="type-select" value={dataType} onChange={(e) => { setDataType(e.target.value); setPreview(null); setImportResult(null); }}>
              {DATA_TYPES.map((t) => (<option key={t.value} value={t.value}>{t.label}</option>))}
            </select>
          </div>
          <div className="field-group" style={{ flex: 1, minWidth: 240 }}>
            <label className="field-label" htmlFor="file-input">CSV or Excel (.xlsx) file</label>
            <input
              id="file-input" type="file" accept=".csv,.xlsx,.xls"
              onChange={(e) => { setFile(e.target.files?.[0] ?? null); setPreview(null); setImportResult(null); }}
              style={{ fontSize: 13 }}
            />
          </div>
          <button className="btn btn-primary" onClick={handlePreview} disabled={!file || previewing}>
            {previewing ? "Validating…" : "Validate"}
          </button>
        </div>
        <div className="muted-text" style={{ fontSize: 11.5 }}>
          Expected fields for "{currentTypeInfo.label}": {currentTypeInfo.hint}
        </div>
      </div>

      {error && (
        <div className="panel" style={{ borderColor: "var(--signal-red)" }}>
          <span style={{ color: "var(--signal-red)" }}>Error: {error}</span>
        </div>
      )}

      {preview && (
        <div className="panel">
          <div className="panel-title-row"><div className="panel-title">Validation report</div></div>

          <div className="kpi-row" style={{ marginBottom: 16 }}>
            <div className="kpi-card">
              <div className="kpi-label">Valid rows</div>
              <div className="kpi-value" style={{ color: "var(--signal-teal)" }}>{preview.valid_rows}</div>
              <div className="kpi-sub">of {preview.total_rows} total</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Warnings</div>
              <div className="kpi-value" style={{ color: preview.warnings.length ? "var(--signal-amber)" : undefined }}>{preview.warnings.length}</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Errors</div>
              <div className="kpi-value" style={{ color: preview.errors.length ? "var(--signal-red)" : undefined }}>{preview.errors.length}</div>
            </div>
          </div>

          {preview.warnings.length > 0 && (
            <div style={{ marginBottom: 12, padding: 10, borderRadius: 6, background: "var(--signal-amber-dim)" }}>
              {preview.warnings.map((w, i) => (<div key={i} style={{ fontSize: 12.5, color: "var(--signal-amber)" }}>{w}</div>))}
            </div>
          )}
          {preview.errors.length > 0 && (
            <div style={{ marginBottom: 12, padding: 10, borderRadius: 6, background: "var(--signal-red-dim)" }}>
              {preview.errors.map((e, i) => (<div key={i} style={{ fontSize: 12.5, color: "var(--signal-red)" }}>{e}</div>))}
            </div>
          )}

          <div className="panel-title" style={{ marginBottom: 10 }}>Column mapping</div>
          <table className="data-table" style={{ marginBottom: 14 }}>
            <thead><tr><th>Internal field</th><th>Uploaded column</th></tr></thead>
            <tbody>
              {Object.keys({ ...preview.suggested_mapping, ...mapping }).map((field) => (
                <tr key={field}>
                  <td className="mono">{field}</td>
                  <td>
                    <select
                      value={mapping[field] ?? ""}
                      onChange={(e) => setMapping((m) => ({ ...m, [field]: e.target.value }))}
                    >
                      <option value="">— not mapped —</option>
                      {preview.detected_columns.map((c) => (<option key={c} value={c}>{c}</option>))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn" onClick={handleReRunPreviewWithMapping} disabled={previewing}>Re-validate with this mapping</button>
            <button className="btn btn-primary" onClick={handleCommit} disabled={importing || preview.valid_rows === 0}>
              {importing ? "Importing…" : `Import ${preview.valid_rows} valid row(s)`}
            </button>
          </div>
          {preview.valid_rows === 0 && (
            <div className="muted-text" style={{ fontSize: 11.5, marginTop: 8 }}>
              No valid rows to import — fix the errors above and re-upload.
            </div>
          )}
        </div>
      )}

      {importResult && (
        <div className="panel" style={{ borderColor: "var(--signal-teal)" }}>
          <span className="status-pill healthy">Import complete</span>
          <div style={{ marginTop: 10, fontSize: 13.5 }}>{importResult.imported_rows} row(s) imported successfully.</div>
        </div>
      )}

      {locations.length > 0 && (
        <div className="panel">
          <div className="panel-title-row"><div className="panel-title">Export results</div></div>
          <div style={{ display: "flex", gap: 16, alignItems: "flex-end", flexWrap: "wrap", marginBottom: 14 }}>
            <div className="field-group">
              <label className="field-label" htmlFor="exp-loc">Location</label>
              <select id="exp-loc" value={selectedLoc ?? ""} onChange={(e) => setSelectedLoc(Number(e.target.value))}>
                {locations.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
              </select>
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="exp-dept">Department</label>
              <select id="exp-dept" value={selectedDept ?? ""} onChange={(e) => setSelectedDept(Number(e.target.value))}>
                {departments.map((d) => (<option key={d.id} value={d.id}>{d.name}</option>))}
              </select>
            </div>
          </div>
          {selectedLoc && selectedDept && (
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <a className="btn" href={api.exportUrl("forecast", selectedLoc, selectedDept)}>Export Forecast (CSV)</a>
              <a className="btn" href={api.exportUrl("requirement", selectedLoc, selectedDept)}>Export Workforce Requirement (CSV)</a>
              <a className="btn" href={api.exportUrl("schedule", selectedLoc, selectedDept)}>Export Schedule (CSV)</a>
              <a className="btn" href={api.exportUrl("executive-summary", selectedLoc, selectedDept)}>Export Executive KPI Summary (CSV)</a>
            </div>
          )}
          <div className="muted-text" style={{ fontSize: 11.5, marginTop: 10 }}>
            Export links download whatever has already been generated — if a forecast, requirement,
            or schedule hasn't been created yet for this location/department, that download will report so.
          </div>
        </div>
      )}
    </div>
  );
}
