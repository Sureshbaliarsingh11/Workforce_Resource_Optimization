import { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";
import {
  api,
  ApiError,
  DashboardSummary,
  Location,
  Department,
  ExecutiveDashboardResult,
} from "../lib/api";
import KpiCard from "../components/KpiCard";

const SEVERITY_CLASS: Record<string, string> = {
  high: "critical",
  medium: "attention",
  low: "pending",
};

export default function Dashboard() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedLoc, setSelectedLoc] = useState<number | null>(null);
  const [selectedDept, setSelectedDept] = useState<number | null>(null);
  const [horizonDays, setHorizonDays] = useState<7 | 14>(7);

  const [exec, setExec] = useState<ExecutiveDashboardResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadAll() {
    setLoading(true);
    setError(null);
    try {
      const s = await api.dashboard();
      setSummary(s);
      if (s.total_locations > 0) {
        const [locs, depts] = await Promise.all([api.locations(), api.departments()]);
        setLocations(locs);
        setDepartments(depts);
        if (locs.length && depts.length) {
          setSelectedLoc(locs[0].id);
          setSelectedDept(depts[0].id);
        }
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
  }, []);

  useEffect(() => {
    if (selectedLoc && selectedDept) {
      loadExecutive();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLoc, selectedDept, horizonDays]);

  async function loadExecutive() {
    if (!selectedLoc || !selectedDept) return;
    try {
      const result = await api.executiveDashboard(selectedLoc, selectedDept, horizonDays);
      setExec(result);
    } catch (e: any) {
      setError(e instanceof ApiError ? e.message : String(e));
    }
  }

  async function handleGenerate() {
    setGenerating(true);
    setError(null);
    try {
      await api.generateData({
        days_of_history: 90,
        num_locations: 2,
        num_departments: 3,
        employees_per_location_dept: 5,
      });
      await loadAll();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setGenerating(false);
    }
  }

  const demandChartData = useMemo(() => {
    if (!exec) return [];
    const map = new Map<string, { time: string; actual?: number; forecast?: number }>();
    for (const p of exec.demand_outlook.actual) {
      map.set(p.timestamp, { time: p.timestamp, actual: p.demand });
    }
    for (const p of exec.demand_outlook.forecast) {
      const existing = map.get(p.timestamp) ?? { time: p.timestamp };
      existing.forecast = p.predicted_demand;
      map.set(p.timestamp, existing);
    }
    return Array.from(map.values())
      .sort((a, b) => a.time.localeCompare(b.time))
      .map((d) => ({
        ...d,
        label: new Date(d.time).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric" }),
      }));
  }, [exec]);

  const boundaryLabel = exec?.demand_outlook.actual.length
    ? new Date(exec.demand_outlook.actual[exec.demand_outlook.actual.length - 1].timestamp).toLocaleString(undefined, {
        month: "short", day: "numeric", hour: "numeric",
      })
    : undefined;

  const capacityChartData = useMemo(() => {
    if (!exec?.workforce_capacity) return [];
    return exec.workforce_capacity.coverage.map((c) => ({
      label: `${c.date} ${c.hour}:00`,
      required: c.required,
      scheduled: c.scheduled,
    }));
  }, [exec]);

  if (loading && !summary) {
    return <div className="muted-text">Loading…</div>;
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Executive Control Tower</div>
          <h1 className="page-title">Executive Dashboard</h1>
        </div>
        <button className="btn btn-primary" onClick={handleGenerate} disabled={generating}>
          {generating ? "Generating…" : summary && summary.total_locations > 0 ? "Regenerate sample data" : "Generate sample data"}
        </button>
      </div>

      {error && (
        <div className="panel" style={{ borderColor: "var(--signal-red)" }}>
          <span style={{ color: "var(--signal-red)" }}>Error: {error}</span>
        </div>
      )}

      {!loading && summary && summary.total_locations === 0 && (
        <div className="panel">
          <div className="empty-state">
            <div className="icon-mark">&#9671;</div>
            <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6, color: "var(--text-primary)" }}>
              No data yet
            </div>
            <div style={{ fontSize: 13, marginBottom: 18 }}>
              Generate a synthetic dataset — 2 locations, 3 departments, ~30 employees,
              90 days of hourly demand — to populate the executive dashboard.
            </div>
            <button className="btn btn-primary" onClick={handleGenerate} disabled={generating}>
              {generating ? "Generating…" : "Generate sample data"}
            </button>
          </div>
        </div>
      )}

      {summary && summary.total_locations > 0 && (
        <>
          <div className="panel">
            <div style={{ display: "flex", gap: 16, alignItems: "flex-end", flexWrap: "wrap" }}>
              <div className="field-group">
                <label className="field-label" htmlFor="loc-select">Location</label>
                <select id="loc-select" value={selectedLoc ?? ""} onChange={(e) => setSelectedLoc(Number(e.target.value))}>
                  {locations.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
                </select>
              </div>
              <div className="field-group">
                <label className="field-label" htmlFor="dept-select">Department</label>
                <select id="dept-select" value={selectedDept ?? ""} onChange={(e) => setSelectedDept(Number(e.target.value))}>
                  {departments.map((d) => (<option key={d.id} value={d.id}>{d.name}</option>))}
                </select>
              </div>
              <div className="field-group">
                <label className="field-label" htmlFor="horizon-select">Horizon</label>
                <select id="horizon-select" value={horizonDays} onChange={(e) => setHorizonDays(Number(e.target.value) as 7 | 14)}>
                  <option value={7}>7 days</option>
                  <option value={14}>14 days</option>
                </select>
              </div>
            </div>
          </div>

          {exec && (
            <>
              {/* Executive KPI layer */}
              <div className="kpi-row">
                <KpiCard label="Forecast accuracy" value={exec.kpis.forecast_accuracy_pct !== null ? `${exec.kpis.forecast_accuracy_pct.toFixed(1)}%` : "—"} muted={exec.kpis.forecast_accuracy_pct === null} />
                <KpiCard label="WAPE" value={exec.kpis.wape_pct !== null ? `${exec.kpis.wape_pct.toFixed(1)}%` : "—"} muted={exec.kpis.wape_pct === null} />
                <KpiCard label="Required headcount (peak)" value={exec.kpis.required_peak_headcount !== null ? String(exec.kpis.required_peak_headcount) : "—"} muted={exec.kpis.required_peak_headcount === null} />
                <KpiCard label="Scheduled employees" value={String(exec.kpis.scheduled_employees)} />
                <KpiCard label="Coverage" value={exec.kpis.avg_coverage_pct !== null ? `${exec.kpis.avg_coverage_pct.toFixed(1)}%` : "—"} muted={exec.kpis.avg_coverage_pct === null} />
                <KpiCard label="Understaffed hours" value={exec.kpis.understaffed_hours !== null ? String(exec.kpis.understaffed_hours) : "—"} muted={exec.kpis.understaffed_hours === null} />
                <KpiCard label="Overstaffed hours" value={exec.kpis.overstaffed_hours !== null ? String(exec.kpis.overstaffed_hours) : "—"} muted={exec.kpis.overstaffed_hours === null} />
                <KpiCard label="Labor cost" value={exec.kpis.labor_cost !== null ? `$${exec.kpis.labor_cost.toLocaleString()}` : "—"} muted={exec.kpis.labor_cost === null} />
                <KpiCard label="Overtime hours" value={exec.kpis.overtime_hours !== null ? String(exec.kpis.overtime_hours) : "—"} muted={exec.kpis.overtime_hours === null} />
                <KpiCard label="Estimated savings" value={exec.kpis.estimated_savings !== null ? `$${exec.kpis.estimated_savings.toLocaleString()}` : "—"} muted={exec.kpis.estimated_savings === null} />
              </div>

              {/* Management alerts */}
              {exec.alerts.length > 0 && (
                <div className="panel">
                  <div className="panel-title-row"><div className="panel-title">Management alerts</div></div>
                  {exec.alerts.map((a, i) => (
                    <div key={i} style={{ display: "flex", gap: 10, alignItems: "center", padding: "8px 0", borderBottom: i < exec.alerts.length - 1 ? "1px solid var(--border)" : "none" }}>
                      <span className={`status-pill ${SEVERITY_CLASS[a.severity]}`}>{a.severity}</span>
                      <span style={{ fontSize: 13 }}>{a.message}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Recommendations */}
              {exec.recommendations.length > 0 && (
                <div className="panel">
                  <div className="panel-title-row"><div className="panel-title">Recommendations</div></div>
                  <ul style={{ margin: 0, paddingLeft: 20, fontSize: 13, lineHeight: 1.8 }}>
                    {exec.recommendations.map((r, i) => (<li key={i}>{r}</li>))}
                  </ul>
                </div>
              )}

              {/* Demand outlook */}
              <div className="panel">
                <div className="panel-title-row"><div className="panel-title">Demand outlook</div></div>
                <div style={{ fontSize: 13.5, marginBottom: 14, color: "var(--text-primary)" }}>
                  {exec.demand_outlook.insight.message}
                </div>
                <ResponsiveContainer width="100%" height={240}>
                  <ComposedChart data={demandChartData}>
                    <CartesianGrid stroke="#262f36" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="label" tick={{ fill: "#7c8b93", fontSize: 10 }} interval={Math.max(1, Math.floor(demandChartData.length / 8))} axisLine={{ stroke: "#262f36" }} tickLine={false} />
                    <YAxis tick={{ fill: "#7c8b93", fontSize: 10 }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ background: "#1b2329", border: "1px solid #262f36", borderRadius: 6, fontSize: 12 }} labelStyle={{ color: "#e8edf0" }} />
                    {boundaryLabel && <ReferenceLine x={boundaryLabel} stroke="#7c8b93" strokeDasharray="2 2" />}
                    <Line type="monotone" dataKey="actual" stroke="#5b8def" strokeWidth={2} dot={false} name="Actual" />
                    <Line type="monotone" dataKey="forecast" stroke="#2bc8a8" strokeWidth={2} strokeDasharray="5 3" dot={false} name="Forecast" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Workforce capacity */}
              {exec.workforce_capacity && (
                <div className="panel">
                  <div className="panel-title-row">
                    <div className="panel-title">Workforce capacity</div>
                    <span className="faint-text mono" style={{ fontSize: 11 }}>{exec.workforce_capacity.available_employees} available employees</span>
                  </div>
                  <ResponsiveContainer width="100%" height={220}>
                    <ComposedChart data={capacityChartData}>
                      <CartesianGrid stroke="#262f36" strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="label" tick={{ fill: "#7c8b93", fontSize: 9 }} interval={Math.max(1, Math.floor(capacityChartData.length / 6))} axisLine={{ stroke: "#262f36" }} tickLine={false} />
                      <YAxis tick={{ fill: "#7c8b93", fontSize: 10 }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{ background: "#1b2329", border: "1px solid #262f36", borderRadius: 6, fontSize: 12 }} labelStyle={{ color: "#e8edf0" }} />
                      <ReferenceLine y={exec.workforce_capacity.available_employees} stroke="#7c8b93" strokeDasharray="2 2" label={{ value: "Available", position: "insideTopRight", fill: "#7c8b93", fontSize: 10 }} />
                      <Area type="monotone" dataKey="required" stroke="#5b8def" fill="#5b8def" fillOpacity={0.12} strokeWidth={1.5} name="Required" />
                      <Line type="stepAfter" dataKey="scheduled" stroke="#2bc8a8" strokeWidth={2} dot={false} name="Scheduled" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              )}

              {/* Labor cost */}
              <div className="panel">
                <div className="panel-title-row"><div className="panel-title">Labor cost</div></div>
                {!exec.labor_cost.available ? (
                  <div className="muted-text" style={{ fontSize: 13 }}>{exec.labor_cost.message}</div>
                ) : (
                  <>
                    <div className="kpi-row">
                      <KpiCard label="Current labor cost" value={`$${(exec.labor_cost.current_labor_cost ?? 0).toLocaleString()}`} />
                      <KpiCard label="Overtime cost" value={`$${(exec.labor_cost.overtime_cost ?? 0).toLocaleString()}`} />
                      <KpiCard label="Cost per hour" value={exec.labor_cost.cost_per_hour != null ? `$${exec.labor_cost.cost_per_hour.toFixed(2)}` : "—"} muted={exec.labor_cost.cost_per_hour == null} />
                      <KpiCard label="Cost per transaction" value={exec.labor_cost.cost_per_transaction != null ? `$${exec.labor_cost.cost_per_transaction.toFixed(3)}` : "—"} muted={exec.labor_cost.cost_per_transaction == null} />
                    </div>
                    {exec.labor_cost.cost_trend && exec.labor_cost.cost_trend.length > 0 && (
                      <ResponsiveContainer width="100%" height={180}>
                        <ComposedChart data={exec.labor_cost.cost_trend}>
                          <CartesianGrid stroke="#262f36" strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="date" tick={{ fill: "#7c8b93", fontSize: 10 }} axisLine={{ stroke: "#262f36" }} tickLine={false} />
                          <YAxis tick={{ fill: "#7c8b93", fontSize: 10 }} axisLine={false} tickLine={false} />
                          <Tooltip contentStyle={{ background: "#1b2329", border: "1px solid #262f36", borderRadius: 6, fontSize: 12 }} labelStyle={{ color: "#e8edf0" }} />
                          <Line type="monotone" dataKey="cost" stroke="#eea23c" strokeWidth={2} dot={{ r: 3 }} name="Daily cost" />
                        </ComposedChart>
                      </ResponsiveContainer>
                    )}
                  </>
                )}
              </div>

              {/* Optimization impact */}
              <div className="panel">
                <div className="panel-title-row"><div className="panel-title">Optimization impact</div></div>
                {!exec.optimization_impact.available ? (
                  <div className="muted-text" style={{ fontSize: 13 }}>{exec.optimization_impact.message}</div>
                ) : (
                  <>
                    <table className="data-table">
                      <thead><tr><th>Metric</th><th>Before (optimized)</th><th>After (modified)</th></tr></thead>
                      <tbody>
                        <tr><td>Labor cost</td><td>${exec.optimization_impact.before!.total_labor_cost.toLocaleString()}</td><td>${exec.optimization_impact.after!.total_labor_cost.toLocaleString()}</td></tr>
                        <tr><td>Labor hours</td><td>{exec.optimization_impact.before!.total_labor_hours}</td><td>{exec.optimization_impact.after!.total_labor_hours}</td></tr>
                        <tr><td>Overtime hours</td><td>{exec.optimization_impact.before!.overtime_hours}</td><td>{exec.optimization_impact.after!.overtime_hours}</td></tr>
                        <tr><td>Coverage</td><td>{exec.optimization_impact.before!.avg_coverage_pct.toFixed(1)}%</td><td>{exec.optimization_impact.after!.avg_coverage_pct.toFixed(1)}%</td></tr>
                        <tr><td>Understaffed hours</td><td>{exec.optimization_impact.before!.understaffed_hours}</td><td>{exec.optimization_impact.after!.understaffed_hours}</td></tr>
                      </tbody>
                    </table>
                    <div className="muted-text" style={{ fontSize: 12, marginTop: 10 }}>
                      Estimated impact: {exec.optimization_impact.estimated_savings! >= 0 ? "savings of" : "additional cost of"}{" "}
                      ${Math.abs(exec.optimization_impact.estimated_savings!).toLocaleString()}
                      {exec.optimization_impact.savings_pct != null ? ` (${exec.optimization_impact.savings_pct.toFixed(1)}%)` : ""}.
                    </div>
                  </>
                )}
              </div>

              {/* What-if summary */}
              <div className="panel">
                <div className="panel-title-row"><div className="panel-title">Latest what-if scenario</div></div>
                {!exec.whatif_summary.available ? (
                  <div className="muted-text" style={{ fontSize: 13 }}>{exec.whatif_summary.message}</div>
                ) : (
                  <div style={{ fontSize: 13.5 }}>{exec.whatif_summary.scenario!.executive_summary}</div>
                )}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
