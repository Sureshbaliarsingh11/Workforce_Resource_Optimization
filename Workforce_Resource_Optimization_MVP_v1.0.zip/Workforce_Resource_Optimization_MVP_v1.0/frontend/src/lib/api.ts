export interface Location {
  id: number;
  name: string;
  region: string;
}

export interface Department {
  id: number;
  name: string;
  default_productivity_per_hour: number;
}

export interface Employee {
  id: number;
  name: string;
  location_id: number;
  department_id: number;
  employment_type: string;
  hourly_cost: number;
  max_weekly_hours: number;
  max_daily_hours: number;
  preferred_shift: string | null;
  active: boolean;
}

export interface DemandPoint {
  timestamp: string;
  demand: number;
  is_holiday: boolean;
  is_promotion: boolean;
}

export interface DashboardSummary {
  total_locations: number;
  total_departments: number;
  total_employees: number;
  total_demand_last_7_days: number;
  avg_hourly_demand_last_7_days: number;
  peak_hourly_demand_last_7_days: number;
  data_days_available: number;
  has_forecast: boolean;
  has_workforce_requirement: boolean;
  has_schedule: boolean;
}

export interface GenerateDataResponse {
  locations_created: number;
  departments_created: number;
  employees_created: number;
  demand_rows_created: number;
  date_range_start: string;
  date_range_end: string;
}

export interface ModelComparisonEntry {
  model_name: string;
  wape: number | null;
  mae: number | null;
  rmse: number | null;
  bias: number | null;
  rank: number | null;
  is_best: boolean;
  folds_evaluated: number;
}

export interface ForecastPoint {
  timestamp: string;
  model_name: string;
  predicted_demand: number;
  is_best_model: boolean;
}

export interface ForecastResult {
  location_id: number;
  department_id: number;
  horizon_days: number;
  best_model: string | null;
  folds_evaluated: number;
  model_comparison: ModelComparisonEntry[];
  forecast_points: ForecastPoint[];
  generated_at: string;
}

export interface WorkforceRequirementPoint {
  timestamp: string;
  forecast_demand: number;
  productivity_per_hour: number;
  shrinkage_pct: number;
  base_headcount: number;
  required_headcount: number;
}

export interface WorkforceRequirementSummary {
  peak_required_headcount: number;
  avg_required_headcount: number;
  total_labor_hours: number;
  hours_covered: number;
}

export interface WorkforceRequirementResult {
  location_id: number;
  department_id: number;
  productivity_per_hour: number;
  shrinkage_pct: number;
  shrinkage_breakdown: {
    absence_pct: number;
    breaks_pct: number;
    training_pct: number;
    other_pct: number;
  } | null;
  summary: WorkforceRequirementSummary;
  points: WorkforceRequirementPoint[];
  generated_at: string;
}

export interface ScheduleAssignment {
  employee_id: number;
  employee_name: string;
  date: string;
  shift_id: number;
  shift_name: string;
  start_hour: number;
  end_hour: number;
  hours: number;
  cost: number;
  is_overtime: boolean;
}

export interface CoveragePoint {
  date: string;
  hour: number;
  required: number;
  scheduled: number;
  understaffed: number;
  overstaffed: number;
}

export interface ScheduleSummary {
  total_labor_cost: number;
  total_shifts: number;
  overtime_shifts: number;
  overtime_hours: number;
  avg_coverage_pct: number;
  understaffed_hours: number;
  overstaffed_hours: number;
  total_hours_covered: number;
}

export interface ScheduleResult {
  location_id: number;
  department_id: number;
  feasible: boolean;
  status: string;
  schedule_status: "optimized" | "modified" | null;
  infeasibility_reason: string | null;
  assignments: ScheduleAssignment[];
  summary: ScheduleSummary | null;
  coverage: CoveragePoint[];
  generated_at: string;
}

export interface ScheduleChangeResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  before: ScheduleSummary | null;
  after: ScheduleSummary | null;
}

export interface StagedChange {
  employee_id: number;
  date: string;
  old_shift_id: number | null;
  new_shift_id: number | null;
  staged_at: string;
}

export interface DraftStatus {
  has_unsaved_changes: boolean;
  changes: StagedChange[];
  baseline: ScheduleSummary | null;
  working: ScheduleSummary | null;
}

export interface StageChangeResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  before: ScheduleSummary | null;
  after: ScheduleSummary | null;
  has_unsaved_changes: boolean;
}

export interface EmployeeAvailabilitySlot {
  day_of_week: number;
  start_hour: number;
  end_hour: number;
}

export interface EmployeeAssignedShift {
  date: string;
  shift_name: string;
  start_hour: number;
  end_hour: number;
  hours: number;
  cost: number;
  is_overtime: boolean;
}

export interface EmployeeDetail {
  employee_id: number;
  name: string;
  employment_type: string;
  hourly_cost: number;
  max_daily_hours: number;
  max_weekly_hours: number;
  preferred_shift: string | null;
  skills: string[];
  availability: EmployeeAvailabilitySlot[];
  assigned_shifts: EmployeeAssignedShift[];
  total_hours: number;
  total_cost: number;
  overtime_shifts: number;
  preference_conflicts: number;
}

export interface ReoptimizePreview {
  feasible: boolean;
  infeasibility_reason: string | null;
  current: ScheduleSummary | null;
  proposed: ScheduleSummary | null;
}

export interface ScenarioRequirementSummary {
  peak_required_headcount: number;
  avg_required_headcount: number;
  total_labor_hours: number;
  hours_covered: number;
}

export interface ScenarioScheduleSummary {
  total_labor_cost: number;
  total_shifts: number;
  overtime_shifts: number;
  overtime_hours: number;
  avg_coverage_pct: number;
  understaffed_hours: number;
  overstaffed_hours: number;
}

export interface ScenarioSide {
  requirement: ScenarioRequirementSummary;
  schedule: ScenarioScheduleSummary | null;
  feasible: boolean;
  infeasibility_reason: string | null;
}

export interface ScenarioDelta {
  additional_headcount: number;
  additional_labor_hours: number;
  additional_labor_cost: number;
  overtime_hours_delta: number;
  coverage_pct_delta: number;
  understaffed_hours_delta: number;
}

export interface ScenarioRunResult {
  scenario_id: number;
  name: string;
  inputs: {
    demand_delta_pct: number;
    absenteeism_delta_pct: number;
    productivity_delta_pct: number;
    cost_delta_pct: number;
  };
  base: ScenarioSide;
  scenario: ScenarioSide;
  delta: ScenarioDelta;
  executive_summary: string;
  generated_at: string;
}

export interface ScenarioListEntry {
  scenario_id: number;
  name: string;
  created_at: string;
  demand_delta_pct: number;
  absenteeism_delta_pct: number;
  productivity_delta_pct: number;
  cost_delta_pct: number;
  delta: ScenarioDelta | null;
  executive_summary: string | null;
}

export interface ExecutiveKpis {
  forecast_accuracy_pct: number | null;
  wape_pct: number | null;
  required_peak_headcount: number | null;
  scheduled_employees: number;
  available_employees: number;
  avg_coverage_pct: number | null;
  understaffed_hours: number | null;
  overstaffed_hours: number | null;
  labor_cost: number | null;
  overtime_hours: number | null;
  estimated_savings: number | null;
}

export interface DemandInsight {
  available: boolean;
  message: string;
  pct_change?: number | null;
  peak_window?: { start_hour: number; end_hour: number; delta: number } | null;
  forecast_avg?: number;
  recent_actual_avg?: number;
}

export interface ExecutiveDashboardResult {
  location: { id: number; name: string } | null;
  department: { id: number; name: string } | null;
  horizon_days: number;
  kpis: ExecutiveKpis;
  demand_outlook: {
    insight: DemandInsight;
    actual: { timestamp: string; demand: number }[];
    forecast: { timestamp: string; predicted_demand: number }[];
  };
  workforce_capacity: { coverage: CoveragePoint[]; available_employees: number } | null;
  labor_cost: {
    available: boolean;
    message?: string;
    current_labor_cost?: number;
    overtime_cost?: number;
    cost_per_hour?: number | null;
    cost_per_transaction?: number | null;
    cost_trend?: { date: string; cost: number }[];
  };
  optimization_impact: {
    available: boolean;
    message?: string;
    before?: Record<string, number>;
    after?: Record<string, number>;
    estimated_savings?: number;
    savings_pct?: number | null;
    coverage_improvement_pct?: number;
  };
  whatif_summary: { available: boolean; message?: string; scenario?: ScenarioListEntry };
  alerts: { severity: "high" | "medium" | "low"; message: string }[];
  recommendations: string[];
  generated_at: string;
}

export interface ImportPreviewResult {
  data_type: string;
  detected_columns: string[];
  suggested_mapping: Record<string, string>;
  total_rows: number;
  valid_rows: number;
  errors: string[];
  warnings: string[];
}

export interface ImportCommitResult {
  imported_rows: number;
  total_rows: number;
  errors: string[];
  warnings: string[];
}

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    const body = await res.text();
    let detail = body;
    try {
      detail = JSON.parse(body).detail ?? body;
    } catch {
      // body wasn't JSON; use as-is
    }
    throw new ApiError(res.status, detail);
  }
  return res.json() as Promise<T>;
}

export const api = {
  health: () => req<{ status: string; phase: number }>("/health"),
  generateData: (params: {
    days_of_history?: number;
    num_locations?: number;
    num_departments?: number;
    employees_per_location_dept?: number;
    seed?: number;
  }) =>
    req<GenerateDataResponse>("/data/generate", {
      method: "POST",
      body: JSON.stringify(params),
    }),
  dashboard: () => req<DashboardSummary>("/dashboard"),
  locations: () => req<Location[]>("/locations"),
  departments: () => req<Department[]>("/departments"),
  employees: (params?: { location_id?: number; department_id?: number }) => {
    const qs = new URLSearchParams();
    if (params?.location_id) qs.set("location_id", String(params.location_id));
    if (params?.department_id) qs.set("department_id", String(params.department_id));
    const suffix = qs.toString() ? `?${qs.toString()}` : "";
    return req<Employee[]>(`/employees${suffix}`);
  },
  demand: (locationId: number, departmentId: number, days = 14) =>
    req<DemandPoint[]>(
      `/demand?location_id=${locationId}&department_id=${departmentId}&days=${days}`
    ),
  generateForecast: (locationId: number, departmentId: number, horizonDays: 7 | 14) =>
    req<ForecastResult>("/forecast", {
      method: "POST",
      body: JSON.stringify({
        location_id: locationId,
        department_id: departmentId,
        horizon_days: horizonDays,
      }),
    }),
  forecastResults: (locationId: number, departmentId: number) =>
    req<ForecastResult>(`/forecast/results?location_id=${locationId}&department_id=${departmentId}`),
  generateWorkforceRequirement: (params: {
    location_id: number;
    department_id: number;
    productivity_per_hour?: number;
    absence_pct: number;
    breaks_pct: number;
    training_pct: number;
    other_pct: number;
  }) =>
    req<WorkforceRequirementResult>("/workforce/requirement", {
      method: "POST",
      body: JSON.stringify(params),
    }),
  workforceRequirementResults: (locationId: number, departmentId: number) =>
    req<WorkforceRequirementResult>(
      `/workforce/requirement/results?location_id=${locationId}&department_id=${departmentId}`
    ),
  generateSchedule: (params: {
    location_id: number;
    department_id: number;
    overtime_threshold_hours_per_week: number;
    overtime_multiplier: number;
  }) =>
    req<ScheduleResult>("/schedule/generate", {
      method: "POST",
      body: JSON.stringify(params),
    }),
  scheduleResults: (locationId: number, departmentId: number) =>
    req<ScheduleResult>(`/schedule/results?location_id=${locationId}&department_id=${departmentId}`),
  validateScheduleChange: (params: {
    location_id: number;
    department_id: number;
    employee_id: number;
    date: string;
    shift_id: number | null;
  }) =>
    req<ScheduleChangeResult>("/schedule/validate-change", {
      method: "POST",
      body: JSON.stringify(params),
    }),
  updateScheduleAssignment: (params: {
    location_id: number;
    department_id: number;
    employee_id: number;
    date: string;
    shift_id: number | null;
  }) =>
    req<ScheduleChangeResult>("/schedule/assignment", {
      method: "PUT",
      body: JSON.stringify(params),
    }),
  undoScheduleChange: (locationId: number, departmentId: number) =>
    req<ScheduleResult>("/schedule/undo", {
      method: "POST",
      body: JSON.stringify({ location_id: locationId, department_id: departmentId }),
    }),
  revertSchedule: (locationId: number, departmentId: number) =>
    req<ScheduleResult>("/schedule/revert", {
      method: "POST",
      body: JSON.stringify({ location_id: locationId, department_id: departmentId }),
    }),
  reoptimizePreview: (locationId: number, departmentId: number) =>
    req<ReoptimizePreview>("/schedule/reoptimize-preview", {
      method: "POST",
      body: JSON.stringify({ location_id: locationId, department_id: departmentId }),
    }),
  employeeDetail: (employeeId: number, locationId: number, departmentId: number) =>
    req<EmployeeDetail>(`/schedule/employee/${employeeId}?location_id=${locationId}&department_id=${departmentId}`),
  stageChange: (params: {
    location_id: number;
    department_id: number;
    employee_id: number;
    date: string;
    shift_id: number | null;
  }) =>
    req<StageChangeResult>("/schedule/stage-change", {
      method: "POST",
      body: JSON.stringify(params),
    }),
  draftStatus: (locationId: number, departmentId: number) =>
    req<DraftStatus>(`/schedule/draft?location_id=${locationId}&department_id=${departmentId}`),
  saveDraft: (locationId: number, departmentId: number) =>
    req<ScheduleResult>("/schedule/save-draft", {
      method: "POST",
      body: JSON.stringify({ location_id: locationId, department_id: departmentId }),
    }),
  cancelDraft: (locationId: number, departmentId: number) =>
    req<{ cancelled: boolean }>("/schedule/cancel-draft", {
      method: "POST",
      body: JSON.stringify({ location_id: locationId, department_id: departmentId }),
    }),
  runScenario: (params: {
    location_id: number;
    department_id: number;
    demand_delta_pct: number;
    absenteeism_delta_pct: number;
    productivity_delta_pct: number;
    cost_delta_pct: number;
    name?: string;
  }) =>
    req<ScenarioRunResult>("/scenario/run", {
      method: "POST",
      body: JSON.stringify(params),
    }),
  scenarioResults: (locationId: number, departmentId: number) =>
    req<ScenarioListEntry[]>(`/scenario/results?location_id=${locationId}&department_id=${departmentId}`),
  executiveDashboard: (locationId: number, departmentId: number, horizonDays: number) =>
    req<ExecutiveDashboardResult>(
      `/executive/dashboard?location_id=${locationId}&department_id=${departmentId}&horizon_days=${horizonDays}`
    ),
  previewImport: async (dataType: string, file: File, mapping?: Record<string, string>) => {
    const form = new FormData();
    form.append("data_type", dataType);
    if (mapping) form.append("mapping_json", JSON.stringify(mapping));
    form.append("file", file);
    const res = await fetch("/api/data/import/preview", { method: "POST", body: form });
    if (!res.ok) {
      const body = await res.text();
      let detail = body;
      try { detail = JSON.parse(body).detail ?? body; } catch { /* not JSON */ }
      throw new ApiError(res.status, detail);
    }
    return res.json() as Promise<ImportPreviewResult>;
  },
  commitImport: async (dataType: string, file: File, mapping: Record<string, string>) => {
    const form = new FormData();
    form.append("data_type", dataType);
    form.append("mapping_json", JSON.stringify(mapping));
    form.append("file", file);
    const res = await fetch("/api/data/import/commit", { method: "POST", body: form });
    if (!res.ok) {
      const body = await res.text();
      let detail = body;
      try { detail = JSON.parse(body).detail ?? body; } catch { /* not JSON */ }
      throw new ApiError(res.status, detail);
    }
    return res.json() as Promise<ImportCommitResult>;
  },
  exportUrl: (kind: "forecast" | "requirement" | "schedule" | "executive-summary", locationId: number, departmentId: number, horizonDays?: number) => {
    const qs = new URLSearchParams({ location_id: String(locationId), department_id: String(departmentId) });
    if (horizonDays) qs.set("horizon_days", String(horizonDays));
    return `/api/export/${kind}?${qs.toString()}`;
  },
  exportScenarioUrl: (scenarioId: number) => `/api/export/scenario/${scenarioId}`,
};

export { ApiError };
