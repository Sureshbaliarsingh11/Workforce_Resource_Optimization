#!/usr/bin/env bash
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for pidfile in "$ROOT_DIR/.backend.pid" "$ROOT_DIR/.frontend.pid"; do
  if [ -f "$pidfile" ]; then
    PID=$(cat "$pidfile")
    kill "$PID" 2>/dev/null && echo "Stopped process $PID" || echo "Process $PID already stopped"
    rm -f "$pidfile"
  fi
done
