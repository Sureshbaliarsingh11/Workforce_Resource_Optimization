import io
import os
import sys
import tempfile

import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402
from app.services import data_import as di  # noqa: E402

client = TestClient(app)
client.__enter__()


def _csv_bytes(df: pd.DataFrame) -> bytes:
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


# ---------- Mapping suggestion ----------

def test_suggest_mapping_matches_common_column_name_variants():
    mapping = di.suggest_mapping("demand", ["Date", "Store", "Volume", "Department"])
    assert mapping["timestamp"] == "Date"
    assert mapping["location"] == "Store"
    assert mapping["demand"] == "Volume"
    assert mapping["department"] == "Department"


def test_suggest_mapping_returns_partial_mapping_when_columns_are_missing():
    mapping = di.suggest_mapping("demand", ["Date", "Volume"])
    assert "location" not in mapping
    assert "department" not in mapping


# ---------- Preview: validation without persistence ----------

def test_preview_demand_import_reports_valid_rows_for_clean_data():
    df = pd.DataFrame({
        "Date": ["2026-01-01 08:00", "2026-01-01 09:00"],
        "Store": ["Location A", "Location A"],
        "Department": ["Sales", "Sales"],
        "Volume": [10, 15],
    })
    resp = client.post(
        "/api/data/import/preview",
        data={"data_type": "demand"},
        files={"file": ("demand.csv", _csv_bytes(df), "text/csv")},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["valid_rows"] == 2
    assert body["total_rows"] == 2
    assert body["errors"] == []


def test_preview_never_writes_to_the_database():
    before = client.get("/api/locations").json()
    df = pd.DataFrame({
        "Date": ["2026-01-01 08:00"], "Store": ["Brand New Location"],
        "Department": ["Sales"], "Volume": [10],
    })
    client.post(
        "/api/data/import/preview",
        data={"data_type": "demand"},
        files={"file": ("demand.csv", _csv_bytes(df), "text/csv")},
    )
    after = client.get("/api/locations").json()
    assert before == after  # preview must not create "Brand New Location"


def test_preview_flags_negative_demand():
    df = pd.DataFrame({
        "Date": ["2026-01-01 08:00", "2026-01-01 09:00"],
        "Store": ["Location A", "Location A"], "Department": ["Sales", "Sales"],
        "Volume": [10, -5],
    })
    resp = client.post(
        "/api/data/import/preview",
        data={"data_type": "demand"},
        files={"file": ("demand.csv", _csv_bytes(df), "text/csv")},
    )
    body = resp.json()
    assert body["valid_rows"] == 1
    assert any("negative" in e.lower() for e in body["errors"])


def test_preview_flags_unparseable_dates():
    df = pd.DataFrame({
        "Date": ["not-a-date"], "Store": ["Location A"], "Department": ["Sales"], "Volume": [10],
    })
    resp = client.post(
        "/api/data/import/preview",
        data={"data_type": "demand"},
        files={"file": ("demand.csv", _csv_bytes(df), "text/csv")},
    )
    body = resp.json()
    assert body["valid_rows"] == 0
    assert any("date" in e.lower() for e in body["errors"])


def test_preview_flags_duplicate_employee_ids():
    df = pd.DataFrame({
        "Worker_ID": ["E1", "E1"], "Name": ["Alice", "Alice B"],
        "Store": ["Location A", "Location A"], "Department": ["Sales", "Sales"],
        "Rate": [20.0, 21.0],
    })
    resp = client.post(
        "/api/data/import/preview",
        data={"data_type": "employees"},
        files={"file": ("employees.csv", _csv_bytes(df), "text/csv")},
    )
    body = resp.json()
    assert any("duplicate" in e.lower() for e in body["errors"])
    assert body["valid_rows"] == 1


def test_preview_rejects_unsupported_data_type():
    df = pd.DataFrame({"a": [1]})
    resp = client.post(
        "/api/data/import/preview",
        data={"data_type": "not_a_real_type"},
        files={"file": ("x.csv", _csv_bytes(df), "text/csv")},
    )
    assert resp.status_code == 422


def test_preview_rejects_unsupported_file_extension():
    resp = client.post(
        "/api/data/import/preview",
        data={"data_type": "demand"},
        files={"file": ("data.txt", b"not a real file", "text/plain")},
    )
    assert resp.status_code == 422


# ---------- Commit: actually writes rows ----------

def test_commit_demand_import_creates_real_rows():
    df = pd.DataFrame({
        "Date": ["2026-02-01 08:00", "2026-02-01 09:00"],
        "Store": ["Imported Store", "Imported Store"],
        "Department": ["Imported Dept", "Imported Dept"],
        "Volume": [22, 31],
    })
    mapping = di.suggest_mapping("demand", list(df.columns))
    resp = client.post(
        "/api/data/import/commit",
        data={"data_type": "demand", "mapping_json": __import__("json").dumps(mapping)},
        files={"file": ("demand.csv", _csv_bytes(df), "text/csv")},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["imported_rows"] == 2

    locs = client.get("/api/locations").json()
    assert any(l["name"] == "Imported Store" for l in locs)


def test_commit_employees_then_availability_links_by_external_id():
    import json as _json
    emp_df = pd.DataFrame({
        "Worker_ID": ["W100", "W101"], "Name": ["Priya K", "Sam T"],
        "Store": ["Import Loc", "Import Loc"], "Department": ["Import Dept", "Import Dept"],
        "Rate": [19.5, 22.0],
    })
    emp_mapping = di.suggest_mapping("employees", list(emp_df.columns))
    r1 = client.post(
        "/api/data/import/commit",
        data={"data_type": "employees", "mapping_json": _json.dumps(emp_mapping)},
        files={"file": ("employees.csv", _csv_bytes(emp_df), "text/csv")},
    )
    assert r1.status_code == 200
    assert r1.json()["imported_rows"] == 2

    avail_df = pd.DataFrame({
        "Worker_ID": ["W100", "W100", "W999"],  # W999 doesn't exist - should be rejected
        "day": [0, 1, 0], "from_hour": [8, 8, 8], "to_hour": [16, 16, 16],
    })
    avail_mapping = di.suggest_mapping("availability", list(avail_df.columns))
    r2 = client.post(
        "/api/data/import/commit",
        data={"data_type": "availability", "mapping_json": _json.dumps(avail_mapping)},
        files={"file": ("availability.csv", _csv_bytes(avail_df), "text/csv")},
    )
    assert r2.status_code == 200
    body = r2.json()
    assert body["imported_rows"] == 2  # only the 2 valid W100 rows
    assert any("not found" in e.lower() for e in body["errors"])


def test_commit_productivity_updates_department_defaults():
    import json as _json
    # First create the department via an employee import
    emp_df = pd.DataFrame({
        "Worker_ID": ["PW1"], "Name": ["Test Employee"],
        "Store": ["Prod Loc"], "Department": ["Prod Dept"], "Rate": [18.0],
    })
    client.post(
        "/api/data/import/commit",
        data={"data_type": "employees", "mapping_json": _json.dumps(di.suggest_mapping("employees", list(emp_df.columns)))},
        files={"file": ("emp.csv", _csv_bytes(emp_df), "text/csv")},
    )
    prod_df = pd.DataFrame({"Department": ["Prod Dept"], "productivity": [12.5]})
    resp = client.post(
        "/api/data/import/commit",
        data={"data_type": "productivity", "mapping_json": _json.dumps(di.suggest_mapping("productivity", list(prod_df.columns)))},
        files={"file": ("prod.csv", _csv_bytes(prod_df), "text/csv")},
    )
    assert resp.status_code == 200
    assert resp.json()["imported_rows"] == 1
    depts = client.get("/api/departments").json()
    prod_dept = next(d for d in depts if d["name"] == "Prod Dept")
    assert prod_dept["default_productivity_per_hour"] == 12.5


def test_commit_with_all_invalid_rows_imports_nothing():
    import json as _json
    df = pd.DataFrame({"Date": ["garbage"], "Store": ["X"], "Department": ["Y"], "Volume": ["not-a-number"]})
    mapping = di.suggest_mapping("demand", list(df.columns))
    resp = client.post(
        "/api/data/import/commit",
        data={"data_type": "demand", "mapping_json": _json.dumps(mapping)},
        files={"file": ("bad.csv", _csv_bytes(df), "text/csv")},
    )
    assert resp.status_code == 200
    assert resp.json()["imported_rows"] == 0


def test_excel_file_import_works_identically_to_csv():
    import json as _json
    df = pd.DataFrame({
        "Date": ["2026-03-01 08:00"], "Store": ["Excel Loc"], "Department": ["Excel Dept"], "Volume": [40],
    })
    buf = io.BytesIO()
    df.to_excel(buf, index=False, engine="openpyxl")
    mapping = di.suggest_mapping("demand", list(df.columns))
    resp = client.post(
        "/api/data/import/commit",
        data={"data_type": "demand", "mapping_json": _json.dumps(mapping)},
        files={"file": ("demand.xlsx", buf.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
    )
    assert resp.status_code == 200
    assert resp.json()["imported_rows"] == 1


# ---------- Demo data still works alongside import (not removed) ----------

def test_demo_data_generation_still_works_after_import_feature_added():
    resp = client.post("/api/data/generate", json={
        "days_of_history": 30, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 3, "seed": 5,
    })
    assert resp.status_code == 200
    assert resp.json()["employees_created"] == 3


# ---------- Export ----------

def _pipeline(seed=200):
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 6, "seed": seed,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    return loc_id, dept_id


def test_export_forecast_returns_real_csv_with_data():
    loc_id, dept_id = _pipeline()
    resp = client.get(f"/api/export/forecast?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/csv")
    df = pd.read_csv(io.StringIO(resp.text))
    assert len(df) == 7 * 24


def test_export_requirement_returns_real_csv():
    loc_id, dept_id = _pipeline(seed=201)
    resp = client.get(f"/api/export/requirement?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    df = pd.read_csv(io.StringIO(resp.text))
    assert "required_headcount" in df.columns


def test_export_schedule_returns_real_csv():
    loc_id, dept_id = _pipeline(seed=202)
    resp = client.get(f"/api/export/schedule?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    df = pd.read_csv(io.StringIO(resp.text))
    assert "employee_name" in df.columns
    assert len(df) > 0


def test_export_scenario_returns_real_csv():
    loc_id, dept_id = _pipeline(seed=203)
    scenario = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.15, "name": "Export test",
    }).json()
    resp = client.get(f"/api/export/scenario/{scenario['scenario_id']}")
    assert resp.status_code == 200
    df = pd.read_csv(io.StringIO(resp.text))
    assert df.iloc[0]["name"] == "Export test"


def test_export_executive_summary_returns_real_csv():
    loc_id, dept_id = _pipeline(seed=204)
    resp = client.get(f"/api/export/executive-summary?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    df = pd.read_csv(io.StringIO(resp.text))
    assert "labor_cost" in df.columns


def test_export_without_data_returns_404_not_a_crash():
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 2, "seed": 205,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    resp = client.get(f"/api/export/forecast?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 404
    assert "detail" in resp.json()


# ---------- Error handling: no raw tracebacks ----------

def test_unhandled_error_returns_friendly_message_not_a_traceback():
    # An out-of-range location_id/department_id for schedule generation
    # triggers a NoRequirementError path (already handled) - to exercise the
    # *global* handler we hit an endpoint with a type that can't be coerced,
    # which FastAPI's own validation catches before it ever reaches our code;
    # so instead we assert the global handler exists and matches expectations
    # via a direct unit check on its registration.
    from app.main import app as fastapi_app
    assert Exception in fastapi_app.exception_handlers
