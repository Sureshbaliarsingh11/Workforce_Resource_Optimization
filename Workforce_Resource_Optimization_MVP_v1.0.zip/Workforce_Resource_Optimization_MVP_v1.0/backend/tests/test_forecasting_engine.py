import os
import sys
import math
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.services import forecasting as fc  # noqa: E402


def _make_series(hours=24 * 60, seed=0):
    """Synthetic hourly series with clean daily seasonality + weekly pattern,
    used to sanity-check the models against a known signal."""
    rng = np.random.default_rng(seed)
    start = pd.Timestamp("2026-01-01")
    idx = pd.date_range(start, periods=hours, freq="h")
    hour_of_day = idx.hour.values
    day_of_week = idx.dayofweek.values
    daily = 50 + 40 * np.sin((hour_of_day - 6) / 24 * 2 * np.pi)
    daily = np.clip(daily, 5, None)
    weekend_damp = np.where(day_of_week >= 5, 0.6, 1.0)
    noise = rng.normal(0, 2, size=hours)
    values = daily * weekend_damp + noise
    values = np.clip(values, 0, None)
    return pd.Series(values, index=idx)


# ---------- Metric correctness ----------

def test_wape_is_zero_for_perfect_forecast():
    actual = [10, 20, 30, 0, 5]
    forecast = [10, 20, 30, 0, 5]
    m = fc.compute_metrics(actual, forecast)
    assert m["wape"] == 0.0
    assert m["mae"] == 0.0
    assert m["bias"] == 0.0


def test_wape_matches_hand_calculation():
    actual = [100, 100, 100, 100]
    forecast = [110, 90, 100, 100]
    # sum|actual-forecast| = 10+10+0+0 = 20; sum|actual| = 400 -> wape = 0.05
    m = fc.compute_metrics(actual, forecast)
    assert m["wape"] == pytest.approx(0.05)


def test_bias_sign_convention_positive_means_overforecast():
    actual = [100, 100]
    forecast = [110, 110]  # consistently over-forecasting
    m = fc.compute_metrics(actual, forecast)
    assert m["bias"] > 0


def test_bias_sign_convention_negative_means_underforecast():
    actual = [100, 100]
    forecast = [90, 90]
    m = fc.compute_metrics(actual, forecast)
    assert m["bias"] < 0


def test_metrics_handle_all_zero_actuals_without_crashing():
    actual = [0, 0, 0, 0]
    forecast = [0, 1, 0, 2]
    m = fc.compute_metrics(actual, forecast)
    # sum(|actual|) == 0 -> wape/bias must be None, not inf or NaN
    assert m["wape"] is None
    assert m["bias"] is None
    assert m["mape"] is None
    assert not math.isnan(m["mae"])


def test_mape_excludes_zero_actual_points_rather_than_dividing_by_zero():
    actual = [0, 100, 0, 100]
    forecast = [5, 110, 3, 90]
    m = fc.compute_metrics(actual, forecast)
    assert m["mape"] is not None
    assert not math.isinf(m["mape"])
    assert m["excluded_zero_actual_points"] == 2


# ---------- Model behavior ----------

def test_seasonal_naive_uses_value_from_exactly_one_week_prior():
    series = _make_series(hours=24 * 30)
    target_ts = series.index[-1] + timedelta(hours=1)
    preds = fc.seasonal_naive_forecast(series, [target_ts])
    expected = series[target_ts - timedelta(days=7)]
    assert preds[0] == pytest.approx(max(0.0, expected))


def test_moving_average_smooths_across_multiple_weeks():
    series = _make_series(hours=24 * 60)
    target_ts = series.index[-1] + timedelta(hours=1)
    preds = fc.moving_average_forecast(series, [target_ts], weeks=4)
    manual_vals = [series[target_ts - timedelta(days=7 * w)] for w in range(1, 5)]
    assert preds[0] == pytest.approx(max(0.0, float(np.mean(manual_vals))))


def test_no_model_produces_negative_forecasts():
    series = _make_series(hours=24 * 45)
    horizon_ts = [series.index[-1] + timedelta(hours=i) for i in range(1, 24 * 7 + 1)]
    for model_name in fc.ALL_MODELS:
        preds = fc.run_model(model_name, series, horizon_ts)
        assert all(p >= 0 for p in preds), f"{model_name} produced a negative forecast"
        assert all(not math.isnan(p) for p in preds), f"{model_name} produced NaN"


def test_forecast_returns_expected_horizon_length():
    series = _make_series(hours=24 * 45)
    for horizon_days in (7, 14):
        horizon_hours = horizon_days * 24
        horizon_ts = [series.index[-1] + timedelta(hours=i) for i in range(1, horizon_hours + 1)]
        preds = fc.run_model(fc.MODEL_SEASONAL_NAIVE, series, horizon_ts)
        assert len(preds) == horizon_hours


def test_exponential_smoothing_falls_back_gracefully_on_constant_series():
    # A perfectly flat series can make Holt-Winters degenerate; must not crash,
    # must fall back to seasonal naive rather than raise.
    idx = pd.date_range("2026-01-01", periods=24 * 20, freq="h")
    flat_series = pd.Series([42.0] * len(idx), index=idx)
    horizon_ts = [idx[-1] + timedelta(hours=i) for i in range(1, 25)]
    preds = fc.run_model(fc.MODEL_EXP_SMOOTHING, flat_series, horizon_ts)
    assert len(preds) == 24
    assert all(not math.isnan(p) for p in preds)


# ---------- Backtesting is time-ordered, not random ----------

def test_backtest_folds_never_use_future_data_to_train():
    series = _make_series(hours=24 * 60)
    windows = fc.build_folds(series, horizon_hours=24 * 7, n_folds=3)
    assert len(windows) > 0
    for train_slice, test_slice in windows:
        # every training timestamp must be strictly before every test timestamp
        assert train_slice.index.max() < test_slice.index.min()


def test_backtest_folds_are_sequential_not_shuffled():
    series = _make_series(hours=24 * 60)
    windows = fc.build_folds(series, horizon_hours=24 * 7, n_folds=3)
    test_starts = [w[1].index.min() for w in windows]
    assert test_starts == sorted(test_starts)


def test_backtest_with_insufficient_history_returns_fewer_or_zero_folds():
    short_series = _make_series(hours=24 * 10)  # only 10 days - below MIN_TRAIN_HOURS
    windows = fc.build_folds(short_series, horizon_hours=24 * 7, n_folds=3)
    assert len(windows) == 0  # not enough data for even one fold; must not crash


def test_rolling_backtest_evaluates_at_least_two_models():
    series = _make_series(hours=24 * 60)
    summary, folds = fc.rolling_backtest(series, horizon_hours=24 * 7, n_folds=2)
    evaluated = [name for name, m in summary.items() if m is not None]
    assert len(evaluated) >= 2
    assert folds >= 1


def test_best_model_selection_prefers_lower_wape():
    summary = {
        "model_a": {"wape": 0.20, "mae": 5, "rmse": 6, "bias": 0.01, "folds_evaluated": 2},
        "model_b": {"wape": 0.08, "mae": 7, "rmse": 8, "bias": -0.02, "folds_evaluated": 2},
    }
    assert fc.select_best_model(summary) == "model_b"


def test_rank_models_orders_by_wape_ascending():
    summary = {
        "a": {"wape": 0.3, "mae": 1, "rmse": 1, "bias": 0, "folds_evaluated": 1},
        "b": {"wape": 0.1, "mae": 1, "rmse": 1, "bias": 0, "folds_evaluated": 1},
        "c": {"wape": 0.2, "mae": 1, "rmse": 1, "bias": 0, "folds_evaluated": 1},
    }
    ranks = fc.rank_models(summary)
    assert ranks["b"] == 1
    assert ranks["c"] == 2
    assert ranks["a"] == 3
