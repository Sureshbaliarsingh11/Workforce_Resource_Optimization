import os
import sys
import math

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.services import workforce_requirement as wr  # noqa: E402


def test_matches_the_spec_worked_example():
    # From the spec: 500 demand / 10 productivity = 50 base; shrinkage 5+5+3=13%
    # required = ceil(50 / 0.87) = ceil(57.47) = 58
    shrinkage = wr.ShrinkageInputs(absence_pct=0.05, breaks_pct=0.05, training_pct=0.03, other_pct=0.0)
    result = wr.compute_headcount_for_demand(500, 10, shrinkage)
    assert result["base_headcount"] == 50
    assert result["required_headcount"] == 58


def test_zero_demand_produces_zero_headcount_not_error():
    shrinkage = wr.ShrinkageInputs()
    result = wr.compute_headcount_for_demand(0, 8, shrinkage)
    assert result["base_headcount"] == 0
    assert result["required_headcount"] == 0


def test_no_shrinkage_means_required_equals_base():
    shrinkage = wr.ShrinkageInputs(absence_pct=0, breaks_pct=0, training_pct=0, other_pct=0)
    result = wr.compute_headcount_for_demand(80, 8, shrinkage)
    assert result["base_headcount"] == 10
    assert result["required_headcount"] == 10


def test_base_headcount_rounds_up_never_down():
    # 41 / 10 = 4.1 -> must round UP to 5, not truncate to 4 (can't schedule 0.1 of a person)
    shrinkage = wr.ShrinkageInputs(absence_pct=0, breaks_pct=0, training_pct=0, other_pct=0)
    result = wr.compute_headcount_for_demand(41, 10, shrinkage)
    assert result["base_headcount"] == 5


def test_negative_or_zero_productivity_rejected():
    shrinkage = wr.ShrinkageInputs()
    with pytest.raises(wr.InvalidAssumptionError):
        wr.compute_headcount_for_demand(100, 0, shrinkage)
    with pytest.raises(wr.InvalidAssumptionError):
        wr.compute_headcount_for_demand(100, -5, shrinkage)


def test_shrinkage_at_or_above_100_percent_rejected():
    shrinkage = wr.ShrinkageInputs(absence_pct=0.5, breaks_pct=0.3, training_pct=0.2, other_pct=0.0)
    # totals to exactly 1.0 - must be rejected, not divide by zero
    with pytest.raises(wr.InvalidAssumptionError):
        wr.compute_headcount_for_demand(100, 10, shrinkage)


def test_negative_shrinkage_component_rejected():
    shrinkage = wr.ShrinkageInputs(absence_pct=-0.1, breaks_pct=0.05, training_pct=0.03, other_pct=0.0)
    with pytest.raises(wr.InvalidAssumptionError):
        wr.compute_headcount_for_demand(100, 10, shrinkage)


def test_higher_shrinkage_always_requires_more_or_equal_headcount():
    low = wr.ShrinkageInputs(absence_pct=0.02, breaks_pct=0.0, training_pct=0.0, other_pct=0.0)
    high = wr.ShrinkageInputs(absence_pct=0.20, breaks_pct=0.10, training_pct=0.05, other_pct=0.0)
    r_low = wr.compute_headcount_for_demand(300, 10, low)
    r_high = wr.compute_headcount_for_demand(300, 10, high)
    assert r_high["required_headcount"] >= r_low["required_headcount"]


def test_compute_requirement_series_preserves_length_and_timestamps():
    shrinkage = wr.ShrinkageInputs()
    points = [(f"2026-01-01T{h:02d}:00:00", 50 + h) for h in range(24)]
    rows = wr.compute_requirement_series(points, 10, shrinkage)
    assert len(rows) == 24
    assert rows[0]["timestamp"] == points[0][0]
    assert all(r["required_headcount"] >= r["base_headcount"] for r in rows)


def test_summarize_computes_real_peak_and_average():
    rows = [
        {"required_headcount": 10}, {"required_headcount": 20}, {"required_headcount": 15},
    ]
    summary = wr.summarize(rows)
    assert summary["peak_required_headcount"] == 20
    assert summary["avg_required_headcount"] == pytest.approx(15.0)
    assert summary["total_labor_hours"] == 45
    assert summary["hours_covered"] == 3


def test_summarize_handles_empty_input_without_crashing():
    summary = wr.summarize([])
    assert summary["peak_required_headcount"] == 0
    assert summary["hours_covered"] == 0
