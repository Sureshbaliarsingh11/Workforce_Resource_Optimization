import os
import sys
from datetime import date, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.services import optimization as opt  # noqa: E402

MORNING = opt.ShiftDef(id=1, name="Morning", start_hour=6, end_hour=14)
DAY = opt.ShiftDef(id=2, name="Day", start_hour=8, end_hour=16)
EVENING = opt.ShiftDef(id=3, name="Evening", start_hour=14, end_hour=22)
PART_TIME = opt.ShiftDef(id=4, name="Part-time", start_hour=10, end_hour=14)
SHIFTS = [MORNING, DAY, EVENING, PART_TIME]

FULL_AVAILABILITY = tuple((dow, 6, 22) for dow in range(7))


def make_employee(eid, name="Emp", cost_cents=2000, max_daily=8, max_weekly=40,
                   has_skill=True, preferred=None, availability=FULL_AVAILABILITY):
    return opt.EmployeeDef(
        id=eid, name=name, hourly_cost_cents=cost_cents, max_daily_hours=max_daily,
        max_weekly_hours=max_weekly, has_required_skill=has_skill,
        preferred_shift=preferred, availability=availability,
    )


def week_of_dates(n=7, start=date(2026, 1, 5)):  # a Monday
    return [start + timedelta(days=i) for i in range(n)]


def uniform_requirement(dates, hours_range, headcount):
    return {(d, h): headcount for d in dates for h in hours_range}


# ---------- Feasible scheduling ----------

def test_feasible_schedule_is_produced_for_reasonable_demand():
    dates = week_of_dates(7)
    employees = [make_employee(i) for i in range(1, 6)]
    requirement = uniform_requirement(dates, range(8, 16), 2)
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount=requirement)
    result = opt.solve(inp)
    assert result.feasible
    assert len(result.raw_assignments) > 0


def test_infeasible_when_no_employees():
    dates = week_of_dates(7)
    inp = opt.OptimizationInput(employees=[], shifts=SHIFTS, dates=dates, required_headcount={})
    result = opt.solve(inp)
    assert not result.feasible
    assert "no employees" in result.infeasibility_reason.lower()


def test_infeasible_when_no_one_has_the_required_skill():
    dates = week_of_dates(7)
    employees = [make_employee(i, has_skill=False) for i in range(1, 4)]
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount={})
    result = opt.solve(inp)
    assert not result.feasible
    assert "skill" in result.infeasibility_reason.lower() or "eligible" in result.infeasibility_reason.lower()


def test_infeasible_when_no_one_is_available_at_all():
    dates = week_of_dates(7)
    # availability window that matches no shift (only 2am-4am)
    bad_availability = tuple((dow, 2, 4) for dow in range(7))
    employees = [make_employee(i, availability=bad_availability) for i in range(1, 4)]
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount={})
    result = opt.solve(inp)
    assert not result.feasible


# ---------- Hard constraints respected ----------

def test_employee_never_scheduled_outside_availability():
    dates = week_of_dates(7)
    # employee only available Mon (dow 0) 6-14
    limited = ((0, 6, 14),)
    employees = [make_employee(1, availability=limited), make_employee(2)]  # emp2 fully available as filler
    requirement = uniform_requirement(dates, range(6, 14), 2)
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount=requirement)
    result = opt.solve(inp)
    assert result.feasible
    for a in result.raw_assignments:
        if a.employee_id == 1:
            assert a.date.weekday() == 0  # Monday only


def test_part_time_employee_never_gets_a_shift_longer_than_max_daily_hours():
    dates = week_of_dates(7)
    pt_employee = make_employee(1, max_daily=4, max_weekly=20)
    requirement = uniform_requirement(dates, range(10, 14), 1)
    inp = opt.OptimizationInput(employees=[pt_employee], shifts=SHIFTS, dates=dates, required_headcount=requirement)
    result = opt.solve(inp)
    assert result.feasible
    shift_by_id = {s.id: s for s in SHIFTS}
    for a in result.raw_assignments:
        assert shift_by_id[a.shift_id].duration_hours <= 4


def test_no_employee_assigned_more_than_one_shift_per_day():
    dates = week_of_dates(7)
    employees = [make_employee(i) for i in range(1, 4)]
    requirement = uniform_requirement(dates, range(6, 22), 3)
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount=requirement)
    result = opt.solve(inp)
    assert result.feasible
    seen = set()
    for a in result.raw_assignments:
        key = (a.employee_id, a.date)
        assert key not in seen, "employee double-booked on the same day"
        seen.add(key)


def test_weekly_hours_cap_is_never_exceeded():
    dates = week_of_dates(7)
    employees = [make_employee(1, max_weekly=16)]  # can only work 2 full shifts
    requirement = uniform_requirement(dates, range(6, 22), 1)
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount=requirement)
    result = opt.solve(inp)
    assert result.feasible
    hours_sum = sum({s.id: s for s in SHIFTS}[a.shift_id].duration_hours for a in result.raw_assignments)
    assert hours_sum <= 16


# ---------- Coverage, cost, overtime via the independent recompute layer ----------

def test_compute_schedule_details_flags_zero_errors_for_a_valid_solve():
    dates = week_of_dates(7)
    employees = [make_employee(i) for i in range(1, 6)]
    requirement = uniform_requirement(dates, range(8, 16), 2)
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount=requirement)
    result = opt.solve(inp)
    details = opt.compute_schedule_details(inp, result.raw_assignments)
    assert details["valid"], details["errors"]


def test_compute_schedule_details_recomputes_cost_correctly():
    dates = [date(2026, 1, 5)]
    employees = [make_employee(1, cost_cents=1500)]
    raw = [opt.RawAssignment(employee_id=1, date=dates[0], shift_id=MORNING.id)]
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount={})
    details = opt.compute_schedule_details(inp, raw)
    # 8 hours at 1500 cents/hr, no overtime (well under 32h threshold)
    assert details["total_cost_cents"] == 8 * 1500
    assert details["assignments"][0].is_overtime is False


def test_compute_schedule_details_detects_overtime_beyond_threshold():
    dates = week_of_dates(5)  # Mon-Fri
    employees = [make_employee(1, cost_cents=2000, max_weekly=40)]
    # 5 x 8-hour shifts = 40 hours; threshold is 32 -> last 8 hours should be overtime
    raw = [opt.RawAssignment(employee_id=1, date=d, shift_id=MORNING.id) for d in dates]
    inp = opt.OptimizationInput(
        employees=employees, shifts=SHIFTS, dates=dates, required_headcount={},
        overtime_threshold_hours_per_week=32, overtime_multiplier=1.5,
    )
    details = opt.compute_schedule_details(inp, raw)
    assert details["valid"]
    assert details["total_overtime_shifts"] >= 1
    # expected cost: 32h normal + 8h at 1.5x
    expected = 32 * 2000 + int(round(8 * 2000 * 1.5))
    assert details["total_cost_cents"] == expected


def test_compute_schedule_details_recomputes_coverage_independently():
    dates = [date(2026, 1, 5)]
    employees = [make_employee(1), make_employee(2)]
    raw = [
        opt.RawAssignment(employee_id=1, date=dates[0], shift_id=MORNING.id),
        opt.RawAssignment(employee_id=2, date=dates[0], shift_id=MORNING.id),
    ]
    requirement = {(dates[0], h): 3 for h in range(6, 14)}  # need 3, only 2 scheduled -> understaffed
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount=requirement)
    details = opt.compute_schedule_details(inp, raw)
    assert details["understaffed_hours"] == 8  # every required hour is short by 1
    assert details["overstaffed_hours"] == 0
    assert details["avg_coverage_pct"] < 100


def test_compute_schedule_details_flags_availability_violation_if_present():
    # Manually construct a raw assignment that violates availability, to prove
    # the validator actually checks it independently rather than trusting the solver.
    dates = [date(2026, 1, 5)]  # a Monday, dow=0
    limited = ((1, 6, 14),)  # only available Tuesday, not Monday
    employees = [make_employee(1, availability=limited)]
    raw = [opt.RawAssignment(employee_id=1, date=dates[0], shift_id=MORNING.id)]
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount={})
    details = opt.compute_schedule_details(inp, raw)
    assert not details["valid"]
    assert any("availability" in e.lower() for e in details["errors"])


def test_compute_schedule_details_flags_missing_skill_if_present():
    dates = [date(2026, 1, 5)]
    employees = [make_employee(1, has_skill=False)]
    raw = [opt.RawAssignment(employee_id=1, date=dates[0], shift_id=MORNING.id)]
    inp = opt.OptimizationInput(employees=employees, shifts=SHIFTS, dates=dates, required_headcount={})
    details = opt.compute_schedule_details(inp, raw)
    assert not details["valid"]
    assert any("skill" in e.lower() for e in details["errors"])
