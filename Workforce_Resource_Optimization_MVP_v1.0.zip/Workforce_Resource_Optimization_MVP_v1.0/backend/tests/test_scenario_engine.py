import os
import sys
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402

client = TestClient(app)
client.__enter__()


def _pipeline_no_schedule(employees_per=6, seed=61):
    """Data + forecast + requirement, but deliberately no schedule generated
    yet - exercises the ephemeral base-case solve path."""
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": employees_per, "seed": seed,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    return loc_id, dept_id


def _pipeline_with_schedule(employees_per=8, seed=62):
    loc_id, dept_id = _pipeline_no_schedule(employees_per, seed)
    client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    return loc_id, dept_id


def test_scenario_requires_a_workforce_requirement_first():
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 3, "seed": 1,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    resp = client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.2})
    assert resp.status_code == 422
    assert "requirement" in resp.json()["detail"].lower()


def test_demand_increase_never_decreases_required_headcount():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.20,
    })
    assert resp.status_code == 200
    body = resp.json()
    assert body["scenario"]["requirement"]["peak_required_headcount"] >= body["base"]["requirement"]["peak_required_headcount"]
    assert body["delta"]["additional_headcount"] >= 0


def test_demand_decrease_never_increases_required_headcount():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "demand_delta_pct": -0.20,
    })
    assert resp.status_code == 200
    body = resp.json()
    assert body["scenario"]["requirement"]["peak_required_headcount"] <= body["base"]["requirement"]["peak_required_headcount"]
    assert body["delta"]["additional_headcount"] <= 0


def test_productivity_decrease_increases_required_headcount():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "productivity_delta_pct": -0.20,
    })
    assert resp.status_code == 200
    body = resp.json()
    # lower productivity per employee -> need MORE people for the same demand
    assert body["scenario"]["requirement"]["peak_required_headcount"] >= body["base"]["requirement"]["peak_required_headcount"]


def test_absenteeism_increase_increases_required_headcount():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "absenteeism_delta_pct": 0.10,
    })
    assert resp.status_code == 200
    body = resp.json()
    assert body["scenario"]["requirement"]["peak_required_headcount"] >= body["base"]["requirement"]["peak_required_headcount"]


def test_no_change_scenario_matches_base_requirement():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id})
    body = resp.json()
    assert body["scenario"]["requirement"]["peak_required_headcount"] == body["base"]["requirement"]["peak_required_headcount"]
    assert body["delta"]["additional_headcount"] == 0


def test_cost_increase_reflects_in_additional_labor_cost_when_feasible():
    loc_id, dept_id = _pipeline_with_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "cost_delta_pct": 0.10,
    })
    assert resp.status_code == 200
    body = resp.json()
    if body["scenario"]["feasible"] and body["base"]["feasible"]:
        assert body["delta"]["additional_labor_cost"] >= 0


def test_scenario_uses_real_persisted_schedule_as_base_when_one_exists():
    loc_id, dept_id = _pipeline_with_schedule()
    stored = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    resp = client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id})
    body = resp.json()
    assert body["base"]["schedule"]["total_labor_cost"] == stored["summary"]["total_labor_cost"]


def test_scenario_never_mutates_the_live_schedule():
    loc_id, dept_id = _pipeline_with_schedule()
    before = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.5})
    after = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    assert before == after


def test_impossible_shrinkage_scenario_returns_clear_error_not_a_crash():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "absenteeism_delta_pct": 5.0,  # pushes total shrinkage way over 100%
    })
    assert resp.status_code == 422


def test_impossible_productivity_scenario_returns_clear_error_not_a_crash():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "productivity_delta_pct": -1.5,  # productivity <= 0
    })
    assert resp.status_code == 422


def test_executive_summary_is_a_real_sentence_derived_from_the_numbers():
    loc_id, dept_id = _pipeline_no_schedule()
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.30, "name": "Demand +30%",
    })
    body = resp.json()
    assert body["name"] == "Demand +30%"
    assert isinstance(body["executive_summary"], str) and len(body["executive_summary"]) > 10


def test_scenario_is_persisted_and_listed():
    loc_id, dept_id = _pipeline_no_schedule()
    run_resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.15, "name": "Peak season test",
    })
    scenario_id = run_resp.json()["scenario_id"]
    listing = client.get(f"/api/scenario/results?location_id={loc_id}&department_id={dept_id}").json()
    assert any(s["scenario_id"] == scenario_id and s["name"] == "Peak season test" for s in listing)


def test_multiple_scenarios_all_persist_independently():
    loc_id, dept_id = _pipeline_no_schedule()
    client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.1, "name": "A"})
    client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.2, "name": "B"})
    listing = client.get(f"/api/scenario/results?location_id={loc_id}&department_id={dept_id}").json()
    names = {s["name"] for s in listing}
    assert {"A", "B"}.issubset(names)


def test_regenerating_data_clears_stale_scenarios():
    loc_id, dept_id = _pipeline_no_schedule(seed=63)
    client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.1})
    assert len(client.get(f"/api/scenario/results?location_id={loc_id}&department_id={dept_id}").json()) > 0

    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 3, "seed": 64,
    })
    new_loc_id = client.get("/api/locations").json()[0]["id"]
    new_dept_id = client.get("/api/departments").json()[0]["id"]
    assert client.get(f"/api/scenario/results?location_id={new_loc_id}&department_id={new_dept_id}").json() == []


def test_end_to_end_scenario_workflow_matches_spec_example_shape():
    """Mirrors the spec's worked example: '+20% demand requires N additional
    employees and approximately $X additional weekly labor cost.'"""
    loc_id, dept_id = _pipeline_with_schedule(employees_per=10, seed=65)
    resp = client.post("/api/scenario/run", json={
        "location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.20, "name": "Demand +20%",
    })
    assert resp.status_code == 200
    body = resp.json()
    assert body["base"]["feasible"]
    assert "additional_headcount" in body["delta"]
    assert "additional_labor_cost" in body["delta"]
    assert body["executive_summary"].startswith('"Demand +20%"')
