import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402
from app.services import optimization as opt  # noqa: E402

client = TestClient(app)
client.__enter__()


def _full_pipeline(employees_per=8, seed=61):
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": employees_per, "seed": seed,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    sched = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    return loc_id, dept_id, sched.json()


def _pick_scheduled_employee_and_free_date(sched_body):
    by_emp = {}
    all_dates = sorted({a["date"] for a in sched_body["assignments"]})
    for a in sched_body["assignments"]:
        by_emp.setdefault(a["employee_id"], set()).add(a["date"])
    for eid, worked_dates in by_emp.items():
        free_dates = [d for d in all_dates if d not in worked_dates]
        if free_dates:
            return eid, sorted(worked_dates)[0], free_dates[0]
    return None, None, None


# ============================================================
# GAP 1 - Soft-constraint warnings (pure unit tests, no DB)
# ============================================================

def _emp(preferred_shift=None):
    return opt.EmployeeDef(
        id=1, name="Test", hourly_cost_cents=2000, max_daily_hours=8, max_weekly_hours=40,
        has_required_skill=True, preferred_shift=preferred_shift,
        availability=tuple((d, 6, 22) for d in range(7)),
    )


def _shift(name="Evening"):
    return opt.ShiftDef(id=3, name=name, start_hour=14, end_hour=22)


def test_preference_violation_warning_fires_on_mismatch():
    emp = _emp(preferred_shift="Morning")
    shift = _shift(name="Evening")
    before = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    after = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    warnings = opt.compute_soft_constraint_warnings(emp, shift, before, after)
    assert any("preference violated" in w.lower() for w in warnings)


def test_no_preference_warning_when_shift_matches_preference():
    emp = _emp(preferred_shift="Evening")
    shift = _shift(name="Evening")
    before = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    after = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    warnings = opt.compute_soft_constraint_warnings(emp, shift, before, after)
    assert not any("preference" in w.lower() for w in warnings)


def test_overtime_increase_warning_matches_spec_phrasing():
    emp = _emp()
    before = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    after = {"overtime_hours": 2, "total_labor_cost": 100, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    warnings = opt.compute_soft_constraint_warnings(emp, None, before, after)
    assert any("overtime increased by 2 hour" in w.lower() for w in warnings)


def test_labor_cost_increase_warning_reports_the_real_dollar_delta():
    emp = _emp()
    before = {"overtime_hours": 0, "total_labor_cost": 100.0, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    after = {"overtime_hours": 0, "total_labor_cost": 185.0, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    warnings = opt.compute_soft_constraint_warnings(emp, None, before, after)
    assert any("labor cost increased by $85" in w.lower() for w in warnings)


def test_coverage_improved_but_overstaffing_increased_warning():
    emp = _emp()
    before = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 80, "overstaffed_hours": 2}
    after = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 90, "overstaffed_hours": 5}
    warnings = opt.compute_soft_constraint_warnings(emp, None, before, after)
    assert any("coverage improved but overstaffing increased" in w.lower() for w in warnings)


def test_no_change_produces_no_warnings():
    emp = _emp()
    same = {"overtime_hours": 0, "total_labor_cost": 100, "avg_coverage_pct": 50, "overstaffed_hours": 0}
    warnings = opt.compute_soft_constraint_warnings(emp, None, same, dict(same))
    assert warnings == []


def test_warnings_never_block_a_valid_commit_via_api():
    loc_id, dept_id, sched = _full_pipeline()
    # find a full-time employee with a preference we can violate
    employees = client.get("/api/employees", params={"location_id": loc_id, "department_id": dept_id}).json()
    candidates = [e for e in employees if e["preferred_shift"] and e["preferred_shift"] != "Morning"]
    assert candidates
    emp = candidates[0]
    all_dates = sorted({a["date"] for a in sched["assignments"]})
    free_dates = [d for d in all_dates if not any(
        a["employee_id"] == emp["id"] and a["date"] == d for a in sched["assignments"]
    )]
    if not free_dates:
        return  # nothing to assert if the employee is fully booked every day
    target_date = free_dates[0]
    resp = client.put("/api/schedule/assignment", json={
        "location_id": loc_id, "department_id": dept_id,
        "employee_id": emp["id"], "date": target_date, "shift_id": 1,  # Morning - likely a preference mismatch
    })
    # Regardless of whether a preference warning fires, a hard-constraint-clean
    # edit must succeed (soft constraints never block).
    if resp.status_code == 200:
        body = resp.json()
        assert body["valid"] is True
        assert "warnings" in body


# ============================================================
# GAP 2 - Batch staging: stage / draft status / save / cancel
# ============================================================

def test_draft_status_reports_no_unsaved_changes_initially():
    loc_id, dept_id, sched = _full_pipeline()
    resp = client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    assert resp.json()["has_unsaved_changes"] is False


def test_staging_a_change_does_not_touch_the_live_schedule():
    loc_id, dept_id, sched = _full_pipeline()
    eid, worked_date, _ = _pick_scheduled_employee_and_free_date(sched)
    before_live = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()

    resp = client.post("/api/schedule/stage-change", json={
        "location_id": loc_id, "department_id": dept_id,
        "employee_id": eid, "date": worked_date, "shift_id": None,
    })
    assert resp.status_code == 200
    assert resp.json()["valid"] is True

    after_live = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    assert after_live == before_live  # staging must not mutate the committed schedule
    assert after_live["schedule_status"] == "optimized"


def test_draft_status_reflects_staged_change():
    loc_id, dept_id, sched = _full_pipeline()
    eid, worked_date, _ = _pick_scheduled_employee_and_free_date(sched)
    client.post("/api/schedule/stage-change", json={
        "location_id": loc_id, "department_id": dept_id,
        "employee_id": eid, "date": worked_date, "shift_id": None,
    })
    draft = client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}").json()
    assert draft["has_unsaved_changes"] is True
    assert len(draft["changes"]) == 1
    assert draft["changes"][0]["employee_id"] == eid
    assert draft["working"]["total_shifts"] == draft["baseline"]["total_shifts"] - 1


def test_staging_multiple_changes_accumulates_in_the_draft():
    loc_id, dept_id, sched = _full_pipeline(employees_per=10, seed=62)
    by_emp = {}
    for a in sched["assignments"]:
        by_emp.setdefault(a["employee_id"], []).append(a["date"])
    employees_with_shifts = [eid for eid, dates in by_emp.items() if len(dates) >= 2]
    assert len(employees_with_shifts) >= 2
    eid1, eid2 = employees_with_shifts[0], employees_with_shifts[1]
    date1 = by_emp[eid1][0]
    date2 = by_emp[eid2][0]

    client.post("/api/schedule/stage-change", json={
        "location_id": loc_id, "department_id": dept_id, "employee_id": eid1, "date": date1, "shift_id": None,
    })
    client.post("/api/schedule/stage-change", json={
        "location_id": loc_id, "department_id": dept_id, "employee_id": eid2, "date": date2, "shift_id": None,
    })
    draft = client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}").json()
    assert len(draft["changes"]) == 2
    assert draft["working"]["total_shifts"] == draft["baseline"]["total_shifts"] - 2


def test_save_draft_commits_all_staged_changes_and_clears_the_draft():
    loc_id, dept_id, sched = _full_pipeline()
    eid, worked_date, _ = _pick_scheduled_employee_and_free_date(sched)
    original_count = len(sched["assignments"])

    client.post("/api/schedule/stage-change", json={
        "location_id": loc_id, "department_id": dept_id,
        "employee_id": eid, "date": worked_date, "shift_id": None,
    })
    resp = client.post("/api/schedule/save-draft", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 200
    body = resp.json()
    assert body["schedule_status"] == "modified"
    assert len(body["assignments"]) == original_count - 1

    # draft is now empty
    draft = client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}").json()
    assert draft["has_unsaved_changes"] is False

    # persisted - reload confirms
    reloaded = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    assert len(reloaded["assignments"]) == original_count - 1


def test_save_draft_with_nothing_staged_returns_clear_error():
    loc_id, dept_id, _ = _full_pipeline()
    resp = client.post("/api/schedule/save-draft", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 422
    assert "no unsaved changes" in resp.json()["detail"].lower()


def test_cancel_draft_discards_staged_changes_without_touching_live_schedule():
    loc_id, dept_id, sched = _full_pipeline()
    eid, worked_date, _ = _pick_scheduled_employee_and_free_date(sched)
    original_count = len(sched["assignments"])

    client.post("/api/schedule/stage-change", json={
        "location_id": loc_id, "department_id": dept_id,
        "employee_id": eid, "date": worked_date, "shift_id": None,
    })
    resp = client.post("/api/schedule/cancel-draft", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 200
    assert resp.json()["cancelled"] is True

    draft = client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}").json()
    assert draft["has_unsaved_changes"] is False

    live = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    assert len(live["assignments"]) == original_count  # untouched
    assert live["schedule_status"] == "optimized"


def test_cancel_draft_with_nothing_staged_returns_clear_error():
    loc_id, dept_id, _ = _full_pipeline()
    resp = client.post("/api/schedule/cancel-draft", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 422


def test_regenerating_schedule_clears_any_stale_draft():
    loc_id, dept_id, sched = _full_pipeline()
    eid, worked_date, _ = _pick_scheduled_employee_and_free_date(sched)
    client.post("/api/schedule/stage-change", json={
        "location_id": loc_id, "department_id": dept_id,
        "employee_id": eid, "date": worked_date, "shift_id": None,
    })
    assert client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}").json()["has_unsaved_changes"] is True

    client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    draft = client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}").json()
    assert draft["has_unsaved_changes"] is False


def test_end_to_end_batch_staging_workflow():
    loc_id, dept_id, sched = _full_pipeline(employees_per=10, seed=63)
    by_emp = {}
    for a in sched["assignments"]:
        by_emp.setdefault(a["employee_id"], []).append(a["date"])
    two_employees = [eid for eid, dates in by_emp.items() if dates][:2]
    assert len(two_employees) == 2

    # 1. stage two edits
    for eid in two_employees:
        client.post("/api/schedule/stage-change", json={
            "location_id": loc_id, "department_id": dept_id,
            "employee_id": eid, "date": by_emp[eid][0], "shift_id": None,
        })

    # 2. draft shows both, live schedule unaffected
    draft = client.get(f"/api/schedule/draft?location_id={loc_id}&department_id={dept_id}").json()
    assert len(draft["changes"]) == 2
    live_before_save = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    assert live_before_save["schedule_status"] == "optimized"

    # 3. save the batch
    saved = client.post("/api/schedule/save-draft", json={"location_id": loc_id, "department_id": dept_id}).json()
    assert saved["schedule_status"] == "modified"
    assert len(saved["assignments"]) == len(sched["assignments"]) - 2

    # 4. reload confirms persistence
    reloaded = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    assert len(reloaded["assignments"]) == len(sched["assignments"]) - 2

    # 5. revert still works after a batch save
    reverted = client.post("/api/schedule/revert", json={"location_id": loc_id, "department_id": dept_id}).json()
    assert reverted["schedule_status"] == "optimized"
    assert len(reverted["assignments"]) == len(sched["assignments"])
