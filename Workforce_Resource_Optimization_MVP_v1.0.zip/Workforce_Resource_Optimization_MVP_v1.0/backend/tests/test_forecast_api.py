import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402

client = TestClient(app)
client.__enter__()


def _generate_dataset():
    resp = client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 3, "seed": 11,
    })
    assert resp.status_code == 200
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    return loc_id, dept_id


def test_forecast_results_404_before_any_forecast_generated():
    loc_id, dept_id = _generate_dataset()
    resp = client.get(f"/api/forecast/results?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 404


def test_generate_forecast_returns_model_comparison_and_forecast_points():
    loc_id, dept_id = _generate_dataset()
    resp = client.post("/api/forecast", json={
        "location_id": loc_id, "department_id": dept_id, "horizon_days": 7,
    })
    assert resp.status_code == 200
    body = resp.json()

    assert body["best_model"] in {"seasonal_naive", "moving_average", "exponential_smoothing"}
    assert len(body["model_comparison"]) == 3
    assert sum(1 for m in body["model_comparison"] if m["is_best"]) == 1

    # At least two forecasting approaches must be evaluated - acceptance criterion
    evaluated = [m for m in body["model_comparison"] if m["folds_evaluated"] > 0]
    assert len(evaluated) >= 2

    # 7-day hourly horizon = 168 points for the best model
    assert len(body["forecast_points"]) == 7 * 24
    assert all(p["is_best_model"] for p in body["forecast_points"])
    assert all(p["predicted_demand"] >= 0 for p in body["forecast_points"])


def test_forecast_results_readable_after_generation():
    loc_id, dept_id = _generate_dataset()
    client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    resp = client.get(f"/api/forecast/results?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    body = resp.json()
    assert body["horizon_days"] == 7
    assert len(body["forecast_points"]) == 7 * 24


def test_invalid_horizon_days_rejected():
    loc_id, dept_id = _generate_dataset()
    resp = client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 3})
    assert resp.status_code == 422


def test_forecast_on_insufficient_history_returns_useful_error_not_500():
    resp = client.post("/api/data/generate", json={
        "days_of_history": 5, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 2, "seed": 3,
    })
    assert resp.status_code == 200
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    resp = client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    assert resp.status_code == 422
    assert "history" in resp.json()["detail"].lower()


def test_dashboard_has_forecast_flips_true_after_generation():
    loc_id, dept_id = _generate_dataset()
    before = client.get("/api/dashboard").json()
    assert before["has_forecast"] is False
    client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    after = client.get("/api/dashboard").json()
    assert after["has_forecast"] is True
