import os
import sys
import tempfile

import pytest
from fastapi.testclient import TestClient

# Use an isolated temp DB per test session so tests never touch dev data
TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import app  # noqa: E402
from app.database import SessionLocal  # noqa: E402

# TestClient must be used as a context manager for startup events (init_db) to fire
client = TestClient(app)
client.__enter__()


def test_health_check():
    resp = client.get("/api/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"


def test_generate_data_creates_expected_counts():
    resp = client.post("/api/data/generate", json={
        "days_of_history": 30,
        "num_locations": 2,
        "num_departments": 3,
        "employees_per_location_dept": 4,
        "seed": 7,
    })
    assert resp.status_code == 200
    body = resp.json()
    assert body["locations_created"] == 2
    assert body["departments_created"] == 3
    # 2 locations * 3 departments * 4 employees each
    assert body["employees_created"] == 2 * 3 * 4
    assert body["demand_rows_created"] > 0


def test_generate_data_is_idempotent_on_rerun():
    # Running twice with same params should not duplicate rows (generator wipes first)
    payload = {
        "days_of_history": 10,
        "num_locations": 1,
        "num_departments": 1,
        "employees_per_location_dept": 3,
        "seed": 1,
    }
    r1 = client.post("/api/data/generate", json=payload)
    r2 = client.post("/api/data/generate", json=payload)
    assert r1.json()["demand_rows_created"] == r2.json()["demand_rows_created"]
    emp_resp = client.get("/api/employees")
    assert len(emp_resp.json()) == 1 * 1 * 3  # not doubled


def test_demand_endpoint_returns_data_for_valid_location_department():
    client.post("/api/data/generate", json={
        "days_of_history": 20, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 2, "seed": 3,
    })
    locs = client.get("/api/locations").json()
    depts = client.get("/api/departments").json()
    resp = client.get("/api/demand", params={
        "location_id": locs[0]["id"], "department_id": depts[0]["id"], "days": 7,
    })
    assert resp.status_code == 200
    rows = resp.json()
    assert len(rows) > 0
    # No negative demand values should ever be generated
    assert all(r["demand"] >= 0 for r in rows)


def test_demand_endpoint_404_for_unknown_ids():
    resp = client.get("/api/demand", params={"location_id": 9999, "department_id": 9999})
    assert resp.status_code == 404


def test_dashboard_reflects_generated_data_not_fake_numbers():
    client.post("/api/data/generate", json={
        "days_of_history": 30, "num_locations": 2, "num_departments": 2,
        "employees_per_location_dept": 5, "seed": 9,
    })
    resp = client.get("/api/dashboard")
    assert resp.status_code == 200
    body = resp.json()
    assert body["total_locations"] == 2
    assert body["total_departments"] == 2
    assert body["total_employees"] == 2 * 2 * 5
    assert body["total_demand_last_7_days"] > 0
    assert body["avg_hourly_demand_last_7_days"] > 0
    # Phase 1 has no forecast/schedule yet - must be honestly reported as False,
    # never faked as True
    assert body["has_forecast"] is False
    assert body["has_schedule"] is False


def test_dashboard_before_any_data_generated_does_not_crash():
    # Fresh, isolated DB (separate engine/session, same metadata) with nothing generated yet
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.database import Base
    from app.services import dashboard as dashboard_service

    fresh_db_file = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    engine = create_engine(f"sqlite:///{fresh_db_file.name}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    FreshSession = sessionmaker(bind=engine)

    db = FreshSession()
    summary = dashboard_service.get_summary(db)
    db.close()

    assert summary["total_locations"] == 0
    assert summary["total_demand_last_7_days"] == 0.0
    assert summary["has_forecast"] is False
