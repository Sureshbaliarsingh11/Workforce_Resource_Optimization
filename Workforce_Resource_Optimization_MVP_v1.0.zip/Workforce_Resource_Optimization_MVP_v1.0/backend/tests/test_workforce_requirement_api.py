import os
import sys
import math
import tempfile

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402

client = TestClient(app)
client.__enter__()


def _generate_dataset_and_forecast():
    resp = client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 3, "seed": 21,
    })
    assert resp.status_code == 200
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    fc = client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    assert fc.status_code == 200
    return loc_id, dept_id


def test_requirement_fails_gracefully_without_a_forecast_first():
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 2, "seed": 5,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    resp = client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 422
    assert "forecast" in resp.json()["detail"].lower()


def test_requirement_generated_from_real_forecast_not_fake_numbers():
    loc_id, dept_id = _generate_dataset_and_forecast()
    resp = client.post("/api/workforce/requirement", json={
        "location_id": loc_id, "department_id": dept_id,
        "productivity_per_hour": 10, "absence_pct": 0.05, "breaks_pct": 0.05, "training_pct": 0.03,
    })
    assert resp.status_code == 200
    body = resp.json()
    assert body["productivity_per_hour"] == 10
    assert abs(body["shrinkage_pct"] - 0.13) < 1e-6
    assert len(body["points"]) == 7 * 24  # matches the 7-day forecast horizon

    # Spot-check one point's math against the actual forecast demand returned
    p = body["points"][0]
    expected_base = math.ceil(p["forecast_demand"] / 10)
    expected_required = math.ceil(expected_base / (1 - 0.13)) if expected_base > 0 else 0
    assert p["base_headcount"] == expected_base
    assert p["required_headcount"] == expected_required

    assert body["summary"]["peak_required_headcount"] >= body["summary"]["avg_required_headcount"]


def test_requirement_uses_department_default_productivity_when_omitted():
    loc_id, dept_id = _generate_dataset_and_forecast()
    dept = client.get("/api/departments").json()[0]
    resp = client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 200
    assert resp.json()["productivity_per_hour"] == dept["default_productivity_per_hour"]


def test_requirement_rejects_shrinkage_at_100_percent():
    loc_id, dept_id = _generate_dataset_and_forecast()
    resp = client.post("/api/workforce/requirement", json={
        "location_id": loc_id, "department_id": dept_id,
        "absence_pct": 0.5, "breaks_pct": 0.3, "training_pct": 0.2, "other_pct": 0.0,
    })
    assert resp.status_code == 422


def test_requirement_results_readable_after_generation():
    loc_id, dept_id = _generate_dataset_and_forecast()
    client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    resp = client.get(f"/api/workforce/requirement/results?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    assert len(resp.json()["points"]) == 7 * 24


def test_requirement_results_404_before_generation():
    resp = client.get("/api/workforce/requirement/results?location_id=999&department_id=999")
    assert resp.status_code == 404


def test_dashboard_has_workforce_requirement_flips_true():
    loc_id, dept_id = _generate_dataset_and_forecast()
    before = client.get("/api/dashboard").json()
    assert before["has_workforce_requirement"] is False
    client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    after = client.get("/api/dashboard").json()
    assert after["has_workforce_requirement"] is True


def test_regenerating_data_wipes_stale_workforce_requirement_rows():
    # Regression test: data_generator must wipe WorkforceRequirement (and
    # ForecastModelRun) on regenerate, or stale rows survive under recycled
    # SQLite primary keys and falsely mark a fresh dataset as already having
    # a workforce requirement computed.
    loc_id, dept_id = _generate_dataset_and_forecast()
    client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    assert client.get("/api/dashboard").json()["has_workforce_requirement"] is True

    # Regenerate a brand new dataset (likely recycling the same small IDs in SQLite)
    resp = client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 2, "seed": 99,
    })
    assert resp.status_code == 200
    assert client.get("/api/dashboard").json()["has_workforce_requirement"] is False
