import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402

client = TestClient(app)
client.__enter__()


def _full_pipeline(num_locations=1, num_departments=1, employees_per=6, seed=31):
    resp = client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": num_locations, "num_departments": num_departments,
        "employees_per_location_dept": employees_per, "seed": seed,
    })
    assert resp.status_code == 200
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]

    fc = client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    assert fc.status_code == 200

    wr = client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    assert wr.status_code == 200

    return loc_id, dept_id


def test_schedule_fails_gracefully_without_requirement_first():
    resp = client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 3, "seed": 1,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    resp = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 422
    assert "requirement" in resp.json()["detail"].lower()


def test_full_pipeline_produces_a_real_feasible_schedule():
    loc_id, dept_id = _full_pipeline()
    resp = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 200
    body = resp.json()
    assert body["feasible"] is True
    assert body["status"] == "FEASIBLE"
    assert len(body["assignments"]) > 0
    assert body["summary"]["total_labor_cost"] > 0
    assert body["summary"]["total_shifts"] == len(body["assignments"])

    # No assignment should have zero or negative cost/hours - would indicate fabricated data
    for a in body["assignments"]:
        assert a["hours"] > 0
        assert a["cost"] > 0


def test_no_employee_double_booked_on_the_same_day():
    loc_id, dept_id = _full_pipeline()
    resp = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    body = resp.json()
    seen = set()
    for a in body["assignments"]:
        key = (a["employee_id"], a["date"])
        assert key not in seen
        seen.add(key)


def test_infeasible_when_department_has_zero_employees_with_required_skill():
    # Generate employees, then manually verify the infeasible path via a
    # location/department pair that has a forecast+requirement but we starve
    # it of eligible employees by using a fresh empty dataset scenario:
    # simplest reliable way is a location/department with employees_per=0.
    resp = client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 0, "seed": 2,
    })
    assert resp.status_code == 200
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    fc = client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    assert fc.status_code == 200
    wr = client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    assert wr.status_code == 200

    resp = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    assert resp.status_code == 422  # NoEmployeesError


def test_schedule_results_readable_after_generation():
    loc_id, dept_id = _full_pipeline()
    client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    resp = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    body = resp.json()
    assert len(body["assignments"]) > 0
    assert body["summary"]["total_labor_cost"] > 0


def test_schedule_results_404_before_generation():
    resp = client.get("/api/schedule/results?location_id=999&department_id=999")
    assert resp.status_code == 404


def test_regenerating_schedule_replaces_not_duplicates():
    loc_id, dept_id = _full_pipeline()
    r1 = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    r2 = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    assert r1.status_code == 200 and r2.status_code == 200
    resp = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}")
    # Should reflect only the latest run's assignment count, not doubled
    assert resp.json()["summary"]["total_shifts"] == r2.json()["summary"]["total_shifts"]


def test_dashboard_has_schedule_flips_true():
    loc_id, dept_id = _full_pipeline()
    before = client.get("/api/dashboard").json()
    assert before["has_schedule"] is False
    client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    after = client.get("/api/dashboard").json()
    assert after["has_schedule"] is True


def test_coverage_data_reflects_real_required_headcount_from_phase3():
    loc_id, dept_id = _full_pipeline()
    wr_body = client.get(f"/api/workforce/requirement/results?location_id={loc_id}&department_id={dept_id}").json()
    resp = client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    body = resp.json()
    if body["feasible"]:
        required_from_wr = {(p["timestamp"][:10], int(p["timestamp"][11:13])): p["required_headcount"] for p in wr_body["points"]}
        for c in body["coverage"][:20]:
            key = (c["date"], c["hour"])
            if key in required_from_wr:
                assert c["required"] == required_from_wr[key]
