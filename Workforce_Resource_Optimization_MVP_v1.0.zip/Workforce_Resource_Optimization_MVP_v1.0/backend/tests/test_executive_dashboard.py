import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{TMP_DB.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402
from app.services import executive_dashboard as ed  # noqa: E402

client = TestClient(app)
client.__enter__()


def _pipeline(with_schedule=True, employees_per=10, seed=71):
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": employees_per, "seed": seed,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    client.post("/api/forecast", json={"location_id": loc_id, "department_id": dept_id, "horizon_days": 7})
    client.post("/api/workforce/requirement", json={"location_id": loc_id, "department_id": dept_id})
    if with_schedule:
        client.post("/api/schedule/generate", json={"location_id": loc_id, "department_id": dept_id})
    return loc_id, dept_id


# ---------- Endpoint basics ----------

def test_dashboard_404_for_unknown_location_or_department():
    resp = client.get("/api/executive/dashboard?location_id=999999&department_id=999999")
    assert resp.status_code == 404


def test_dashboard_loads_with_full_pipeline():
    loc_id, dept_id = _pipeline()
    resp = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    body = resp.json()
    assert body["location"]["id"] == loc_id
    assert body["department"]["id"] == dept_id
    assert body["kpis"]["labor_cost"] is not None
    assert body["kpis"]["forecast_accuracy_pct"] is not None


def test_dashboard_degrades_gracefully_with_only_data_generated():
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 1, "num_departments": 1,
        "employees_per_location_dept": 5, "seed": 72,
    })
    loc_id = client.get("/api/locations").json()[0]["id"]
    dept_id = client.get("/api/departments").json()[0]["id"]
    resp = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}")
    assert resp.status_code == 200
    body = resp.json()
    # No forecast/requirement/schedule yet - must not crash, must honestly report unavailable
    assert body["kpis"]["forecast_accuracy_pct"] is None
    assert body["kpis"]["labor_cost"] is None
    assert body["optimization_impact"]["available"] is False
    assert body["whatif_summary"]["available"] is False


# ---------- KPI correctness (real numbers, cross-checked against source endpoints) ----------

def test_kpi_labor_cost_matches_schedule_results_exactly():
    loc_id, dept_id = _pipeline()
    schedule = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    assert dash["kpis"]["labor_cost"] == schedule["summary"]["total_labor_cost"]
    assert dash["kpis"]["avg_coverage_pct"] == schedule["summary"]["avg_coverage_pct"]


def test_kpi_forecast_accuracy_derived_from_wape_correctly():
    loc_id, dept_id = _pipeline()
    forecast = client.get(f"/api/forecast/results?location_id={loc_id}&department_id={dept_id}").json()
    best = next(m for m in forecast["model_comparison"] if m["is_best"])
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    expected_accuracy = round((1 - best["wape"]) * 100, 1)
    assert dash["kpis"]["forecast_accuracy_pct"] == expected_accuracy


def test_kpi_required_headcount_matches_requirement_results():
    loc_id, dept_id = _pipeline()
    req = client.get(f"/api/workforce/requirement/results?location_id={loc_id}&department_id={dept_id}").json()
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    assert dash["kpis"]["required_peak_headcount"] == req["summary"]["peak_required_headcount"]


# ---------- Labor cost detail (overtime cost split correctness) ----------

def test_overtime_cost_is_never_negative_and_never_exceeds_total_cost():
    loc_id, dept_id = _pipeline(employees_per=6)
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    lc = dash["labor_cost"]
    if lc["available"]:
        assert lc["overtime_cost"] >= 0
        assert lc["overtime_cost"] <= lc["current_labor_cost"]


def test_cost_trend_has_one_entry_per_scheduled_date():
    loc_id, dept_id = _pipeline()
    schedule = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    dates = {a["date"] for a in schedule["assignments"]}
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    trend_dates = {c["date"] for c in dash["labor_cost"]["cost_trend"]}
    assert trend_dates == dates


# ---------- Optimization impact: real baseline-vs-current, or honest "unavailable" ----------

def test_optimization_impact_unavailable_when_no_schedule():
    loc_id, dept_id = _pipeline(with_schedule=False)
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    assert dash["optimization_impact"]["available"] is False
    assert "unavailable" in dash["optimization_impact"]["message"].lower()


def test_optimization_impact_unavailable_when_schedule_unmodified():
    loc_id, dept_id = _pipeline()
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    # Fresh generate -> status "optimized", nothing to compare against yet
    assert dash["optimization_impact"]["available"] is False


def test_optimization_impact_available_and_correct_after_a_manual_edit():
    loc_id, dept_id = _pipeline()
    sched = client.get(f"/api/schedule/results?location_id={loc_id}&department_id={dept_id}").json()
    a = sched["assignments"][0]
    client.put("/api/schedule/assignment", json={
        "location_id": loc_id, "department_id": dept_id,
        "employee_id": a["employee_id"], "date": a["date"], "shift_id": None,
    })
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    impact = dash["optimization_impact"]
    assert impact["available"] is True
    # removing a paid shift can only reduce or maintain cost relative to the optimized baseline
    assert impact["before"]["total_labor_cost"] >= impact["after"]["total_labor_cost"]
    assert impact["estimated_savings"] == round(impact["before"]["total_labor_cost"] - impact["after"]["total_labor_cost"], 2)


# ---------- What-if summary ----------

def test_whatif_summary_unavailable_with_no_scenarios():
    loc_id, dept_id = _pipeline()
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    assert dash["whatif_summary"]["available"] is False


def test_whatif_summary_surfaces_the_most_recent_scenario():
    loc_id, dept_id = _pipeline()
    client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.1, "name": "First"})
    client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.2, "name": "Second"})
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    assert dash["whatif_summary"]["available"] is True
    assert dash["whatif_summary"]["scenario"]["name"] == "Second"


# ---------- Alert logic ----------

def test_alerts_are_a_list_of_dicts_with_severity_and_message():
    loc_id, dept_id = _pipeline(employees_per=4)  # small pool -> likely understaffed
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    for alert in dash["alerts"]:
        assert "severity" in alert and "message" in alert
        assert alert["severity"] in {"high", "medium", "low"}


def test_forecast_bias_alert_fires_only_when_bias_exceeds_threshold():
    summary_low_bias = {"wape": 0.1, "mae": 1, "rmse": 1, "bias": 0.02, "rank": 1, "is_best": True, "folds_evaluated": 3}
    alerts = ed._compute_alerts(None, summary_low_bias)
    assert not any("bias" in a["message"].lower() for a in alerts)

    summary_high_bias = {"wape": 0.1, "mae": 1, "rmse": 1, "bias": -0.25, "rank": 1, "is_best": True, "folds_evaluated": 3}
    alerts = ed._compute_alerts(None, summary_high_bias)
    assert any("bias" in a["message"].lower() and "under-forecasting" in a["message"].lower() for a in alerts)


def test_understaffed_window_detection_finds_the_real_worst_block():
    coverage = [
        {"date": "2026-01-01", "hour": 8, "required": 5, "scheduled": 5, "understaffed": 0, "overstaffed": 0},
        {"date": "2026-01-01", "hour": 9, "required": 10, "scheduled": 5, "understaffed": 5, "overstaffed": 0},
        {"date": "2026-01-01", "hour": 10, "required": 10, "scheduled": 5, "understaffed": 5, "overstaffed": 0},
        {"date": "2026-01-01", "hour": 11, "required": 5, "scheduled": 5, "understaffed": 0, "overstaffed": 0},
    ]
    window = ed._find_worst_contiguous_window(coverage, "understaffed", 2)
    assert window["start_hour"] == 9 and window["end_hour"] == 11
    assert window["avg_gap"] == 5.0


def test_worst_window_returns_none_when_nothing_meets_threshold():
    coverage = [{"date": "2026-01-01", "hour": h, "required": 5, "scheduled": 5, "understaffed": 0, "overstaffed": 0} for h in range(24)]
    assert ed._find_worst_contiguous_window(coverage, "understaffed", 2) is None


def test_full_day_window_formats_as_all_day_not_00_to_24():
    coverage = [{"date": "2026-01-01", "hour": h, "required": 10, "scheduled": 3, "understaffed": 7, "overstaffed": 0} for h in range(24)]
    alerts = ed._compute_alerts({"feasible": True, "summary": {"overtime_hours": 0}, "coverage": coverage, "assignments": []}, None)
    assert any("all day" in a["message"] for a in alerts)
    assert not any("24:00" in a["message"] for a in alerts)


def test_demand_insight_message_direction_matches_the_peak_windows_own_sign():
    """Regression test: the sentence must describe the peak window using its
    OWN sign, not the overall trend's sign - a window can be the biggest
    deviation while moving the opposite direction from the overall average."""
    from datetime import datetime as dt

    # Overall trend is flat/slightly up, but hour 14 specifically drops hard.
    actual_points = [(dt(2026, 1, 1, 14), 100.0), (dt(2026, 1, 2, 14), 100.0)]
    forecast_points = [
        {"timestamp": dt(2026, 1, 8, 10), "predicted_demand": 50.0},
        {"timestamp": dt(2026, 1, 8, 14), "predicted_demand": 10.0},  # big drop at hour 14
    ]
    # Pad actual_points with a matching hour-10 entry so pct_change isn't skewed to None
    actual_points = [(dt(2026, 1, 1, 10), 50.0), (dt(2026, 1, 2, 10), 50.0)] + actual_points

    insight = ed._compute_demand_insight(actual_points, forecast_points, horizon_days=7)
    assert insight["peak_window"]["delta"] < 0
    assert "decrease" in insight["message"].split("occurring")[0].split(",")[-1] or "decrease" in insight["message"]
    # specifically: the clause right before "occurring" must say decrease, not increase
    assert "largest decrease occurring" in insight["message"]


# ---------- Recommendation logic ----------

def test_recommendations_are_real_sentences_not_empty_when_data_exists():
    loc_id, dept_id = _pipeline(employees_per=4)
    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    assert isinstance(dash["recommendations"], list)
    for rec in dash["recommendations"]:
        assert isinstance(rec, str) and len(rec) > 10


# ---------- Filtering ----------

def test_dashboard_filters_by_location_and_department_independently():
    client.post("/api/data/generate", json={
        "days_of_history": 90, "num_locations": 2, "num_departments": 2,
        "employees_per_location_dept": 5, "seed": 73,
    })
    locs = client.get("/api/locations").json()
    depts = client.get("/api/departments").json()
    for loc in locs:
        for dept in depts:
            client.post("/api/forecast", json={"location_id": loc["id"], "department_id": dept["id"], "horizon_days": 7})
            client.post("/api/workforce/requirement", json={"location_id": loc["id"], "department_id": dept["id"]})
            client.post("/api/schedule/generate", json={"location_id": loc["id"], "department_id": dept["id"]})

    dash_a = client.get(f"/api/executive/dashboard?location_id={locs[0]['id']}&department_id={depts[0]['id']}").json()
    dash_b = client.get(f"/api/executive/dashboard?location_id={locs[1]['id']}&department_id={depts[1]['id']}").json()
    assert dash_a["location"]["id"] != dash_b["location"]["id"]
    assert dash_a["department"]["id"] != dash_b["department"]["id"]


def test_dashboard_respects_horizon_days_parameter():
    loc_id, dept_id = _pipeline()
    dash7 = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}&horizon_days=7").json()
    assert dash7["horizon_days"] == 7


# ---------- End-to-end ----------

def test_end_to_end_executive_dashboard_reflects_full_pipeline():
    loc_id, dept_id = _pipeline(employees_per=8, seed=99)
    client.post("/api/scenario/run", json={"location_id": loc_id, "department_id": dept_id, "demand_delta_pct": 0.15, "name": "Peak test"})

    dash = client.get(f"/api/executive/dashboard?location_id={loc_id}&department_id={dept_id}").json()
    assert dash["kpis"]["labor_cost"] is not None
    assert dash["kpis"]["forecast_accuracy_pct"] is not None
    assert dash["demand_outlook"]["insight"]["available"] is True
    assert dash["workforce_capacity"] is not None
    assert dash["labor_cost"]["available"] is True
    assert dash["whatif_summary"]["available"] is True
    assert isinstance(dash["alerts"], list)
    assert isinstance(dash["recommendations"], list)
