"""
What-If Scenario Engine.

Real calculations only, per the product spec:
  - "base" numbers come from the actual currently-persisted forecast/
    requirement/schedule where one exists; if no schedule has been generated
    yet, base is computed by solving once (ephemerally, never persisted) so
    a comparison is still possible.
  - "scenario" numbers come from re-running the REAL workforce-requirement
    math (app.services.workforce_requirement) and the REAL OR-Tools solver
    (app.services.optimization) against perturbed inputs. Nothing here
    re-implements those calculations - this module only perturbs inputs and
    calls the existing single sources of truth.
  - Scenarios are always ephemeral with respect to the live schedule: they
    are recorded to the `Scenario` table for history/audit, but never write
    to WorkforceRequirement, Forecast, or Schedule/ScheduleAssignment.
"""
import json
from dataclasses import replace
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from app import models
from app.services import optimization as opt
from app.services import optimization_service as opt_service
from app.services import workforce_requirement as wr


class NoRequirementError(Exception):
    pass


def _base_optimization_input(db: Session, location_id: int, department_id: int) -> opt.OptimizationInput:
    return opt_service.load_optimization_input(db, location_id, department_id, 32, 1.5)


def _base_requirement_rows(db: Session, location_id: int, department_id: int):
    rows = (
        db.query(models.WorkforceRequirement)
        .filter(models.WorkforceRequirement.location_id == location_id)
        .filter(models.WorkforceRequirement.department_id == department_id)
        .order_by(models.WorkforceRequirement.timestamp.asc())
        .all()
    )
    if not rows:
        raise NoRequirementError(
            "No workforce requirement found for this location/department. "
            "Generate one first via POST /api/workforce/requirement."
        )
    return rows


def _schedule_summary_from_details(details: dict) -> dict:
    return {
        "total_labor_cost": round(details["total_cost_cents"] / 100.0, 2),
        "total_shifts": len(details["assignments"]),
        "overtime_shifts": details["total_overtime_shifts"],
        "overtime_hours": details.get("total_overtime_hours", 0),
        "avg_coverage_pct": details["avg_coverage_pct"],
        "understaffed_hours": details["understaffed_hours"],
        "overstaffed_hours": details["overstaffed_hours"],
    }


def _get_base_schedule_summary(db: Session, location_id: int, department_id: int, base_inp: opt.OptimizationInput) -> dict:
    """Uses the real persisted schedule if one exists; otherwise solves once
    ephemerally (never persisted) purely so a base-case comparison exists."""
    stored = opt_service.load_stored(db, location_id, department_id)
    if stored is not None and stored["feasible"]:
        return {
            "total_labor_cost": stored["summary"]["total_labor_cost"],
            "total_shifts": stored["summary"]["total_shifts"],
            "overtime_shifts": stored["summary"]["overtime_shifts"],
            "overtime_hours": stored["summary"].get("overtime_hours", 0),
            "avg_coverage_pct": stored["summary"]["avg_coverage_pct"],
            "understaffed_hours": stored["summary"]["understaffed_hours"],
            "overstaffed_hours": stored["summary"]["overstaffed_hours"],
        }, True, None

    result = opt.solve(base_inp)
    if not result.feasible:
        return None, False, result.infeasibility_reason
    details = opt.compute_schedule_details(base_inp, result.raw_assignments)
    return _schedule_summary_from_details(details), True, None


def _build_executive_summary(name: str, additional_headcount: int, additional_labor_cost: float) -> str:
    parts = []
    if additional_headcount > 0:
        parts.append(f"requires {additional_headcount} additional employee{'s' if additional_headcount != 1 else ''}")
    elif additional_headcount < 0:
        parts.append(f"frees up {abs(additional_headcount)} employee{'s' if additional_headcount != -1 else ''}")

    if additional_labor_cost > 0:
        parts.append(f"approximately ${additional_labor_cost:,.0f} in additional weekly labor cost")
    elif additional_labor_cost < 0:
        parts.append(f"approximately ${abs(additional_labor_cost):,.0f} in weekly labor cost savings")

    if not parts:
        return f'"{name}" has minimal impact on required staffing and labor cost.'
    return f'"{name}" ' + " and ".join(parts) + "."


def run_scenario(
    db: Session, location_id: int, department_id: int,
    demand_delta_pct: float = 0.0, absenteeism_delta_pct: float = 0.0,
    productivity_delta_pct: float = 0.0, cost_delta_pct: float = 0.0,
    name: Optional[str] = None,
) -> dict:
    base_rows = _base_requirement_rows(db, location_id, department_id)
    base_inp = _base_optimization_input(db, location_id, department_id)

    # Phase 3's requirement rows carry the productivity/shrinkage assumptions
    # actually used to generate them - the single source of truth for "what
    # are the current assumptions" that this scenario perturbs.
    base_productivity = base_rows[0].productivity_per_hour
    base_shrinkage_pct = base_rows[0].shrinkage_pct

    scenario_productivity = base_productivity * (1 + productivity_delta_pct)
    scenario_shrinkage_total = base_shrinkage_pct + absenteeism_delta_pct
    scenario_shrinkage = wr.ShrinkageInputs(absence_pct=scenario_shrinkage_total, breaks_pct=0.0, training_pct=0.0, other_pct=0.0)
    wr.validate_assumptions(scenario_productivity, scenario_shrinkage)  # raises InvalidAssumptionError if impossible

    base_shrinkage = wr.ShrinkageInputs(absence_pct=base_shrinkage_pct, breaks_pct=0.0, training_pct=0.0, other_pct=0.0)

    base_requirement_points = []
    scenario_requirement_points = []
    scenario_required_headcount = {}
    for r in base_rows:
        base_point = wr.compute_headcount_for_demand(r.forecast_demand, base_productivity, base_shrinkage)
        base_requirement_points.append(base_point)

        scenario_demand = r.forecast_demand * (1 + demand_delta_pct)
        scenario_point = wr.compute_headcount_for_demand(scenario_demand, scenario_productivity, scenario_shrinkage)
        scenario_requirement_points.append(scenario_point)
        scenario_required_headcount[(r.timestamp.date(), r.timestamp.hour)] = scenario_point["required_headcount"]

    base_req_summary = wr.summarize([{"required_headcount": p["required_headcount"]} for p in base_requirement_points])
    scenario_req_summary = wr.summarize([{"required_headcount": p["required_headcount"]} for p in scenario_requirement_points])

    base_schedule_summary, base_feasible, base_infeasible_reason = _get_base_schedule_summary(db, location_id, department_id, base_inp)

    # Scenario optimization input: perturbed required headcount + cost-scaled employees
    scenario_employees = [
        replace(e, hourly_cost_cents=int(round(e.hourly_cost_cents * (1 + cost_delta_pct))))
        for e in base_inp.employees
    ]
    scenario_inp = opt.OptimizationInput(
        employees=scenario_employees, shifts=base_inp.shifts, dates=base_inp.dates,
        required_headcount=scenario_required_headcount,
        overtime_threshold_hours_per_week=base_inp.overtime_threshold_hours_per_week,
        overtime_multiplier=base_inp.overtime_multiplier,
    )
    scenario_result = opt.solve(scenario_inp)
    if scenario_result.feasible:
        scenario_details = opt.compute_schedule_details(scenario_inp, scenario_result.raw_assignments)
        scenario_schedule_summary = _schedule_summary_from_details(scenario_details)
        scenario_feasible = True
        scenario_infeasible_reason = None
    else:
        scenario_schedule_summary = None
        scenario_feasible = False
        scenario_infeasible_reason = scenario_result.infeasibility_reason

    additional_headcount = scenario_req_summary["peak_required_headcount"] - base_req_summary["peak_required_headcount"]
    additional_labor_hours = scenario_req_summary["total_labor_hours"] - base_req_summary["total_labor_hours"]

    if base_schedule_summary and scenario_schedule_summary:
        additional_labor_cost = round(scenario_schedule_summary["total_labor_cost"] - base_schedule_summary["total_labor_cost"], 2)
        overtime_hours_delta = scenario_schedule_summary["overtime_hours"] - base_schedule_summary["overtime_hours"]
        coverage_pct_delta = round(scenario_schedule_summary["avg_coverage_pct"] - base_schedule_summary["avg_coverage_pct"], 1)
        understaffed_hours_delta = scenario_schedule_summary["understaffed_hours"] - base_schedule_summary["understaffed_hours"]
    else:
        additional_labor_cost = 0.0
        overtime_hours_delta = 0
        coverage_pct_delta = 0.0
        understaffed_hours_delta = 0

    scenario_name = name or _default_scenario_name(demand_delta_pct, absenteeism_delta_pct, productivity_delta_pct, cost_delta_pct)
    executive_summary = _build_executive_summary(scenario_name, additional_headcount, additional_labor_cost)

    response = {
        "name": scenario_name,
        "inputs": {
            "demand_delta_pct": demand_delta_pct, "absenteeism_delta_pct": absenteeism_delta_pct,
            "productivity_delta_pct": productivity_delta_pct, "cost_delta_pct": cost_delta_pct,
        },
        "base": {
            "requirement": base_req_summary, "schedule": base_schedule_summary,
            "feasible": base_feasible, "infeasibility_reason": base_infeasible_reason,
        },
        "scenario": {
            "requirement": scenario_req_summary, "schedule": scenario_schedule_summary,
            "feasible": scenario_feasible, "infeasibility_reason": scenario_infeasible_reason,
        },
        "delta": {
            "additional_headcount": additional_headcount,
            "additional_labor_hours": additional_labor_hours,
            "additional_labor_cost": additional_labor_cost,
            "overtime_hours_delta": overtime_hours_delta,
            "coverage_pct_delta": coverage_pct_delta,
            "understaffed_hours_delta": understaffed_hours_delta,
        },
        "executive_summary": executive_summary,
        "generated_at": datetime.utcnow().isoformat(),
    }

    scenario_row = models.Scenario(
        name=scenario_name, location_id=location_id, department_id=department_id,
        demand_delta_pct=demand_delta_pct, absenteeism_delta_pct=absenteeism_delta_pct,
        productivity_delta_pct=productivity_delta_pct, cost_delta_pct=cost_delta_pct,
        created_at=datetime.utcnow(), result_json=json.dumps(response),
    )
    db.add(scenario_row)
    db.commit()
    db.refresh(scenario_row)
    response["scenario_id"] = scenario_row.id
    return response


def _default_scenario_name(demand_delta_pct, absenteeism_delta_pct, productivity_delta_pct, cost_delta_pct) -> str:
    parts = []
    if demand_delta_pct:
        parts.append(f"Demand {demand_delta_pct:+.0%}")
    if absenteeism_delta_pct:
        parts.append(f"Absenteeism {absenteeism_delta_pct:+.0%}")
    if productivity_delta_pct:
        parts.append(f"Productivity {productivity_delta_pct:+.0%}")
    if cost_delta_pct:
        parts.append(f"Cost {cost_delta_pct:+.0%}")
    return ", ".join(parts) if parts else "No change"


def list_scenarios(db: Session, location_id: int, department_id: int) -> list:
    rows = (
        db.query(models.Scenario)
        .filter(models.Scenario.location_id == location_id)
        .filter(models.Scenario.department_id == department_id)
        .order_by(models.Scenario.created_at.desc())
        .all()
    )
    out = []
    for r in rows:
        try:
            result = json.loads(r.result_json) if r.result_json else {}
        except (TypeError, ValueError):
            result = {}
        out.append({
            "scenario_id": r.id, "name": r.name, "created_at": r.created_at.isoformat(),
            "demand_delta_pct": r.demand_delta_pct, "absenteeism_delta_pct": r.absenteeism_delta_pct,
            "productivity_delta_pct": r.productivity_delta_pct, "cost_delta_pct": r.cost_delta_pct,
            "delta": result.get("delta"), "executive_summary": result.get("executive_summary"),
        })
    return out
