from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session
from sqlalchemy import delete

from app import models
from app.services import workforce_requirement as wr


class NoForecastError(Exception):
    pass


def generate_and_store(
    db: Session,
    location_id: int,
    department_id: int,
    productivity_per_hour: Optional[float],
    shrinkage: wr.ShrinkageInputs,
) -> dict:
    forecast_rows = (
        db.query(models.Forecast)
        .filter(models.Forecast.location_id == location_id)
        .filter(models.Forecast.department_id == department_id)
        .filter(models.Forecast.is_best_model.is_(True))
        .order_by(models.Forecast.timestamp.asc())
        .all()
    )
    if not forecast_rows:
        raise NoForecastError(
            "No forecast found for this location/department. "
            "Generate a forecast first via POST /api/forecast."
        )

    if productivity_per_hour is None:
        dept = db.query(models.Department).filter(models.Department.id == department_id).first()
        productivity_per_hour = dept.default_productivity_per_hour if dept else 8.0

    wr.validate_assumptions(productivity_per_hour, shrinkage)  # raises InvalidAssumptionError early

    demand_points = [(f.timestamp, f.predicted_demand) for f in forecast_rows]
    rows = wr.compute_requirement_series(demand_points, productivity_per_hour, shrinkage)
    summary = wr.summarize(rows)

    generated_at = datetime.utcnow()

    db.execute(
        delete(models.WorkforceRequirement)
        .where(models.WorkforceRequirement.location_id == location_id)
        .where(models.WorkforceRequirement.department_id == department_id)
    )
    for r in rows:
        db.add(models.WorkforceRequirement(
            location_id=location_id, department_id=department_id,
            timestamp=r["timestamp"], forecast_demand=r["forecast_demand"],
            productivity_per_hour=r["productivity_per_hour"], shrinkage_pct=r["shrinkage_pct"],
            base_headcount=r["base_headcount"], required_headcount=r["required_headcount"],
            generated_at=generated_at,
        ))
    db.commit()

    return {
        "location_id": location_id,
        "department_id": department_id,
        "productivity_per_hour": productivity_per_hour,
        "shrinkage_pct": round(shrinkage.total, 4),
        "shrinkage_breakdown": {
            "absence_pct": shrinkage.absence_pct,
            "breaks_pct": shrinkage.breaks_pct,
            "training_pct": shrinkage.training_pct,
            "other_pct": shrinkage.other_pct,
        },
        "summary": summary,
        "points": rows,
        "generated_at": generated_at,
    }


def load_stored(db: Session, location_id: int, department_id: int) -> Optional[dict]:
    rows_db = (
        db.query(models.WorkforceRequirement)
        .filter(models.WorkforceRequirement.location_id == location_id)
        .filter(models.WorkforceRequirement.department_id == department_id)
        .order_by(models.WorkforceRequirement.timestamp.asc())
        .all()
    )
    if not rows_db:
        return None

    rows = [
        {
            "timestamp": r.timestamp, "forecast_demand": r.forecast_demand,
            "productivity_per_hour": r.productivity_per_hour, "shrinkage_pct": r.shrinkage_pct,
            "base_headcount": r.base_headcount, "required_headcount": r.required_headcount,
        }
        for r in rows_db
    ]
    summary = wr.summarize(rows)
    first = rows_db[0]

    return {
        "location_id": location_id,
        "department_id": department_id,
        "productivity_per_hour": first.productivity_per_hour,
        "shrinkage_pct": first.shrinkage_pct,
        "shrinkage_breakdown": None,  # not persisted per-component; total is authoritative
        "summary": summary,
        "points": rows,
        "generated_at": first.generated_at,
    }
