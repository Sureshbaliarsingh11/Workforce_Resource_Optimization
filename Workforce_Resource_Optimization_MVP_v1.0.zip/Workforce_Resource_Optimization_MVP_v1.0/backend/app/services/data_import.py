"""
CSV / Excel data import: validate-then-commit, with a simple column-mapping
layer so uploaded files don't have to exactly match the internal schema.

Design:
  - `preview_import` parses the file, suggests a column mapping using simple
    name-matching heuristics, validates against the suggested (or caller-
    supplied) mapping, and returns a report - it never writes to the
    database.
  - `commit_import` re-validates (never trusts a stale preview) and only
    then writes rows, inside a single transaction per call.
  - Both share one validation implementation per data type so there is
    exactly one definition of "valid" - preview and commit can never disagree.
"""
import io
from datetime import datetime
from typing import Optional

import pandas as pd
from sqlalchemy.orm import Session

from app import models

SUPPORTED_TYPES = {"demand", "employees", "availability", "skills", "productivity"}

# Internal field -> plausible uploaded column name variants, used to suggest
# a default mapping. Matching is case-insensitive and ignores spaces/underscores.
FIELD_ALIASES = {
    "demand": {
        "timestamp": ["date", "timestamp", "datetime", "hour", "period"],
        "location": ["location", "store", "site"],
        "department": ["department", "dept", "team"],
        "demand": ["demand", "volume", "transactions", "value", "count"],
    },
    "employees": {
        "employee_id": ["employee_id", "worker_id", "id", "empid", "staffid"],
        "name": ["name", "employee_name", "full_name"],
        "location": ["location", "store", "site"],
        "department": ["department", "dept", "team"],
        "employment_type": ["employment_type", "type", "worker_type"],
        "hourly_cost": ["hourly_cost", "hourly_rate", "rate", "pay_rate", "wage"],
        "max_weekly_hours": ["max_weekly_hours", "weekly_hours", "max_hours_week"],
        "max_daily_hours": ["max_daily_hours", "daily_hours", "max_hours_day"],
        "preferred_shift": ["preferred_shift", "shift_preference", "preferred"],
    },
    "availability": {
        "employee_id": ["employee_id", "worker_id", "id", "empid", "staffid"],
        "day_of_week": ["day_of_week", "day", "weekday"],
        "start_hour": ["start_hour", "available_start", "from_hour"],
        "end_hour": ["end_hour", "available_end", "to_hour"],
    },
    "skills": {
        "employee_id": ["employee_id", "worker_id", "id", "empid", "staffid"],
        "skill": ["skill", "skill_name", "capability"],
    },
    "productivity": {
        "department": ["department", "dept", "team"],
        "productivity_per_hour": ["productivity_per_hour", "productivity", "units_per_hour", "rate"],
    },
}

REQUIRED_FIELDS = {
    "demand": ["timestamp", "location", "department", "demand"],
    "employees": ["employee_id", "name", "location", "department", "hourly_cost"],
    "availability": ["employee_id", "day_of_week", "start_hour", "end_hour"],
    "skills": ["employee_id", "skill"],
    "productivity": ["department", "productivity_per_hour"],
}


class UnsupportedDataTypeError(Exception):
    pass


class FileParseError(Exception):
    pass


def _normalize(s: str) -> str:
    return str(s).strip().lower().replace(" ", "_").replace("-", "_")


def parse_file(filename: str, content: bytes) -> pd.DataFrame:
    lower = filename.lower()
    try:
        if lower.endswith(".csv"):
            return pd.read_csv(io.BytesIO(content))
        if lower.endswith(".xlsx") or lower.endswith(".xls"):
            return pd.read_excel(io.BytesIO(content))
    except Exception as e:
        raise FileParseError(f"Could not read '{filename}': {e}")
    raise FileParseError(f"Unsupported file type for '{filename}' - please upload a .csv or .xlsx file.")


def suggest_mapping(data_type: str, columns: list) -> dict:
    if data_type not in SUPPORTED_TYPES:
        raise UnsupportedDataTypeError(f"Unknown data type '{data_type}'.")
    normalized_columns = {_normalize(c): c for c in columns}
    mapping = {}
    for field, aliases in FIELD_ALIASES[data_type].items():
        for alias in aliases:
            if alias in normalized_columns:
                mapping[field] = normalized_columns[alias]
                break
    return mapping


def _validate_dataframe(data_type: str, df: pd.DataFrame, mapping: dict, db: Session) -> dict:
    errors, warnings = [], []
    required = REQUIRED_FIELDS[data_type]
    missing_required = [f for f in required if f not in mapping or mapping[f] not in df.columns]
    if missing_required:
        errors.append(f"Missing required column mapping for: {', '.join(missing_required)}.")
        return {"valid_rows": 0, "total_rows": len(df), "errors": errors, "warnings": warnings}

    renamed = df.rename(columns={v: k for k, v in mapping.items()})
    total_rows = len(renamed)
    valid_mask = pd.Series([True] * total_rows)

    if data_type == "demand":
        renamed["timestamp"] = pd.to_datetime(renamed["timestamp"], errors="coerce")
        bad_dates = renamed["timestamp"].isna()
        if bad_dates.any():
            errors.append(f"{int(bad_dates.sum())} row(s) have an unparseable date/timestamp.")
            valid_mask &= ~bad_dates
        renamed["demand"] = pd.to_numeric(renamed["demand"], errors="coerce")
        bad_demand = renamed["demand"].isna()
        if bad_demand.any():
            errors.append(f"{int(bad_demand.sum())} row(s) have a non-numeric demand value.")
            valid_mask &= ~bad_demand
        negative = renamed["demand"] < 0
        if negative.any():
            errors.append(f"{int(negative.sum())} row(s) have negative demand, which is not physically valid.")
            valid_mask &= ~negative
        missing_loc = renamed["location"].isna() | renamed["department"].isna()
        if missing_loc.any():
            errors.append(f"{int(missing_loc.sum())} row(s) are missing location or department.")
            valid_mask &= ~missing_loc
        dup_key = renamed[["location", "department", "timestamp"]].astype(str).agg("|".join, axis=1)
        dup_mask = dup_key.duplicated(keep="first")
        if dup_mask.any():
            warnings.append(f"{int(dup_mask.sum())} duplicate (location, department, timestamp) row(s) found - only the first of each will be imported.")
            valid_mask &= ~dup_mask

    elif data_type == "employees":
        missing_id = renamed["employee_id"].isna()
        if missing_id.any():
            errors.append(f"{int(missing_id.sum())} row(s) are missing an employee ID.")
            valid_mask &= ~missing_id
        dup_ids = renamed["employee_id"].astype(str).duplicated(keep="first")
        if dup_ids.any():
            errors.append(f"{int(dup_ids.sum())} duplicate employee ID(s) found.")
            valid_mask &= ~dup_ids
        renamed["hourly_cost"] = pd.to_numeric(renamed["hourly_cost"], errors="coerce")
        bad_cost = renamed["hourly_cost"].isna() | (renamed["hourly_cost"] <= 0)
        if bad_cost.any():
            errors.append(f"{int(bad_cost.sum())} row(s) have a missing or non-positive hourly cost.")
            valid_mask &= ~bad_cost
        missing_loc = renamed["location"].isna() | renamed["department"].isna()
        if missing_loc.any():
            errors.append(f"{int(missing_loc.sum())} row(s) are missing location or department.")
            valid_mask &= ~missing_loc
        if "max_weekly_hours" in renamed.columns:
            missing_wk = pd.to_numeric(renamed["max_weekly_hours"], errors="coerce").isna()
            if missing_wk.any():
                warnings.append(f"{int(missing_wk.sum())} row(s) missing max_weekly_hours - will default to 40.")

    elif data_type == "availability":
        known_ids = {e.external_id for e in db.query(models.Employee.external_id).all() if e[0]} if db else set()
        renamed["day_of_week"] = pd.to_numeric(renamed["day_of_week"], errors="coerce")
        renamed["start_hour"] = pd.to_numeric(renamed["start_hour"], errors="coerce")
        renamed["end_hour"] = pd.to_numeric(renamed["end_hour"], errors="coerce")
        bad_day = ~renamed["day_of_week"].between(0, 6)
        if bad_day.any():
            errors.append(f"{int(bad_day.sum())} row(s) have an invalid day_of_week (must be 0-6).")
            valid_mask &= ~bad_day
        bad_hours = ~renamed["start_hour"].between(0, 23) | ~renamed["end_hour"].between(0, 23)
        if bad_hours.any():
            errors.append(f"{int(bad_hours.sum())} row(s) have start/end hours outside 0-23.")
            valid_mask &= ~bad_hours
        bad_order = renamed["start_hour"] >= renamed["end_hour"]
        if bad_order.any():
            errors.append(f"{int(bad_order.sum())} row(s) have a start_hour at or after end_hour.")
            valid_mask &= ~bad_order
        if known_ids:
            unknown = ~renamed["employee_id"].astype(str).isin({str(i) for i in known_ids})
            if unknown.any():
                errors.append(f"{int(unknown.sum())} row(s) reference an employee_id not found in imported employees.")
                valid_mask &= ~unknown

    elif data_type == "skills":
        known_ids = {e.external_id for e in db.query(models.Employee.external_id).all() if e[0]} if db else set()
        missing = renamed["employee_id"].isna() | renamed["skill"].isna()
        if missing.any():
            errors.append(f"{int(missing.sum())} row(s) are missing employee_id or skill.")
            valid_mask &= ~missing
        if known_ids:
            unknown = ~renamed["employee_id"].astype(str).isin({str(i) for i in known_ids})
            if unknown.any():
                errors.append(f"{int(unknown.sum())} row(s) reference an employee_id not found in imported employees.")
                valid_mask &= ~unknown

    elif data_type == "productivity":
        renamed["productivity_per_hour"] = pd.to_numeric(renamed["productivity_per_hour"], errors="coerce")
        bad = renamed["productivity_per_hour"].isna() | (renamed["productivity_per_hour"] <= 0)
        if bad.any():
            errors.append(f"{int(bad.sum())} row(s) have a missing or non-positive productivity value.")
            valid_mask &= ~bad

    valid_rows = int(valid_mask.sum())
    return {
        "valid_rows": valid_rows, "total_rows": total_rows,
        "errors": errors, "warnings": warnings,
        "_renamed": renamed, "_valid_mask": valid_mask,  # internal, stripped before returning to API
    }


def preview_import(data_type: str, filename: str, content: bytes, db: Session, mapping_override: Optional[dict] = None) -> dict:
    if data_type not in SUPPORTED_TYPES:
        raise UnsupportedDataTypeError(f"Unknown data type '{data_type}'. Supported: {', '.join(sorted(SUPPORTED_TYPES))}.")
    df = parse_file(filename, content)
    if df.empty:
        raise FileParseError("The uploaded file has no data rows.")
    mapping = mapping_override or suggest_mapping(data_type, list(df.columns))
    report = _validate_dataframe(data_type, df, mapping, db)
    return {
        "data_type": data_type, "detected_columns": list(df.columns), "suggested_mapping": mapping,
        "total_rows": report["total_rows"], "valid_rows": report["valid_rows"],
        "errors": report["errors"], "warnings": report["warnings"],
    }


def commit_import(data_type: str, filename: str, content: bytes, mapping: dict, db: Session) -> dict:
    if data_type not in SUPPORTED_TYPES:
        raise UnsupportedDataTypeError(f"Unknown data type '{data_type}'.")
    df = parse_file(filename, content)
    if df.empty:
        raise FileParseError("The uploaded file has no data rows.")
    report = _validate_dataframe(data_type, df, mapping, db)
    if report["errors"] and report["valid_rows"] == 0:
        return {
            "imported_rows": 0, "total_rows": report["total_rows"],
            "errors": report["errors"], "warnings": report["warnings"],
        }

    renamed = report["_renamed"][report["_valid_mask"]].copy()
    imported = 0

    if data_type == "demand":
        loc_cache, dept_cache = {}, {}
        for _, row in renamed.iterrows():
            loc = _get_or_create_location(db, loc_cache, str(row["location"]))
            dept = _get_or_create_department(db, dept_cache, str(row["department"]))
            db.add(models.DemandHistory(
                location_id=loc.id, department_id=dept.id, timestamp=row["timestamp"].to_pydatetime(),
                demand=float(row["demand"]), is_holiday=False, is_promotion=False,
            ))
            imported += 1
        db.commit()

    elif data_type == "employees":
        loc_cache, dept_cache = {}, {}
        for _, row in renamed.iterrows():
            loc = _get_or_create_location(db, loc_cache, str(row["location"]))
            dept = _get_or_create_department(db, dept_cache, str(row["department"]))
            db.add(models.Employee(
                name=str(row.get("name") or row["employee_id"]), external_id=str(row["employee_id"]),
                location_id=loc.id, department_id=dept.id,
                employment_type=str(row["employment_type"]) if "employment_type" in renamed.columns and pd.notna(row.get("employment_type")) else "full_time",
                hourly_cost=float(row["hourly_cost"]),
                max_weekly_hours=float(row["max_weekly_hours"]) if "max_weekly_hours" in renamed.columns and pd.notna(row.get("max_weekly_hours")) else 40.0,
                max_daily_hours=float(row["max_daily_hours"]) if "max_daily_hours" in renamed.columns and pd.notna(row.get("max_daily_hours")) else 8.0,
                preferred_shift=str(row["preferred_shift"]) if "preferred_shift" in renamed.columns and pd.notna(row.get("preferred_shift")) else None,
                active=True,
            ))
            imported += 1
        db.commit()

    elif data_type == "availability":
        emp_by_ext = {e.external_id: e for e in db.query(models.Employee).filter(models.Employee.external_id.isnot(None)).all()}
        for _, row in renamed.iterrows():
            emp = emp_by_ext.get(str(row["employee_id"]))
            if emp is None:
                continue
            db.add(models.EmployeeAvailability(
                employee_id=emp.id, day_of_week=int(row["day_of_week"]),
                available_start_hour=int(row["start_hour"]), available_end_hour=int(row["end_hour"]),
            ))
            imported += 1
        db.commit()

    elif data_type == "skills":
        emp_by_ext = {e.external_id: e for e in db.query(models.Employee).filter(models.Employee.external_id.isnot(None)).all()}
        skill_cache = {s.name: s for s in db.query(models.Skill).all()}
        for _, row in renamed.iterrows():
            emp = emp_by_ext.get(str(row["employee_id"]))
            if emp is None:
                continue
            skill_name = str(row["skill"])
            skill = skill_cache.get(skill_name)
            if skill is None:
                skill = models.Skill(name=skill_name)
                db.add(skill)
                db.flush()
                skill_cache[skill_name] = skill
            db.add(models.EmployeeSkill(employee_id=emp.id, skill_id=skill.id))
            imported += 1
        db.commit()

    elif data_type == "productivity":
        dept_cache = {d.name: d for d in db.query(models.Department).all()}
        for _, row in renamed.iterrows():
            dept = dept_cache.get(str(row["department"]))
            if dept is None:
                continue
            dept.default_productivity_per_hour = float(row["productivity_per_hour"])
            imported += 1
        db.commit()

    return {
        "imported_rows": imported, "total_rows": report["total_rows"],
        "errors": report["errors"], "warnings": report["warnings"],
    }


def _get_or_create_location(db: Session, cache: dict, name: str) -> models.Location:
    if name in cache:
        return cache[name]
    loc = db.query(models.Location).filter(models.Location.name == name).first()
    if loc is None:
        loc = models.Location(name=name, region="Imported")
        db.add(loc)
        db.flush()
    cache[name] = loc
    return loc


def _get_or_create_department(db: Session, cache: dict, name: str) -> models.Department:
    if name in cache:
        return cache[name]
    dept = db.query(models.Department).filter(models.Department.name == name).first()
    if dept is None:
        dept = models.Department(name=name, default_productivity_per_hour=8.0)
        db.add(dept)
        db.flush()
    cache[name] = dept
    return dept
