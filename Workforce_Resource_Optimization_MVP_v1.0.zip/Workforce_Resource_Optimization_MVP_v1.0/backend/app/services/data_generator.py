"""
Synthetic data generator for the Version 1 prototype.

Scale (per section 3 of the build spec): 1 region, 2 locations, 3 departments,
20-30 employees, 90 days of hourly demand history. Deliberately small so the
forecasting/optimization engines in later phases iterate fast; the schema
supports scaling this up later without changes.
"""
import random
from datetime import datetime, timedelta

from sqlalchemy.orm import Session
from sqlalchemy import delete

from app import models

LOCATION_NAMES = ["Location A", "Location B", "Location C", "Location D"]
DEPARTMENT_NAMES = ["Customer Service", "Sales", "Operations", "Technical Support"]
SKILL_NAMES = ["Phone Support", "Chat Support", "Order Processing", "Upselling", "Escalations"]
SHIFT_NAMES = [
    ("Morning", 6, 14),
    ("Day", 8, 16),
    ("Evening", 14, 22),
    ("Part-time", 10, 14),
]

# Each department has a designated primary skill. Every employee in that
# department is guaranteed to hold it, so the optimizer's "required skills"
# hard constraint is meaningful and testable (an employee lacking it truly
# cannot be scheduled), not just a rubber-stamp "has at least one skill" check.
DEPARTMENT_PRIMARY_SKILL = {
    "Customer Service": "Phone Support",
    "Sales": "Upselling",
    "Operations": "Order Processing",
    "Technical Support": "Escalations",
}

REGION = "North America"


def _hourly_seasonality_factor(hour: int) -> float:
    """Business hours curve: low overnight, peaks mid-morning and mid-afternoon."""
    # Simple bimodal curve over 0-23h
    base = {
        0: 0.05, 1: 0.03, 2: 0.02, 3: 0.02, 4: 0.03, 5: 0.08,
        6: 0.18, 7: 0.35, 8: 0.6, 9: 0.85, 10: 1.0, 11: 0.95,
        12: 0.8, 13: 0.85, 14: 0.95, 15: 1.0, 16: 0.9, 17: 0.7,
        18: 0.5, 19: 0.35, 20: 0.25, 21: 0.15, 22: 0.1, 23: 0.07,
    }
    return base[hour]


def _day_of_week_factor(dow: int) -> float:
    """0=Monday ... 6=Sunday. Weekends lower for a B2B-style contact center."""
    factors = {0: 1.0, 1: 1.05, 2: 1.05, 3: 1.0, 4: 0.95, 5: 0.55, 6: 0.4}
    return factors[dow]


def _is_holiday(d) -> bool:
    # A handful of fixed synthetic "holidays" spaced through the year for demo purposes
    holiday_month_days = {(1, 1), (7, 4), (11, 28), (12, 25), (12, 31)}
    return (d.month, d.day) in holiday_month_days


def generate_all(
    db: Session,
    days_of_history: int = 90,
    num_locations: int = 2,
    num_departments: int = 3,
    employees_per_location_dept: int = 5,
    seed: int = 42,
):
    rng = random.Random(seed)

    # Wipe existing generated data so re-running is idempotent
    for model in [
        models.DemandHistory, models.EmployeeAvailability, models.EmployeeSkill,
        models.ScheduleAssignment, models.Schedule,
        models.ScheduleOptimizedSnapshot, models.ScheduleUndoBuffer, models.ScheduleDraft,
        models.Scenario,
        models.Forecast, models.ForecastModelRun, models.WorkforceRequirement,
        models.ActualWorkforce, models.Employee, models.Skill,
        models.Department, models.Location,
    ]:
        db.execute(delete(model))
    db.commit()

    # --- Locations ---
    locations = []
    for i in range(num_locations):
        loc = models.Location(name=LOCATION_NAMES[i % len(LOCATION_NAMES)], region=REGION)
        db.add(loc)
        locations.append(loc)
    db.flush()

    # --- Departments ---
    dept_productivity = {"Customer Service": 8.0, "Sales": 6.0, "Operations": 10.0, "Technical Support": 5.0}
    departments = []
    for i in range(num_departments):
        name = DEPARTMENT_NAMES[i % len(DEPARTMENT_NAMES)]
        dept = models.Department(name=name, default_productivity_per_hour=dept_productivity.get(name, 8.0))
        db.add(dept)
        departments.append(dept)
    db.flush()

    # --- Skills ---
    skills = []
    skill_by_name = {}
    for name in SKILL_NAMES:
        sk = models.Skill(name=name)
        db.add(sk)
        skills.append(sk)
    db.flush()
    for sk in skills:
        skill_by_name[sk.name] = sk

    # --- Shift templates ---
    for name, start, end in SHIFT_NAMES:
        db.add(models.ShiftTemplate(name=name, start_hour=start, end_hour=end))
    db.flush()

    # --- Employees ---
    first_names = ["Aisha", "Wei", "Carlos", "Priya", "Liam", "Fatima", "Noah", "Yuki",
                   "Sofia", "Omar", "Emma", "Raj", "Chen", "Maria", "James", "Layla",
                   "Ben", "Anika", "Diego", "Grace", "Ivan", "Mei", "Tariq", "Nina",
                   "Hassan", "Zoe", "Kofi", "Elena", "Sam", "Ravi"]
    last_names = ["Khan", "Silva", "Nguyen", "Patel", "Brown", "Garcia", "Kim", "Ito",
                  "Rossi", "Haddad", "Clark", "Singh", "Wang", "Lopez", "Turner"]

    employees = []
    employee_department_map = []
    emp_counter = 0
    for loc in locations:
        for dept in departments:
            for _ in range(employees_per_location_dept):
                emp_counter += 1
                name = f"{rng.choice(first_names)} {rng.choice(last_names)}"
                employment_type = rng.choices(["full_time", "part_time"], weights=[0.75, 0.25])[0]
                base_cost = rng.uniform(16.0, 28.0)
                emp = models.Employee(
                    name=name,
                    location_id=loc.id,
                    department_id=dept.id,
                    employment_type=employment_type,
                    hourly_cost=round(base_cost, 2),
                    max_weekly_hours=25.0 if employment_type == "part_time" else 40.0,
                    max_daily_hours=6.0 if employment_type == "part_time" else 8.0,
                    preferred_shift=rng.choice([s[0] for s in SHIFT_NAMES]),
                    active=True,
                )
                db.add(emp)
                employees.append(emp)
                employee_department_map.append((emp, dept))
    db.flush()

    # --- Employee skills ---
    # Most employees hold their department's primary skill (see
    # DEPARTMENT_PRIMARY_SKILL); a small fraction don't yet (e.g. still in
    # training), which makes the optimizer's skill constraint genuinely bind
    # rather than being a rubber stamp.
    for emp, dept in employee_department_map:
        primary_name = DEPARTMENT_PRIMARY_SKILL.get(dept.name)
        primary_skill = skill_by_name.get(primary_name) if primary_name else None
        has_primary = rng.random() < 0.85
        chosen = set()
        if primary_skill and has_primary:
            chosen.add(primary_skill)
        remaining = [s for s in skills if s not in chosen]
        extra_count = rng.randint(0, 1) if chosen else rng.randint(1, 2)
        if remaining and extra_count:
            chosen.update(rng.sample(remaining, k=min(extra_count, len(remaining))))
        for sk in chosen:
            db.add(models.EmployeeSkill(employee_id=emp.id, skill_id=sk.id))

    # --- Employee availability (most employees available most days; some part-timers limited) ---
    for emp in employees:
        days_available = range(7) if emp.employment_type == "full_time" else rng.sample(range(7), k=5)
        for dow in days_available:
            if emp.employment_type == "part_time":
                start_h = rng.choice([6, 10, 14])
                end_h = start_h + 4
            else:
                start_h, end_h = 6, 22
            db.add(models.EmployeeAvailability(
                employee_id=emp.id, day_of_week=dow,
                available_start_hour=start_h, available_end_hour=end_h,
            ))
    db.commit()

    # --- Demand history (hourly, per location+department) ---
    end_date = datetime.utcnow().replace(minute=0, second=0, microsecond=0)
    start_date = end_date - timedelta(days=days_of_history)

    # Give each (location, department) pair a distinct base volume so charts look realistic
    demand_rows = 0
    batch = []
    for loc in locations:
        for dept in departments:
            base_volume = rng.uniform(40, 120)  # peak-hour transactions
            trend_drift = rng.uniform(-0.05, 0.15)  # mild growth/decline over the window, as fraction
            promo_days = set(rng.sample(range(days_of_history), k=max(1, days_of_history // 20)))

            current = start_date
            day_index = 0
            while current < end_date:
                if current.hour == 0:
                    day_index += 1
                dow = current.weekday()
                hour_factor = _hourly_seasonality_factor(current.hour)
                day_factor = _day_of_week_factor(dow)
                trend_factor = 1.0 + trend_drift * (day_index / max(days_of_history, 1))
                holiday = _is_holiday(current)
                promotion = day_index in promo_days

                value = base_volume * hour_factor * day_factor * trend_factor
                if holiday:
                    value *= 0.3
                if promotion:
                    value *= rng.uniform(1.3, 1.7)

                # random noise + occasional spike
                noise = rng.gauss(0, 0.08)
                spike = 0.0
                if rng.random() < 0.01:
                    spike = value * rng.uniform(0.5, 1.2)
                value = max(0.0, value * (1 + noise) + spike)

                batch.append(models.DemandHistory(
                    location_id=loc.id, department_id=dept.id,
                    timestamp=current, demand=round(value, 1),
                    is_holiday=holiday, is_promotion=promotion,
                ))
                demand_rows += 1
                current += timedelta(hours=1)

                if len(batch) >= 5000:
                    db.bulk_save_objects(batch)
                    batch = []

    if batch:
        db.bulk_save_objects(batch)
    db.commit()

    return {
        "locations_created": len(locations),
        "departments_created": len(departments),
        "employees_created": len(employees),
        "demand_rows_created": demand_rows,
        "date_range_start": start_date,
        "date_range_end": end_date,
    }
