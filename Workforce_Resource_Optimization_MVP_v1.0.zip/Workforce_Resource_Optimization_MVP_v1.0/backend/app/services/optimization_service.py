"""
Schedule generation orchestration.

Single source of truth rule: required headcount comes ONLY from the
WorkforceRequirement rows already persisted by Phase 3
(workforce_requirement_service.generate_and_store). This module does not
recompute demand -> headcount itself; if no requirement has been generated
yet, it raises NoRequirementError rather than silently deriving one.

Status tracking: every Schedule row for a location/department carries a
status of "optimized" (fresh solver output) or "modified" (a manager has
hand-edited at least one assignment since). schedule_editor.py flips this to
"modified" on a manual edit; generate_and_store and revert_to_optimized both
reset it to "optimized".
"""
import json
from collections import defaultdict
from datetime import datetime, date as date_type
from typing import Optional, List

from sqlalchemy.orm import Session
from sqlalchemy import delete

from app import models
from app.services import optimization as opt

DEPARTMENT_PRIMARY_SKILL = {
    "Customer Service": "Phone Support",
    "Sales": "Upselling",
    "Operations": "Order Processing",
    "Technical Support": "Escalations",
}


class NoRequirementError(Exception):
    pass


class NoEmployeesError(Exception):
    pass


def load_optimization_input(
    db: Session, location_id: int, department_id: int,
    overtime_threshold_hours_per_week: int, overtime_multiplier: float,
) -> opt.OptimizationInput:
    requirement_rows = (
        db.query(models.WorkforceRequirement)
        .filter(models.WorkforceRequirement.location_id == location_id)
        .filter(models.WorkforceRequirement.department_id == department_id)
        .order_by(models.WorkforceRequirement.timestamp.asc())
        .all()
    )
    if not requirement_rows:
        raise NoRequirementError(
            "No workforce requirement found for this location/department. "
            "Generate one first via POST /api/workforce/requirement."
        )

    required_headcount = {}
    dates_set = set()
    for r in requirement_rows:
        d = r.timestamp.date()
        dates_set.add(d)
        required_headcount[(d, r.timestamp.hour)] = r.required_headcount
    dates = sorted(dates_set)

    dept = db.query(models.Department).filter(models.Department.id == department_id).first()
    primary_skill_name = DEPARTMENT_PRIMARY_SKILL.get(dept.name) if dept else None

    employees_db = (
        db.query(models.Employee)
        .filter(models.Employee.location_id == location_id)
        .filter(models.Employee.department_id == department_id)
        .filter(models.Employee.active.is_(True))
        .all()
    )
    if not employees_db:
        raise NoEmployeesError("No active employees exist for this location/department.")

    shift_templates = db.query(models.ShiftTemplate).all()
    shifts = [opt.ShiftDef(id=s.id, name=s.name, start_hour=s.start_hour, end_hour=s.end_hour) for s in shift_templates]

    employee_defs = []
    for emp in employees_db:
        has_skill = True
        if primary_skill_name:
            skill_names = {es.skill.name for es in emp.skills}
            has_skill = primary_skill_name in skill_names

        availability = tuple(
            (a.day_of_week, a.available_start_hour, a.available_end_hour)
            for a in emp.availability
        )

        employee_defs.append(opt.EmployeeDef(
            id=emp.id, name=emp.name,
            hourly_cost_cents=int(round(emp.hourly_cost * 100)),
            max_daily_hours=int(emp.max_daily_hours),
            max_weekly_hours=int(emp.max_weekly_hours),
            has_required_skill=has_skill,
            preferred_shift=emp.preferred_shift,
            availability=availability,
        ))

    return opt.OptimizationInput(
        employees=employee_defs, shifts=shifts, dates=dates,
        required_headcount=required_headcount,
        overtime_threshold_hours_per_week=overtime_threshold_hours_per_week,
        overtime_multiplier=overtime_multiplier,
    )


def load_current_raw_assignments(db: Session, location_id: int, department_id: int) -> List[opt.RawAssignment]:
    schedules = (
        db.query(models.Schedule)
        .filter(models.Schedule.location_id == location_id)
        .filter(models.Schedule.department_id == department_id)
        .all()
    )
    schedule_by_id = {s.id: s for s in schedules}
    if not schedules:
        return []
    assignment_rows = (
        db.query(models.ScheduleAssignment)
        .filter(models.ScheduleAssignment.schedule_id.in_(list(schedule_by_id.keys())))
        .all()
    )
    return [
        opt.RawAssignment(
            employee_id=a.employee_id,
            date=schedule_by_id[a.schedule_id].date,
            shift_id=a.shift_template_id,
        )
        for a in assignment_rows
    ]


def _wipe_current_schedule(db: Session, location_id: int, department_id: int) -> None:
    old_schedule_ids = [
        row.id for row in
        db.query(models.Schedule.id)
        .filter(models.Schedule.location_id == location_id)
        .filter(models.Schedule.department_id == department_id)
        .all()
    ]
    if old_schedule_ids:
        db.execute(delete(models.ScheduleAssignment).where(models.ScheduleAssignment.schedule_id.in_(old_schedule_ids)))
        db.execute(delete(models.Schedule).where(models.Schedule.id.in_(old_schedule_ids)))
        db.commit()


def persist_assignments(
    db: Session, location_id: int, department_id: int,
    details: dict, generated_at: datetime, schedule_status: str,
) -> None:
    """Wipes any existing schedule for this location/department and writes
    the given (already-validated) assignment details as the new current
    state. Shared by generate, revert, and manual-edit commits so there is
    exactly one persistence code path."""
    _wipe_current_schedule(db, location_id, department_id)

    by_date = defaultdict(list)
    for a in details["assignments"]:
        by_date[a.date].append(a)

    for d, assignments_for_day in by_date.items():
        total_cost = sum(a.cost_cents for a in assignments_for_day) / 100.0
        sched = models.Schedule(
            location_id=location_id, department_id=department_id, date=d,
            created_at=generated_at, total_cost=round(total_cost, 2), status=schedule_status,
        )
        db.add(sched)
        db.flush()
        for a in assignments_for_day:
            db.add(models.ScheduleAssignment(
                schedule_id=sched.id, employee_id=a.employee_id, shift_template_id=a.shift_id,
                start_hour=a.start_hour, end_hour=a.end_hour, cost=round(a.cost_cents / 100.0, 2),
                is_overtime=a.is_overtime,
            ))
    db.commit()


def save_optimized_snapshot(
    db: Session, location_id: int, department_id: int,
    raw_assignments: List[opt.RawAssignment], overtime_threshold_hours_per_week: int, overtime_multiplier: float,
) -> None:
    db.execute(
        delete(models.ScheduleOptimizedSnapshot)
        .where(models.ScheduleOptimizedSnapshot.location_id == location_id)
        .where(models.ScheduleOptimizedSnapshot.department_id == department_id)
    )
    payload = [[a.employee_id, a.date.isoformat(), a.shift_id] for a in raw_assignments]
    db.add(models.ScheduleOptimizedSnapshot(
        location_id=location_id, department_id=department_id,
        assignments_json=json.dumps(payload),
        overtime_threshold_hours_per_week=overtime_threshold_hours_per_week,
        overtime_multiplier=overtime_multiplier,
        created_at=datetime.utcnow(),
    ))
    db.commit()


def generate_and_store(
    db: Session, location_id: int, department_id: int,
    overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5,
) -> dict:
    inp = load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    result = opt.solve(inp)
    generated_at = datetime.utcnow()

    _wipe_current_schedule(db, location_id, department_id)
    # A fresh (re-)generate always invalidates any pending single-level undo
    # and any in-progress manager draft (both would reference a now-stale baseline).
    db.execute(
        delete(models.ScheduleUndoBuffer)
        .where(models.ScheduleUndoBuffer.location_id == location_id)
        .where(models.ScheduleUndoBuffer.department_id == department_id)
    )
    db.execute(
        delete(models.ScheduleDraft)
        .where(models.ScheduleDraft.location_id == location_id)
        .where(models.ScheduleDraft.department_id == department_id)
    )
    db.commit()

    if not result.feasible:
        return {
            "location_id": location_id, "department_id": department_id,
            "feasible": False, "status": result.status, "schedule_status": None,
            "infeasibility_reason": result.infeasibility_reason,
            "assignments": [], "summary": None, "coverage": [], "generated_at": generated_at,
        }

    details = opt.compute_schedule_details(inp, result.raw_assignments)
    if not details["valid"]:
        return {
            "location_id": location_id, "department_id": department_id,
            "feasible": False, "status": "VALIDATION_FAILED", "schedule_status": None,
            "infeasibility_reason": "Solver produced a schedule that failed independent validation: "
                                     + "; ".join(details["errors"][:5]),
            "assignments": [], "summary": None, "coverage": [], "generated_at": generated_at,
        }

    persist_assignments(db, location_id, department_id, details, generated_at, "optimized")
    save_optimized_snapshot(db, location_id, department_id, result.raw_assignments,
                             overtime_threshold_hours_per_week, overtime_multiplier)

    return build_response(location_id, department_id, True, "FEASIBLE", None, details, generated_at, "optimized")


def revert_to_optimized(db: Session, location_id: int, department_id: int) -> dict:
    snapshot = (
        db.query(models.ScheduleOptimizedSnapshot)
        .filter(models.ScheduleOptimizedSnapshot.location_id == location_id)
        .filter(models.ScheduleOptimizedSnapshot.department_id == department_id)
        .first()
    )
    if snapshot is None:
        raise NoRequirementError(  # reused error type: "nothing to act on yet" family
            "No optimized schedule exists yet to revert to. Generate one first via POST /api/schedule/generate."
        )
    inp = load_optimization_input(
        db, location_id, department_id,
        snapshot.overtime_threshold_hours_per_week, snapshot.overtime_multiplier,
    )
    payload = json.loads(snapshot.assignments_json)
    raw = [opt.RawAssignment(employee_id=eid, date=date_type.fromisoformat(d), shift_id=sid) for eid, d, sid in payload]
    details = opt.compute_schedule_details(inp, raw)
    generated_at = datetime.utcnow()
    persist_assignments(db, location_id, department_id, details, generated_at, "optimized")
    db.execute(
        delete(models.ScheduleUndoBuffer)
        .where(models.ScheduleUndoBuffer.location_id == location_id)
        .where(models.ScheduleUndoBuffer.department_id == department_id)
    )
    db.execute(
        delete(models.ScheduleDraft)
        .where(models.ScheduleDraft.location_id == location_id)
        .where(models.ScheduleDraft.department_id == department_id)
    )
    db.commit()
    return build_response(location_id, department_id, True, "FEASIBLE", None, details, generated_at, "optimized")


def build_response(location_id, department_id, feasible, status, infeasibility_reason, details, generated_at, schedule_status) -> dict:
    assignments_out = [
        {
            "employee_id": a.employee_id, "employee_name": a.employee_name,
            "date": a.date, "shift_id": a.shift_id, "shift_name": a.shift_name,
            "start_hour": a.start_hour, "end_hour": a.end_hour, "hours": a.hours,
            "cost": round(a.cost_cents / 100.0, 2), "is_overtime": a.is_overtime,
        }
        for a in details["assignments"]
    ]
    coverage_out = [
        {
            "date": c["date"], "hour": c["hour"], "required": c["required"], "scheduled": c["scheduled"],
            "understaffed": c["understaffed"], "overstaffed": c["overstaffed"],
        }
        for c in details["coverage"]
    ]
    summary = {
        "total_labor_cost": round(details["total_cost_cents"] / 100.0, 2),
        "total_shifts": len(details["assignments"]),
        "overtime_shifts": details["total_overtime_shifts"],
        "overtime_hours": details["total_overtime_hours"],
        "avg_coverage_pct": details["avg_coverage_pct"],
        "understaffed_hours": details["understaffed_hours"],
        "overstaffed_hours": details["overstaffed_hours"],
        "total_hours_covered": details["total_hours_covered"],
    }
    return {
        "location_id": location_id, "department_id": department_id,
        "feasible": feasible, "status": status, "schedule_status": schedule_status,
        "infeasibility_reason": infeasibility_reason,
        "assignments": assignments_out, "summary": summary, "coverage": coverage_out,
        "generated_at": generated_at,
    }


def load_stored(db: Session, location_id: int, department_id: int) -> Optional[dict]:
    """
    Reconstructs the full response (assignments/summary/coverage) by feeding
    the persisted (employee_id, date, shift_id) decisions back through the
    same compute_schedule_details() used everywhere else - one definition of
    "the schedule's numbers", not a second hand-rolled aggregation.
    """
    schedules = (
        db.query(models.Schedule)
        .filter(models.Schedule.location_id == location_id)
        .filter(models.Schedule.department_id == department_id)
        .order_by(models.Schedule.date.asc())
        .all()
    )
    if not schedules:
        return None

    raw = load_current_raw_assignments(db, location_id, department_id)
    inp = load_optimization_input(db, location_id, department_id, 32, 1.5)
    details = opt.compute_schedule_details(inp, raw)

    schedule_status = "modified" if any(s.status == "modified" for s in schedules) else "optimized"
    generated_at = max(s.created_at for s in schedules)

    return build_response(location_id, department_id, True, "FEASIBLE", None, details, generated_at, schedule_status)
