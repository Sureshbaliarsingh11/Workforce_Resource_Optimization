"""
Demand forecasting engine.

Models: Seasonal Naive, (seasonal) Moving Average, Exponential Smoothing
(Holt-Winters via statsmodels). Selection is based on rolling-window /
walk-forward backtesting - never a random train/test split, since that
leaks future information into the past for time series.

Metric safety: WAPE and Bias divide by sum(|actual|), which is 0 only if an
entire fold has zero demand throughout (extremely unlikely in real data, but
handled). MAPE divides per-point by |actual|, so zero-demand points are
excluded from the MAPE average rather than producing inf/NaN - the excluded
count is reported so the number is honestly qualified.
"""
from datetime import timedelta
from typing import List, Optional

import numpy as np
import pandas as pd
from statsmodels.tsa.holtwinters import ExponentialSmoothing

MODEL_SEASONAL_NAIVE = "seasonal_naive"
MODEL_MOVING_AVERAGE = "moving_average"
MODEL_EXP_SMOOTHING = "exponential_smoothing"
ALL_MODELS = [MODEL_SEASONAL_NAIVE, MODEL_MOVING_AVERAGE, MODEL_EXP_SMOOTHING]

MIN_TRAIN_HOURS = 14 * 24  # require at least 2 weeks of training history per fold
DEFAULT_FOLDS = 3


def rows_to_series(rows: List[tuple]) -> pd.Series:
    """rows: list of (timestamp, demand), any order -> continuous hourly pd.Series."""
    idx = pd.DatetimeIndex([r[0] for r in rows])
    vals = [float(r[1]) for r in rows]
    s = pd.Series(vals, index=idx).sort_index()
    s = s[~s.index.duplicated(keep="last")]
    full_idx = pd.date_range(s.index.min(), s.index.max(), freq="h")
    s = s.reindex(full_idx)
    s = s.interpolate(limit_direction="both")
    return s


def seasonal_naive_forecast(train: pd.Series, horizon_timestamps: List[pd.Timestamp]) -> List[float]:
    preds = []
    for ts in horizon_timestamps:
        lookup = ts - timedelta(days=7)
        if lookup in train.index:
            preds.append(max(0.0, float(train[lookup])))
        else:
            same_hour = train[train.index.hour == ts.hour]
            preds.append(max(0.0, float(same_hour.mean()) if len(same_hour) else float(train.mean())))
    return preds


def moving_average_forecast(train: pd.Series, horizon_timestamps: List[pd.Timestamp], weeks: int = 4) -> List[float]:
    preds = []
    for ts in horizon_timestamps:
        vals = []
        for w in range(1, weeks + 1):
            lookup = ts - timedelta(days=7 * w)
            if lookup in train.index:
                vals.append(float(train[lookup]))
        if vals:
            preds.append(max(0.0, float(np.mean(vals))))
        else:
            same_hour = train[train.index.hour == ts.hour]
            preds.append(max(0.0, float(same_hour.mean()) if len(same_hour) else float(train.mean())))
    return preds


def exponential_smoothing_forecast(train: pd.Series, horizon_hours: int) -> Optional[List[float]]:
    """Holt-Winters with daily seasonality. Returns None if fitting fails
    (e.g. too little data, degenerate/constant series) so the caller can
    fall back rather than crash."""
    try:
        if train.std() < 1e-6 or len(train) < 24 * 7:
            return None
        model = ExponentialSmoothing(
            train, trend="add", seasonal="add", seasonal_periods=24,
            initialization_method="estimated",
        )
        fit = model.fit(optimized=True)
        preds = fit.forecast(horizon_hours)
        out = [max(0.0, float(v)) for v in preds]
        if any(np.isnan(out)):
            return None
        return out
    except Exception:
        return None


def run_model(model_name: str, train: pd.Series, horizon_timestamps: List[pd.Timestamp]) -> List[float]:
    if model_name == MODEL_SEASONAL_NAIVE:
        return seasonal_naive_forecast(train, horizon_timestamps)
    if model_name == MODEL_MOVING_AVERAGE:
        return moving_average_forecast(train, horizon_timestamps)
    if model_name == MODEL_EXP_SMOOTHING:
        preds = exponential_smoothing_forecast(train, len(horizon_timestamps))
        return preds if preds is not None else seasonal_naive_forecast(train, horizon_timestamps)
    raise ValueError(f"Unknown model: {model_name}")


def compute_metrics(actual: List[float], forecast: List[float]) -> dict:
    a = np.array(actual, dtype=float)
    f = np.array(forecast, dtype=float)
    errors = f - a
    abs_errors = np.abs(errors)

    mae = float(np.mean(abs_errors))
    rmse = float(np.sqrt(np.mean(errors ** 2)))

    sum_abs_actual = float(np.sum(np.abs(a)))
    wape = float(np.sum(abs_errors) / sum_abs_actual) if sum_abs_actual > 0 else None
    bias = float(np.sum(errors) / sum_abs_actual) if sum_abs_actual > 0 else None

    nonzero = a != 0
    mape = float(np.mean(abs_errors[nonzero] / np.abs(a[nonzero]))) if nonzero.sum() > 0 else None

    return {
        "mae": round(mae, 3),
        "rmse": round(rmse, 3),
        "wape": round(wape, 4) if wape is not None else None,
        "mape": round(mape, 4) if mape is not None else None,
        "bias": round(bias, 4) if bias is not None else None,
        "excluded_zero_actual_points": int((~nonzero).sum()),
    }


def build_folds(series: pd.Series, horizon_hours: int, n_folds: int = DEFAULT_FOLDS):
    """Walk-forward folds: train on everything up to a cutoff, test on the
    next `horizon_hours`. Cutoffs step backwards in horizon-sized increments
    from the end of the series. This is time-ordered validation, never a
    random split."""
    total_hours = len(series)
    max_possible_folds = (total_hours - MIN_TRAIN_HOURS) // horizon_hours
    folds_to_run = max(0, min(n_folds, max_possible_folds))

    windows = []
    for k in range(folds_to_run, 0, -1):
        cutoff_idx = total_hours - k * horizon_hours
        if cutoff_idx < MIN_TRAIN_HOURS:
            continue
        train_slice = series.iloc[:cutoff_idx]
        test_slice = series.iloc[cutoff_idx: cutoff_idx + horizon_hours]
        if len(test_slice) < horizon_hours:
            continue
        windows.append((train_slice, test_slice))
    return windows


def rolling_backtest(series: pd.Series, horizon_hours: int, n_folds: int = DEFAULT_FOLDS) -> dict:
    """Returns {model_name: {wape, mae, rmse, bias, folds_evaluated} or None}."""
    fold_windows = build_folds(series, horizon_hours, n_folds)

    per_model_folds = {m: [] for m in ALL_MODELS}
    for train_slice, test_slice in fold_windows:
        horizon_ts = list(test_slice.index)
        actual = list(test_slice.values)
        for model_name in ALL_MODELS:
            try:
                preds = run_model(model_name, train_slice, horizon_ts)
                per_model_folds[model_name].append(compute_metrics(actual, preds))
            except Exception:
                continue

    summary = {}
    for model_name, fold_metrics in per_model_folds.items():
        if not fold_metrics:
            summary[model_name] = None
            continue
        wapes = [m["wape"] for m in fold_metrics if m["wape"] is not None]
        biases = [m["bias"] for m in fold_metrics if m["bias"] is not None]
        summary[model_name] = {
            "wape": round(float(np.mean(wapes)), 4) if wapes else None,
            "mae": round(float(np.mean([m["mae"] for m in fold_metrics])), 3),
            "rmse": round(float(np.mean([m["rmse"] for m in fold_metrics])), 3),
            "bias": round(float(np.mean(biases)), 4) if biases else None,
            "folds_evaluated": len(fold_metrics),
        }
    return summary, len(fold_windows)


def select_best_model(summary: dict) -> Optional[str]:
    """Lowest average WAPE wins. Models with no WAPE (e.g. every fold had
    zero demand) are ranked last by falling back to MAE."""
    candidates = [(name, m) for name, m in summary.items() if m is not None]
    if not candidates:
        return None
    with_wape = [(n, m) for n, m in candidates if m["wape"] is not None]
    if with_wape:
        return min(with_wape, key=lambda x: x[1]["wape"])[0]
    return min(candidates, key=lambda x: x[1]["mae"])[0]


def rank_models(summary: dict) -> dict:
    """Returns {model_name: rank (1 = best)}, ranked by WAPE then MAE."""
    items = [(name, m) for name, m in summary.items() if m is not None]

    def sort_key(item):
        _, m = item
        return (m["wape"] if m["wape"] is not None else float("inf"), m["mae"])

    items.sort(key=sort_key)
    ranks = {name: i + 1 for i, (name, _) in enumerate(items)}
    for name, m in summary.items():
        if m is None:
            ranks[name] = None
    return ranks
