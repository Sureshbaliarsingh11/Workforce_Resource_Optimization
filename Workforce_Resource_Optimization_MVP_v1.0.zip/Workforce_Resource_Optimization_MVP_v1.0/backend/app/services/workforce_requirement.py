"""
Workforce requirement engine.

Converts forecasted demand into required headcount:

    base_headcount     = ceil(forecast_demand / productivity_per_hour)
    required_headcount = ceil(base_headcount / (1 - total_shrinkage))

Shrinkage components (absence, breaks, training, other) are summed into a
single fraction. Validation is strict: productivity must be positive, and
total shrinkage must be in [0, 1) - at 100% shrinkage the required headcount
is mathematically infinite, so that's rejected rather than silently
producing inf/NaN.
"""
import math
from dataclasses import dataclass
from typing import List, Optional


class InvalidAssumptionError(ValueError):
    pass


@dataclass
class ShrinkageInputs:
    absence_pct: float = 0.05
    breaks_pct: float = 0.05
    training_pct: float = 0.03
    other_pct: float = 0.0

    @property
    def total(self) -> float:
        return self.absence_pct + self.breaks_pct + self.training_pct + self.other_pct


def validate_assumptions(productivity_per_hour: float, shrinkage: ShrinkageInputs) -> None:
    if productivity_per_hour <= 0:
        raise InvalidAssumptionError("productivity_per_hour must be greater than 0")
    for name, val in [
        ("absence_pct", shrinkage.absence_pct), ("breaks_pct", shrinkage.breaks_pct),
        ("training_pct", shrinkage.training_pct), ("other_pct", shrinkage.other_pct),
    ]:
        if val < 0:
            raise InvalidAssumptionError(f"{name} cannot be negative")
    if shrinkage.total >= 1.0:
        raise InvalidAssumptionError(
            f"Total shrinkage ({shrinkage.total * 100:.1f}%) must be less than 100% - "
            "at or above 100% shrinkage, no finite headcount can cover the requirement."
        )


def compute_headcount_for_demand(
    demand: float, productivity_per_hour: float, shrinkage: ShrinkageInputs
) -> dict:
    validate_assumptions(productivity_per_hour, shrinkage)
    base = math.ceil(max(0.0, demand) / productivity_per_hour)
    required = math.ceil(base / (1 - shrinkage.total)) if base > 0 else 0
    return {
        "forecast_demand": round(demand, 1),
        "base_headcount": base,
        "required_headcount": required,
    }


def compute_requirement_series(
    demand_points: List[tuple],  # list of (timestamp, demand)
    productivity_per_hour: float,
    shrinkage: ShrinkageInputs,
) -> List[dict]:
    """Returns one row per input point with the full transparent breakdown."""
    validate_assumptions(productivity_per_hour, shrinkage)
    results = []
    for ts, demand in demand_points:
        row = compute_headcount_for_demand(demand, productivity_per_hour, shrinkage)
        row["timestamp"] = ts
        row["productivity_per_hour"] = productivity_per_hour
        row["shrinkage_pct"] = round(shrinkage.total, 4)
        results.append(row)
    return results


def summarize(rows: List[dict]) -> dict:
    if not rows:
        return {
            "peak_required_headcount": 0, "avg_required_headcount": 0.0,
            "total_labor_hours": 0, "hours_covered": 0,
        }
    required = [r["required_headcount"] for r in rows]
    return {
        "peak_required_headcount": max(required),
        "avg_required_headcount": round(sum(required) / len(required), 2),
        "total_labor_hours": sum(required),  # 1 hour per headcount-hour row
        "hours_covered": len(rows),
    }
