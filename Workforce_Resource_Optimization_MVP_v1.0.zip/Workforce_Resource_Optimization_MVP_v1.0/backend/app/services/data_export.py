"""
Local CSV export for each pipeline artifact. No external service - builds a
pandas DataFrame from data already loaded by the relevant phase's own
load_stored function and returns CSV bytes.
"""
import io
import json
from typing import Optional

import pandas as pd
from sqlalchemy.orm import Session

from app import models
from app.services import forecast_service
from app.services import workforce_requirement_service as wrs
from app.services import optimization_service as opt_service
from app.services import scenario_engine
from app.services import executive_dashboard


class NothingToExportError(Exception):
    pass


def _to_csv_bytes(df: pd.DataFrame) -> bytes:
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


def export_forecast(db: Session, location_id: int, department_id: int) -> bytes:
    data = forecast_service.load_stored(db, location_id, department_id)
    if data is None:
        raise NothingToExportError("No forecast has been generated yet for this location/department.")
    df = pd.DataFrame(data["forecast_points"])
    return _to_csv_bytes(df)


def export_requirement(db: Session, location_id: int, department_id: int) -> bytes:
    data = wrs.load_stored(db, location_id, department_id)
    if data is None:
        raise NothingToExportError("No workforce requirement has been generated yet for this location/department.")
    df = pd.DataFrame(data["points"])
    return _to_csv_bytes(df)


def export_schedule(db: Session, location_id: int, department_id: int) -> bytes:
    data = opt_service.load_stored(db, location_id, department_id)
    if data is None:
        raise NothingToExportError("No schedule has been generated yet for this location/department.")
    df = pd.DataFrame(data["assignments"])
    return _to_csv_bytes(df)


def export_scenario(db: Session, scenario_id: int) -> bytes:
    row = db.query(models.Scenario).filter(models.Scenario.id == scenario_id).first()
    if row is None:
        raise NothingToExportError(f"Scenario {scenario_id} not found.")
    result = json.loads(row.result_json) if row.result_json else {}
    flat = {
        "name": row.name, "demand_delta_pct": row.demand_delta_pct,
        "absenteeism_delta_pct": row.absenteeism_delta_pct, "productivity_delta_pct": row.productivity_delta_pct,
        "cost_delta_pct": row.cost_delta_pct, "executive_summary": result.get("executive_summary"),
    }
    delta = result.get("delta", {})
    flat.update({f"delta_{k}": v for k, v in delta.items()})
    df = pd.DataFrame([flat])
    return _to_csv_bytes(df)


def export_executive_summary(db: Session, location_id: int, department_id: int, horizon_days: int = 7) -> bytes:
    dash = executive_dashboard.get_executive_dashboard(db, location_id, department_id, horizon_days)
    flat = dict(dash["kpis"])
    flat["location"] = dash["location"]["name"] if dash["location"] else None
    flat["department"] = dash["department"]["name"] if dash["department"] else None
    flat["generated_at"] = dash["generated_at"]
    df = pd.DataFrame([flat])
    return _to_csv_bytes(df)
