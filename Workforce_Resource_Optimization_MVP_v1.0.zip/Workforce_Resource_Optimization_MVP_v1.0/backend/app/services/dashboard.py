"""
Dashboard aggregation service.

RULE (per build spec section 26): every number shown on the dashboard must be
computed from real generated/stored data - never hardcoded or randomly
displayed. In Phase 1, forecast and schedule don't exist yet, so those KPIs
are honestly reported as unavailable rather than faked.
"""
from datetime import timedelta
from sqlalchemy.orm import Session
from sqlalchemy import func

from app import models


def get_summary(db: Session) -> dict:
    total_locations = db.query(models.Location).count()
    total_departments = db.query(models.Department).count()
    total_employees = db.query(models.Employee).filter(models.Employee.active.is_(True)).count()

    latest = db.query(func.max(models.DemandHistory.timestamp)).scalar()
    earliest = db.query(func.min(models.DemandHistory.timestamp)).scalar()

    total_demand_7d = 0.0
    avg_hourly_7d = 0.0
    peak_hourly_7d = 0.0
    data_days_available = 0

    if latest and earliest:
        window_start = latest - timedelta(days=7)
        rows = (
            db.query(models.DemandHistory.demand)
            .filter(models.DemandHistory.timestamp >= window_start)
            .filter(models.DemandHistory.timestamp <= latest)
            .all()
        )
        values = [r[0] for r in rows]
        if values:
            total_demand_7d = sum(values)
            avg_hourly_7d = total_demand_7d / len(values)
            peak_hourly_7d = max(values)
        data_days_available = (latest - earliest).days

    has_forecast = db.query(models.Forecast).count() > 0
    has_workforce_requirement = db.query(models.WorkforceRequirement).count() > 0
    has_schedule = db.query(models.Schedule).count() > 0

    return {
        "total_locations": total_locations,
        "total_departments": total_departments,
        "total_employees": total_employees,
        "total_demand_last_7_days": round(total_demand_7d, 1),
        "avg_hourly_demand_last_7_days": round(avg_hourly_7d, 1),
        "peak_hourly_demand_last_7_days": round(peak_hourly_7d, 1),
        "data_days_available": data_days_available,
        "has_forecast": has_forecast,
        "has_workforce_requirement": has_workforce_requirement,
        "has_schedule": has_schedule,
    }
