from datetime import datetime, timedelta

from sqlalchemy.orm import Session
from sqlalchemy import delete

from app import models
from app.services import forecasting as fc


class InsufficientDataError(Exception):
    pass


def _load_series(db: Session, location_id: int, department_id: int):
    rows = (
        db.query(models.DemandHistory.timestamp, models.DemandHistory.demand)
        .filter(models.DemandHistory.location_id == location_id)
        .filter(models.DemandHistory.department_id == department_id)
        .order_by(models.DemandHistory.timestamp.asc())
        .all()
    )
    if len(rows) < fc.MIN_TRAIN_HOURS + 24:
        raise InsufficientDataError(
            f"Only {len(rows)} hours of demand history available; "
            f"need at least {fc.MIN_TRAIN_HOURS + 24} to backtest and forecast."
        )
    return fc.rows_to_series([(r[0], r[1]) for r in rows])


def generate_and_store(db: Session, location_id: int, department_id: int, horizon_days: int) -> dict:
    if horizon_days not in (7, 14):
        raise ValueError("horizon_days must be 7 or 14")

    series = _load_series(db, location_id, department_id)
    horizon_hours = horizon_days * 24

    summary, folds_evaluated = fc.rolling_backtest(series, horizon_hours)
    best_model = fc.select_best_model(summary)
    if best_model is None:
        raise InsufficientDataError("Could not evaluate any model on this data window.")
    ranks = fc.rank_models(summary)

    generated_at = datetime.utcnow()

    # --- Persist model comparison (wipe previous runs for this loc/dept/horizon) ---
    db.execute(
        delete(models.ForecastModelRun)
        .where(models.ForecastModelRun.location_id == location_id)
        .where(models.ForecastModelRun.department_id == department_id)
        .where(models.ForecastModelRun.horizon_days == horizon_days)
    )
    for model_name in fc.ALL_MODELS:
        m = summary.get(model_name)
        db.add(models.ForecastModelRun(
            location_id=location_id, department_id=department_id,
            model_name=model_name, horizon_days=horizon_days,
            wape=m["wape"] if m else None,
            mae=m["mae"] if m else None,
            rmse=m["rmse"] if m else None,
            bias=m["bias"] if m else None,
            rank=ranks.get(model_name),
            is_best=(model_name == best_model),
            folds_evaluated=m["folds_evaluated"] if m else 0,
            generated_at=generated_at,
        ))

    # --- Retrain each model on the FULL series and forecast the real future horizon ---
    last_ts = series.index.max()
    horizon_timestamps = [last_ts + timedelta(hours=i) for i in range(1, horizon_hours + 1)]

    db.execute(
        delete(models.Forecast)
        .where(models.Forecast.location_id == location_id)
        .where(models.Forecast.department_id == department_id)
    )
    forecast_points = []
    for model_name in fc.ALL_MODELS:
        try:
            preds = fc.run_model(model_name, series, horizon_timestamps)
        except Exception:
            continue
        is_best = model_name == best_model
        for ts, val in zip(horizon_timestamps, preds):
            db.add(models.Forecast(
                location_id=location_id, department_id=department_id,
                timestamp=ts, model_name=model_name, predicted_demand=round(val, 1),
                generated_at=generated_at, is_best_model=is_best,
            ))
            if is_best:
                forecast_points.append({
                    "timestamp": ts, "model_name": model_name,
                    "predicted_demand": round(val, 1), "is_best_model": True,
                })
    db.commit()

    model_comparison = []
    for model_name in fc.ALL_MODELS:
        m = summary.get(model_name)
        model_comparison.append({
            "model_name": model_name,
            "wape": m["wape"] if m else None,
            "mae": m["mae"] if m else None,
            "rmse": m["rmse"] if m else None,
            "bias": m["bias"] if m else None,
            "rank": ranks.get(model_name),
            "is_best": model_name == best_model,
            "folds_evaluated": m["folds_evaluated"] if m else 0,
        })

    return {
        "location_id": location_id,
        "department_id": department_id,
        "horizon_days": horizon_days,
        "best_model": best_model,
        "folds_evaluated": folds_evaluated,
        "model_comparison": model_comparison,
        "forecast_points": forecast_points,
        "generated_at": generated_at,
    }


def load_stored(db: Session, location_id: int, department_id: int):
    runs = (
        db.query(models.ForecastModelRun)
        .filter(models.ForecastModelRun.location_id == location_id)
        .filter(models.ForecastModelRun.department_id == department_id)
        .order_by(models.ForecastModelRun.generated_at.desc())
        .all()
    )
    if not runs:
        return None

    latest_generated_at = runs[0].generated_at
    latest_horizon = runs[0].horizon_days
    latest_runs = [
        r for r in runs
        if r.generated_at == latest_generated_at and r.horizon_days == latest_horizon
    ]

    best_model = next((r.model_name for r in latest_runs if r.is_best), None)

    forecast_rows = (
        db.query(models.Forecast)
        .filter(models.Forecast.location_id == location_id)
        .filter(models.Forecast.department_id == department_id)
        .filter(models.Forecast.is_best_model.is_(True))
        .order_by(models.Forecast.timestamp.asc())
        .all()
    )

    return {
        "location_id": location_id,
        "department_id": department_id,
        "horizon_days": latest_horizon,
        "best_model": best_model,
        "folds_evaluated": max((r.folds_evaluated for r in latest_runs), default=0),
        "model_comparison": [
            {
                "model_name": r.model_name, "wape": r.wape, "mae": r.mae,
                "rmse": r.rmse, "bias": r.bias, "rank": r.rank, "is_best": r.is_best,
                "folds_evaluated": r.folds_evaluated,
            }
            for r in sorted(latest_runs, key=lambda r: (r.rank is None, r.rank))
        ],
        "forecast_points": [
            {
                "timestamp": f.timestamp, "model_name": f.model_name,
                "predicted_demand": f.predicted_demand, "is_best_model": f.is_best_model,
            }
            for f in forecast_rows
        ],
        "generated_at": latest_generated_at,
    }
