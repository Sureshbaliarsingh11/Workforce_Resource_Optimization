"""
Manager Schedule Experience - manual edits on top of the Phase 4 solver output.

Design rules carried over from Phase 4:
  - Business calculations live here in Python, never duplicated in React.
  - Every accepted edit is persisted immediately to SQLite (the backend
    remains the single source of truth - nothing lives only in frontend
    memory).
  - Hard-constraint checks reuse the exact same EmployeeDef/ShiftDef/
    OptimizationInput/compute_schedule_details machinery Phase 4 uses, so
    there is exactly one definition of "valid schedule" in the whole app.
"""
import json
from datetime import datetime, date as date_type
from typing import Optional, List

from sqlalchemy.orm import Session
from sqlalchemy import delete

from app import models
from app.services import optimization as opt
from app.services import optimization_service as opt_service


class EmployeeNotFoundError(Exception):
    pass


class ShiftNotFoundError(Exception):
    pass


class NothingToUndoError(Exception):
    pass


def _apply_change(raw: List[opt.RawAssignment], employee_id: int, target_date: date_type, new_shift_id: Optional[int]) -> List[opt.RawAssignment]:
    new_raw = [a for a in raw if not (a.employee_id == employee_id and a.date == target_date)]
    if new_shift_id is not None:
        new_raw.append(opt.RawAssignment(employee_id=employee_id, date=target_date, shift_id=new_shift_id))
    return new_raw


def _validate_single_change(
    inp: opt.OptimizationInput, current_raw: List[opt.RawAssignment],
    employee_id: int, target_date: date_type, new_shift_id: Optional[int],
) -> List[str]:
    """Fast, specific pre-checks with spec-style messages, followed by a full
    re-validation of the resulting schedule via the shared validator (so
    weekly-hours/overlap logic is never duplicated)."""
    emp = next((e for e in inp.employees if e.id == employee_id), None)
    if emp is None:
        raise EmployeeNotFoundError(f"Employee {employee_id} not found in this location/department.")

    if new_shift_id is None:
        return []  # removing an assignment can never violate a hard constraint

    shift = next((s for s in inp.shifts if s.id == new_shift_id), None)
    if shift is None:
        raise ShiftNotFoundError(f"Shift template {new_shift_id} not found.")

    errors = []
    if not emp.is_available_for(target_date.weekday(), shift):
        errors.append("Cannot assign employee: unavailable during this period.")
    if not emp.has_required_skill:
        errors.append("Cannot assign task: employee does not have the required skill.")
    if shift.duration_hours > emp.max_daily_hours:
        errors.append("Cannot assign employee: shift exceeds maximum daily hours.")
    if errors:
        return errors  # no need to also run the full re-validation

    hypothetical = _apply_change(current_raw, employee_id, target_date, new_shift_id)
    details = opt.compute_schedule_details(inp, hypothetical)
    if not details["valid"]:
        relevant = [e for e in details["errors"] if f"Employee {employee_id} " in e or f"Employee {employee_id}\n" in e]
        if any("weekly hours" in e for e in relevant):
            errors.append(f"Cannot assign employee: exceeds weekly hour limit ({emp.max_weekly_hours}h).")
        if any("more than one shift" in e for e in relevant):
            errors.append("Cannot save: shift overlaps with an existing assignment that day.")
        if not errors:
            errors.extend(relevant or details["errors"][:3])
    return errors


def _resolve_warnings(inp: opt.OptimizationInput, employee_id: int, new_shift_id: Optional[int],
                       before_details: dict, after_details: dict) -> List[str]:
    emp = next((e for e in inp.employees if e.id == employee_id), None)
    if emp is None:
        return []
    shift = next((s for s in inp.shifts if s.id == new_shift_id), None) if new_shift_id is not None else None
    return opt.compute_soft_constraint_warnings(emp, shift, _summary(before_details), _summary(after_details))


def validate_change(
    db: Session, location_id: int, department_id: int,
    employee_id: int, target_date: date_type, new_shift_id: Optional[int],
    overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5,
) -> dict:
    """Dry run - never persists. Returns before/after summaries so the UI can
    show the live business impact of a proposed change before committing."""
    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    current_raw = opt_service.load_current_raw_assignments(db, location_id, department_id)
    before_details = opt.compute_schedule_details(inp, current_raw)

    errors = _validate_single_change(inp, current_raw, employee_id, target_date, new_shift_id)
    if errors:
        return {"valid": False, "errors": errors, "warnings": [], "before": _summary(before_details), "after": None}

    new_raw = _apply_change(current_raw, employee_id, target_date, new_shift_id)
    after_details = opt.compute_schedule_details(inp, new_raw)
    warnings = _resolve_warnings(inp, employee_id, new_shift_id, before_details, after_details)
    return {"valid": True, "errors": [], "warnings": warnings, "before": _summary(before_details), "after": _summary(after_details)}


def commit_change(
    db: Session, location_id: int, department_id: int,
    employee_id: int, target_date: date_type, new_shift_id: Optional[int],
    overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5,
) -> dict:
    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    current_raw = opt_service.load_current_raw_assignments(db, location_id, department_id)
    before_details = opt.compute_schedule_details(inp, current_raw)

    errors = _validate_single_change(inp, current_raw, employee_id, target_date, new_shift_id)
    if errors:
        return {"valid": False, "errors": errors, "warnings": [], "before": _summary(before_details), "after": None}

    # Single-level undo buffer: remember the state right before this edit.
    _save_undo_buffer(db, location_id, department_id, current_raw)

    new_raw = _apply_change(current_raw, employee_id, target_date, new_shift_id)
    after_details = opt.compute_schedule_details(inp, new_raw)
    warnings = _resolve_warnings(inp, employee_id, new_shift_id, before_details, after_details)
    generated_at = datetime.utcnow()
    opt_service.persist_assignments(db, location_id, department_id, after_details, generated_at, "modified")

    return {"valid": True, "errors": [], "warnings": warnings, "before": _summary(before_details), "after": _summary(after_details)}


def _save_undo_buffer(db: Session, location_id: int, department_id: int, raw: List[opt.RawAssignment]) -> None:
    db.execute(
        delete(models.ScheduleUndoBuffer)
        .where(models.ScheduleUndoBuffer.location_id == location_id)
        .where(models.ScheduleUndoBuffer.department_id == department_id)
    )
    payload = [[a.employee_id, a.date.isoformat(), a.shift_id] for a in raw]
    db.add(models.ScheduleUndoBuffer(
        location_id=location_id, department_id=department_id,
        assignments_json=json.dumps(payload), updated_at=datetime.utcnow(),
    ))
    db.commit()


def undo_last_change(
    db: Session, location_id: int, department_id: int,
    overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5,
) -> dict:
    buf = (
        db.query(models.ScheduleUndoBuffer)
        .filter(models.ScheduleUndoBuffer.location_id == location_id)
        .filter(models.ScheduleUndoBuffer.department_id == department_id)
        .first()
    )
    if buf is None:
        raise NothingToUndoError("Nothing to undo - no manual edit has been made since the last generate/revert.")

    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    payload = json.loads(buf.assignments_json)
    raw = [opt.RawAssignment(employee_id=eid, date=date_type.fromisoformat(d), shift_id=sid) for eid, d, sid in payload]
    details = opt.compute_schedule_details(inp, raw)
    generated_at = datetime.utcnow()
    opt_service.persist_assignments(db, location_id, department_id, details, generated_at, "modified")

    db.execute(delete(models.ScheduleUndoBuffer).where(models.ScheduleUndoBuffer.id == buf.id))
    db.commit()

    return opt_service.build_response(location_id, department_id, True, "FEASIBLE", None, details, generated_at, "modified")


def _summary(details: dict) -> dict:
    return {
        "total_labor_cost": round(details["total_cost_cents"] / 100.0, 2),
        "total_shifts": len(details["assignments"]),
        "overtime_shifts": details["total_overtime_shifts"],
        "overtime_hours": details["total_overtime_hours"],
        "avg_coverage_pct": details["avg_coverage_pct"],
        "understaffed_hours": details["understaffed_hours"],
        "overstaffed_hours": details["overstaffed_hours"],
        "total_hours_covered": details["total_hours_covered"],
    }


def get_employee_detail(db: Session, location_id: int, department_id: int, employee_id: int,
                         overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5) -> dict:
    emp = db.query(models.Employee).filter(models.Employee.id == employee_id).first()
    if emp is None:
        raise EmployeeNotFoundError(f"Employee {employee_id} not found.")

    skills = [es.skill.name for es in emp.skills]
    availability = [
        {"day_of_week": a.day_of_week, "start_hour": a.available_start_hour, "end_hour": a.available_end_hour}
        for a in sorted(emp.availability, key=lambda a: a.day_of_week)
    ]

    raw = opt_service.load_current_raw_assignments(db, location_id, department_id)
    shift_templates = {s.id: s for s in db.query(models.ShiftTemplate).all()}
    my_raw = [a for a in raw if a.employee_id == employee_id]

    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    details = opt.compute_schedule_details(inp, raw)
    my_assignments = [a for a in details["assignments"] if a.employee_id == employee_id]

    total_hours = sum(a.hours for a in my_assignments)
    total_cost = sum(a.cost_cents for a in my_assignments) / 100.0
    overtime_shift_count = sum(1 for a in my_assignments if a.is_overtime)
    preference_conflicts = sum(
        1 for a in my_assignments if emp.preferred_shift and a.shift_name != emp.preferred_shift
    )

    return {
        "employee_id": emp.id, "name": emp.name, "employment_type": emp.employment_type,
        "hourly_cost": emp.hourly_cost, "max_daily_hours": emp.max_daily_hours,
        "max_weekly_hours": emp.max_weekly_hours, "preferred_shift": emp.preferred_shift,
        "skills": skills, "availability": availability,
        "assigned_shifts": [
            {
                "date": a.date, "shift_name": a.shift_name, "start_hour": a.start_hour,
                "end_hour": a.end_hour, "hours": a.hours, "cost": round(a.cost_cents / 100.0, 2),
                "is_overtime": a.is_overtime,
            }
            for a in sorted(my_assignments, key=lambda a: a.date)
        ],
        "total_hours": total_hours, "total_cost": round(total_cost, 2),
        "overtime_shifts": overtime_shift_count, "preference_conflicts": preference_conflicts,
    }


def reoptimize_preview(
    db: Session, location_id: int, department_id: int,
    overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5,
) -> dict:
    """Runs the real OR-Tools solver fresh, WITHOUT touching the persisted
    schedule, so the manager can compare current vs. re-optimized before
    deciding whether to replace anything."""
    current_raw = opt_service.load_current_raw_assignments(db, location_id, department_id)
    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    current_details = opt.compute_schedule_details(inp, current_raw)

    result = opt.solve(inp)
    if not result.feasible:
        return {
            "feasible": False, "infeasibility_reason": result.infeasibility_reason,
            "current": _summary(current_details), "proposed": None,
        }
    proposed_details = opt.compute_schedule_details(inp, result.raw_assignments)
    return {
        "feasible": True, "infeasibility_reason": None,
        "current": _summary(current_details), "proposed": _summary(proposed_details),
    }


# ---------------------------------------------------------------------------
# Batch staging: "Save Changes" / "Cancel Changes"
#
# A manager can stage several edits before deciding whether to keep any of
# them. Staged edits are validated the same way as instant commits and are
# persisted to SQLite immediately (in ScheduleDraft) - never held only in
# frontend memory - but they do NOT touch the live Schedule/ScheduleAssignment
# tables until "Save Changes" commits the whole batch. "Cancel Changes"
# simply discards the draft; nothing to undo because nothing was committed.
# ---------------------------------------------------------------------------

class NoDraftError(Exception):
    pass


def _get_draft_row(db: Session, location_id: int, department_id: int):
    return (
        db.query(models.ScheduleDraft)
        .filter(models.ScheduleDraft.location_id == location_id)
        .filter(models.ScheduleDraft.department_id == department_id)
        .first()
    )


def _get_working_raw(db: Session, location_id: int, department_id: int):
    """Returns (raw_assignments, draft_row_or_None). If a draft exists, that
    is the working state; otherwise the working state is whatever is
    currently persisted."""
    draft = _get_draft_row(db, location_id, department_id)
    if draft is not None:
        payload = json.loads(draft.assignments_json)
        raw = [opt.RawAssignment(employee_id=eid, date=date_type.fromisoformat(d), shift_id=sid) for eid, d, sid in payload]
        return raw, draft
    return opt_service.load_current_raw_assignments(db, location_id, department_id), None


def get_draft_status(db: Session, location_id: int, department_id: int,
                      overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5) -> dict:
    draft = _get_draft_row(db, location_id, department_id)
    if draft is None:
        return {"has_unsaved_changes": False, "changes": [], "baseline": None, "working": None}

    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    working_raw, _ = _get_working_raw(db, location_id, department_id)
    baseline_raw = opt_service.load_current_raw_assignments(db, location_id, department_id)

    working_details = opt.compute_schedule_details(inp, working_raw)
    baseline_details = opt.compute_schedule_details(inp, baseline_raw)

    return {
        "has_unsaved_changes": True,
        "changes": json.loads(draft.changes_json),
        "baseline": _summary(baseline_details),
        "working": _summary(working_details),
    }


def stage_change(
    db: Session, location_id: int, department_id: int,
    employee_id: int, target_date: date_type, new_shift_id: Optional[int],
    overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5,
) -> dict:
    """Validates and stages one edit into the draft. Never touches the live
    Schedule/ScheduleAssignment tables - only the ScheduleDraft row."""
    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    working_raw, draft = _get_working_raw(db, location_id, department_id)
    before_details = opt.compute_schedule_details(inp, working_raw)

    errors = _validate_single_change(inp, working_raw, employee_id, target_date, new_shift_id)
    if errors:
        return {
            "valid": False, "errors": errors, "warnings": [],
            "before": _summary(before_details), "after": None, "has_unsaved_changes": draft is not None,
        }

    old_shift_id = next((a.shift_id for a in working_raw if a.employee_id == employee_id and a.date == target_date), None)
    new_raw = _apply_change(working_raw, employee_id, target_date, new_shift_id)
    after_details = opt.compute_schedule_details(inp, new_raw)
    warnings = _resolve_warnings(inp, employee_id, new_shift_id, before_details, after_details)

    now = datetime.utcnow()
    payload = [[a.employee_id, a.date.isoformat(), a.shift_id] for a in new_raw]
    change_entry = {
        "employee_id": employee_id, "date": target_date.isoformat(),
        "old_shift_id": old_shift_id, "new_shift_id": new_shift_id,
        "staged_at": now.isoformat(),
    }
    if draft is not None:
        changes = json.loads(draft.changes_json)
        changes.append(change_entry)
        draft.assignments_json = json.dumps(payload)
        draft.changes_json = json.dumps(changes)
        draft.updated_at = now
    else:
        db.add(models.ScheduleDraft(
            location_id=location_id, department_id=department_id,
            assignments_json=json.dumps(payload), changes_json=json.dumps([change_entry]),
            created_at=now, updated_at=now,
        ))
    db.commit()

    return {
        "valid": True, "errors": [], "warnings": warnings,
        "before": _summary(before_details), "after": _summary(after_details), "has_unsaved_changes": True,
    }


def save_draft(db: Session, location_id: int, department_id: int,
                overtime_threshold_hours_per_week: int = 32, overtime_multiplier: float = 1.5) -> dict:
    draft = _get_draft_row(db, location_id, department_id)
    if draft is None:
        raise NoDraftError("No unsaved changes to save.")

    inp = opt_service.load_optimization_input(db, location_id, department_id, overtime_threshold_hours_per_week, overtime_multiplier)
    working_raw, _ = _get_working_raw(db, location_id, department_id)
    details = opt.compute_schedule_details(inp, working_raw)

    # Snapshot what's currently live before overwriting, so a single-level
    # undo remains available even for a saved batch.
    current_raw = opt_service.load_current_raw_assignments(db, location_id, department_id)
    _save_undo_buffer(db, location_id, department_id, current_raw)

    generated_at = datetime.utcnow()
    opt_service.persist_assignments(db, location_id, department_id, details, generated_at, "modified")

    db.execute(delete(models.ScheduleDraft).where(models.ScheduleDraft.id == draft.id))
    db.commit()

    return opt_service.build_response(location_id, department_id, True, "FEASIBLE", None, details, generated_at, "modified")


def cancel_draft(db: Session, location_id: int, department_id: int) -> dict:
    draft = _get_draft_row(db, location_id, department_id)
    if draft is None:
        raise NoDraftError("No unsaved changes to cancel.")
    db.execute(delete(models.ScheduleDraft).where(models.ScheduleDraft.id == draft.id))
    db.commit()
    return {"cancelled": True}
