"""
Executive Dashboard v2 - a read-only aggregation layer over Phases 2-6.

Rule for this whole module: it computes nothing that a lower phase doesn't
already compute. Every number here is either read directly from a stored
row, or derived with a small, explainable, deterministic formula from
numbers those phases already produced (e.g. cost-per-hour = total cost /
total hours). No forecasting, optimization, or requirement math is
duplicated here - see forecasting.py / optimization.py / workforce_requirement.py
for those.

Alerts and recommendations are rule-based (documented thresholds below), not
an external AI call - the spec explicitly requires this.
"""
import json
from collections import defaultdict
from datetime import date as date_type, datetime
from typing import Optional

from sqlalchemy.orm import Session

from app import models
from app.services import forecast_service
from app.services import workforce_requirement_service as wrs
from app.services import optimization as opt
from app.services import optimization_service as opt_service
from app.services import scenario_engine

# Deterministic alert/recommendation thresholds - documented here, not magic
# numbers scattered through the code.
OVERTIME_ALERT_THRESHOLD_PCT = 8.0          # overtime hours / total scheduled hours
FORECAST_BIAS_ALERT_THRESHOLD = 0.10        # |bias| as a fraction, e.g. 0.10 = 10%
UNDERSTAFFED_ALERT_MIN_GAP = 2              # minimum average headcount gap to alert on
OVERSTAFFED_ALERT_MIN_SURPLUS = 2


def _get_best_forecast_model(forecast_data: Optional[dict]) -> Optional[dict]:
    if not forecast_data:
        return None
    return next((m for m in forecast_data["model_comparison"] if m["is_best"]), None)


def _get_recent_actual_demand(db: Session, location_id: int, department_id: int, hours: int):
    latest = (
        db.query(models.DemandHistory.timestamp)
        .filter(models.DemandHistory.location_id == location_id)
        .filter(models.DemandHistory.department_id == department_id)
        .order_by(models.DemandHistory.timestamp.desc())
        .first()
    )
    if not latest:
        return []
    from datetime import timedelta
    window_start = latest[0] - timedelta(hours=hours)
    rows = (
        db.query(models.DemandHistory.timestamp, models.DemandHistory.demand)
        .filter(models.DemandHistory.location_id == location_id)
        .filter(models.DemandHistory.department_id == department_id)
        .filter(models.DemandHistory.timestamp > window_start)
        .order_by(models.DemandHistory.timestamp.asc())
        .all()
    )
    return [(r[0], r[1]) for r in rows]


def _compute_demand_insight(actual_points, forecast_points, horizon_days: int) -> dict:
    if not forecast_points:
        return {"available": False, "message": "No forecast has been generated yet."}

    forecast_values = [p["predicted_demand"] for p in forecast_points]
    forecast_avg = sum(forecast_values) / len(forecast_values)

    # Compare against the most recent equal-length window of actual demand.
    comparable_actual = actual_points[-len(forecast_points):] if len(actual_points) >= len(forecast_points) else actual_points
    if not comparable_actual:
        return {
            "available": True, "pct_change": None,
            "message": "Not enough historical demand yet to compute a trend comparison.",
            "peak_window": None,
        }
    actual_avg = sum(v for _, v in comparable_actual) / len(comparable_actual)

    pct_change = ((forecast_avg - actual_avg) / actual_avg * 100) if actual_avg > 0 else None

    # Find the hour-of-day with the largest forecast-vs-recent-actual-same-hour delta.
    actual_by_hour = defaultdict(list)
    for ts, v in comparable_actual:
        actual_by_hour[ts.hour].append(v)
    actual_avg_by_hour = {h: sum(vs) / len(vs) for h, vs in actual_by_hour.items()}

    forecast_by_hour = defaultdict(list)
    for p in forecast_points:
        forecast_by_hour[p["timestamp"].hour].append(p["predicted_demand"])
    forecast_avg_by_hour = {h: sum(vs) / len(vs) for h, vs in forecast_by_hour.items()}

    best_hour, best_delta = None, None
    for h, f_avg in forecast_avg_by_hour.items():
        a_avg = actual_avg_by_hour.get(h)
        if a_avg is None:
            continue
        delta = f_avg - a_avg
        if best_delta is None or abs(delta) > abs(best_delta):
            best_delta, best_hour = delta, h

    peak_window = None
    if best_hour is not None:
        window_start = max(0, best_hour - 1)
        window_end = min(24, best_hour + 3)
        peak_window = {"start_hour": window_start, "end_hour": window_end, "delta": round(best_delta, 1)}

    direction = "increase" if (pct_change or 0) >= 0 else "decrease"
    if pct_change is None:
        message = f"Forecast demand over the next {horizon_days} days averages {forecast_avg:.1f} per hour."
    elif peak_window:
        window_direction = "increase" if peak_window["delta"] >= 0 else "decrease"
        message = (
            f"Demand is expected to {direction} {abs(pct_change):.0f}% over the next {horizon_days} days, "
            f"with the largest {window_direction} occurring between "
            f"{peak_window['start_hour']:02d}:00\u2013{peak_window['end_hour']:02d}:00."
        )
    else:
        message = f"Demand is expected to {direction} {abs(pct_change):.0f}% over the next {horizon_days} days."

    return {"available": True, "pct_change": round(pct_change, 1) if pct_change is not None else None,
            "message": message, "peak_window": peak_window,
            "forecast_avg": round(forecast_avg, 1), "recent_actual_avg": round(actual_avg, 1)}


def _compute_labor_cost_metrics(db: Session, location_id: int, department_id: int, schedule_data: Optional[dict], actual_demand_total: float) -> dict:
    if not schedule_data or not schedule_data.get("feasible") or not schedule_data.get("summary"):
        return {"available": False, "message": "No schedule has been generated yet."}

    summary = schedule_data["summary"]
    total_cost = summary["total_labor_cost"]
    total_hours = sum(a["hours"] for a in schedule_data["assignments"])

    # Real overtime cost = the actual premium paid, computed from each
    # overtime assignment's stored cost minus what that employee's base rate
    # would have cost for the same hours - not an estimate.
    employee_rates = {
        e.id: e.hourly_cost for e in
        db.query(models.Employee).filter(models.Employee.location_id == location_id).filter(models.Employee.department_id == department_id).all()
    }
    overtime_cost = 0.0
    for a in schedule_data["assignments"]:
        if a["is_overtime"]:
            base_rate = employee_rates.get(a["employee_id"], 0)
            base_cost = a["hours"] * base_rate
            overtime_cost += max(0.0, a["cost"] - base_cost)

    cost_per_hour = round(total_cost / total_hours, 2) if total_hours > 0 else None
    cost_per_transaction = round(total_cost / actual_demand_total, 4) if actual_demand_total > 0 else None

    schedules = (
        db.query(models.Schedule)
        .filter(models.Schedule.location_id == location_id)
        .filter(models.Schedule.department_id == department_id)
        .order_by(models.Schedule.date.asc())
        .all()
    )
    cost_trend = [{"date": s.date.isoformat(), "cost": s.total_cost} for s in schedules]

    return {
        "available": True,
        "current_labor_cost": total_cost,
        "overtime_cost": round(overtime_cost, 2),
        "cost_per_hour": cost_per_hour,
        "cost_per_transaction": cost_per_transaction,
        "cost_trend": cost_trend,
    }


def _load_snapshot_details(db: Session, location_id: int, department_id: int):
    snapshot = (
        db.query(models.ScheduleOptimizedSnapshot)
        .filter(models.ScheduleOptimizedSnapshot.location_id == location_id)
        .filter(models.ScheduleOptimizedSnapshot.department_id == department_id)
        .first()
    )
    if snapshot is None:
        return None
    inp = opt_service.load_optimization_input(
        db, location_id, department_id,
        snapshot.overtime_threshold_hours_per_week, snapshot.overtime_multiplier,
    )
    payload = json.loads(snapshot.assignments_json)
    raw = [opt.RawAssignment(employee_id=eid, date=date_type.fromisoformat(d), shift_id=sid) for eid, d, sid in payload]
    return opt.compute_schedule_details(inp, raw)


def _compute_optimization_impact(db: Session, location_id: int, department_id: int, schedule_data: Optional[dict]) -> dict:
    if not schedule_data or not schedule_data.get("feasible"):
        return {"available": False, "message": "Baseline unavailable \u2014 no optimized schedule has been generated yet."}

    if schedule_data.get("schedule_status") != "modified":
        return {
            "available": False,
            "message": "No manual modifications since the last optimization run \u2014 there is nothing to compare "
                        "the optimized schedule against. Showing optimized metrics only.",
        }

    snapshot_details = _load_snapshot_details(db, location_id, department_id)
    if snapshot_details is None:
        return {"available": False, "message": "Baseline unavailable \u2014 no optimized schedule snapshot exists."}

    before = {
        "total_labor_cost": round(snapshot_details["total_cost_cents"] / 100.0, 2),
        "total_labor_hours": sum(a.hours for a in snapshot_details["assignments"]),
        "overtime_shifts": snapshot_details["total_overtime_shifts"],
        "overtime_hours": snapshot_details["total_overtime_hours"],
        "avg_coverage_pct": snapshot_details["avg_coverage_pct"],
        "understaffed_hours": snapshot_details["understaffed_hours"],
        "overstaffed_hours": snapshot_details["overstaffed_hours"],
    }
    after_summary = schedule_data["summary"]
    after = {
        "total_labor_cost": after_summary["total_labor_cost"],
        "total_labor_hours": sum(a["hours"] for a in schedule_data["assignments"]),
        "overtime_shifts": after_summary["overtime_shifts"],
        "overtime_hours": after_summary.get("overtime_hours", 0),
        "avg_coverage_pct": after_summary["avg_coverage_pct"],
        "understaffed_hours": after_summary["understaffed_hours"],
        "overstaffed_hours": after_summary["overstaffed_hours"],
    }
    cost_impact = round(before["total_labor_cost"] - after["total_labor_cost"], 2)  # positive = savings
    cost_impact_pct = round(cost_impact / before["total_labor_cost"] * 100, 1) if before["total_labor_cost"] > 0 else None

    return {
        "available": True, "before": before, "after": after,
        "estimated_savings": cost_impact, "savings_pct": cost_impact_pct,
        "coverage_improvement_pct": round(after["avg_coverage_pct"] - before["avg_coverage_pct"], 1),
    }


def _compute_whatif_summary(db: Session, location_id: int, department_id: int) -> dict:
    scenarios = scenario_engine.list_scenarios(db, location_id, department_id)
    if not scenarios:
        return {"available": False, "message": "No what-if scenarios have been run yet."}
    latest = scenarios[0]
    return {"available": True, "scenario": latest}


def _find_worst_contiguous_window(coverage: list, key: str, min_value: int):
    """Finds the hour range (within a single date) with the largest average
    gap for the given key ('understaffed' or 'overstaffed'), only among
    hours where the gap is at least min_value."""
    by_date = defaultdict(list)
    for c in coverage:
        by_date[c["date"]].append(c)

    best = None
    for d, hours in by_date.items():
        hours_sorted = sorted(hours, key=lambda c: c["hour"])
        run = []
        for c in hours_sorted + [None]:
            if c is not None and c[key] >= min_value:
                run.append(c)
            else:
                if run:
                    avg_gap = sum(r[key] for r in run) / len(run)
                    candidate = {
                        "date": d, "start_hour": run[0]["hour"], "end_hour": run[-1]["hour"] + 1,
                        "avg_gap": round(avg_gap, 1),
                    }
                    if best is None or candidate["avg_gap"] > best["avg_gap"]:
                        best = candidate
                run = []
    return best


def _format_window_hours(start_hour: int, end_hour: int) -> str:
    if start_hour == 0 and end_hour == 24:
        return "all day"
    return f"{start_hour:02d}:00\u2013{end_hour:02d}:00"


def _compute_alerts(schedule_data: Optional[dict], best_forecast_model: Optional[dict]) -> list:
    alerts = []

    if schedule_data and schedule_data.get("feasible") and schedule_data.get("summary"):
        summary = schedule_data["summary"]
        coverage = schedule_data["coverage"]
        total_hours = sum(a["hours"] for a in schedule_data["assignments"])

        understaffed_window = _find_worst_contiguous_window(coverage, "understaffed", UNDERSTAFFED_ALERT_MIN_GAP)
        if understaffed_window:
            hours_str = _format_window_hours(understaffed_window["start_hour"], understaffed_window["end_hour"])
            alerts.append({
                "severity": "high",
                "message": (
                    f"{understaffed_window['date']} ({hours_str}) is projected to be understaffed by "
                    f"{understaffed_window['avg_gap']:.0f} employees on average."
                ),
            })

        overstaffed_window = _find_worst_contiguous_window(coverage, "overstaffed", OVERSTAFFED_ALERT_MIN_SURPLUS)
        if overstaffed_window:
            hours_str = _format_window_hours(overstaffed_window["start_hour"], overstaffed_window["end_hour"])
            alerts.append({
                "severity": "medium",
                "message": (
                    f"Excess staffing projected on {overstaffed_window['date']} ({hours_str}) "
                    f"(~{overstaffed_window['avg_gap']:.0f} more than required)."
                ),
            })

        overtime_hours = summary.get("overtime_hours", 0)
        if total_hours > 0 and (overtime_hours / total_hours * 100) > OVERTIME_ALERT_THRESHOLD_PCT:
            pct = overtime_hours / total_hours * 100
            alerts.append({
                "severity": "medium",
                "message": f"Overtime is at {pct:.0f}% of scheduled hours, above the {OVERTIME_ALERT_THRESHOLD_PCT:.0f}% threshold.",
            })

    if best_forecast_model and best_forecast_model.get("bias") is not None:
        bias = best_forecast_model["bias"]
        if abs(bias) > FORECAST_BIAS_ALERT_THRESHOLD:
            direction = "under-forecasting" if bias < 0 else "over-forecasting"
            alerts.append({
                "severity": "low",
                "message": f"Forecast bias indicates persistent {direction} ({bias * 100:+.1f}%).",
            })

    return alerts


def _compute_recommendations(schedule_data: Optional[dict], requirement_data: Optional[dict]) -> list:
    recommendations = []
    if schedule_data and schedule_data.get("feasible"):
        coverage = schedule_data["coverage"]
        understaffed_window = _find_worst_contiguous_window(coverage, "understaffed", UNDERSTAFFED_ALERT_MIN_GAP)
        overstaffed_window = _find_worst_contiguous_window(coverage, "overstaffed", OVERSTAFFED_ALERT_MIN_SURPLUS)
        if understaffed_window and overstaffed_window:
            recommendations.append(
                f"Consider shifting coverage from "
                f"{_format_window_hours(overstaffed_window['start_hour'], overstaffed_window['end_hour'])} "
                f"({overstaffed_window['date']}) to "
                f"{_format_window_hours(understaffed_window['start_hour'], understaffed_window['end_hour'])} "
                f"({understaffed_window['date']}) to improve peak coverage."
            )
        elif understaffed_window:
            recommendations.append(
                f"Consider increasing staffing during "
                f"{_format_window_hours(understaffed_window['start_hour'], understaffed_window['end_hour'])} "
                f"on {understaffed_window['date']}."
            )
        elif overstaffed_window:
            recommendations.append(
                f"Demand is consistently below scheduled capacity during "
                f"{_format_window_hours(overstaffed_window['start_hour'], overstaffed_window['end_hour'])} "
                f"on {overstaffed_window['date']} \u2014 consider reducing staffing there."
            )

    if requirement_data:
        by_weekday = defaultdict(list)
        for p in requirement_data["points"]:
            ts = datetime.fromisoformat(p["timestamp"]) if isinstance(p["timestamp"], str) else p["timestamp"]
            by_weekday[ts.strftime("%A")].append(p["required_headcount"])
        if by_weekday:
            peak_day = max(by_weekday, key=lambda d: max(by_weekday[d]))
            peak_value = max(by_weekday[peak_day])
            recommendations.append(
                f"{peak_day} shows the highest single-hour staffing requirement this horizon ({peak_value} employees) \u2014 "
                f"confirm adequate coverage is scheduled that day."
            )

    return recommendations


def get_executive_dashboard(db: Session, location_id: int, department_id: int, horizon_days: int = 7) -> dict:
    location = db.query(models.Location).filter(models.Location.id == location_id).first()
    department = db.query(models.Department).filter(models.Department.id == department_id).first()

    forecast_data = forecast_service.load_stored(db, location_id, department_id)
    requirement_data = wrs.load_stored(db, location_id, department_id)
    schedule_data = opt_service.load_stored(db, location_id, department_id)

    best_forecast_model = _get_best_forecast_model(forecast_data)

    actual_points = _get_recent_actual_demand(db, location_id, department_id, hours=24 * 30)
    actual_demand_total = sum(v for _, v in actual_points[-24 * horizon_days:]) if actual_points else 0.0

    demand_insight = _compute_demand_insight(
        actual_points, forecast_data["forecast_points"] if forecast_data else [], horizon_days
    )
    labor_cost = _compute_labor_cost_metrics(db, location_id, department_id, schedule_data, actual_demand_total)
    optimization_impact = _compute_optimization_impact(db, location_id, department_id, schedule_data)
    whatif_summary = _compute_whatif_summary(db, location_id, department_id)
    alerts = _compute_alerts(schedule_data, best_forecast_model)
    recommendations = _compute_recommendations(schedule_data, requirement_data)

    total_active_employees = (
        db.query(models.Employee)
        .filter(models.Employee.location_id == location_id)
        .filter(models.Employee.department_id == department_id)
        .filter(models.Employee.active.is_(True))
        .count()
    )
    scheduled_employees = len({a["employee_id"] for a in schedule_data["assignments"]}) if schedule_data and schedule_data.get("assignments") else 0

    kpis = {
        "forecast_accuracy_pct": round((1 - best_forecast_model["wape"]) * 100, 1) if best_forecast_model and best_forecast_model.get("wape") is not None else None,
        "wape_pct": round(best_forecast_model["wape"] * 100, 1) if best_forecast_model and best_forecast_model.get("wape") is not None else None,
        "required_peak_headcount": requirement_data["summary"]["peak_required_headcount"] if requirement_data else None,
        "scheduled_employees": scheduled_employees,
        "available_employees": total_active_employees,
        "avg_coverage_pct": schedule_data["summary"]["avg_coverage_pct"] if schedule_data and schedule_data.get("summary") else None,
        "understaffed_hours": schedule_data["summary"]["understaffed_hours"] if schedule_data and schedule_data.get("summary") else None,
        "overstaffed_hours": schedule_data["summary"]["overstaffed_hours"] if schedule_data and schedule_data.get("summary") else None,
        "labor_cost": schedule_data["summary"]["total_labor_cost"] if schedule_data and schedule_data.get("summary") else None,
        "overtime_hours": schedule_data["summary"].get("overtime_hours") if schedule_data and schedule_data.get("summary") else None,
        "estimated_savings": optimization_impact.get("estimated_savings") if optimization_impact.get("available") else None,
    }

    workforce_capacity = None
    if schedule_data and schedule_data.get("coverage"):
        workforce_capacity = {
            "coverage": schedule_data["coverage"],
            "available_employees": total_active_employees,
        }

    return {
        "location": {"id": location.id, "name": location.name} if location else None,
        "department": {"id": department.id, "name": department.name} if department else None,
        "horizon_days": horizon_days,
        "kpis": kpis,
        "demand_outlook": {
            "insight": demand_insight,
            "actual": [{"timestamp": ts.isoformat(), "demand": v} for ts, v in actual_points],
            "forecast": forecast_data["forecast_points"] if forecast_data else [],
        },
        "workforce_capacity": workforce_capacity,
        "labor_cost": labor_cost,
        "optimization_impact": optimization_impact,
        "whatif_summary": whatif_summary,
        "alerts": alerts,
        "recommendations": recommendations,
        "generated_at": datetime.utcnow().isoformat(),
    }
