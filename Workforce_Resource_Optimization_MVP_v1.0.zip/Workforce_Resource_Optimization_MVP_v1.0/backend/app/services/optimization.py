"""
Workforce scheduling optimization engine (Google OR-Tools CP-SAT).

Design principle - independent validation, not solver trust:
The solver is asked ONLY for the raw yes/no assignment decisions (which
employee works which shift on which day). Cost, overtime attribution, and
coverage are deliberately NOT read from the solver's internal auxiliary
variables (even though the model uses auxiliary integer variables internally
to give the solver an incentive to avoid overtime/under/overstaffing) -
they are recomputed from scratch in plain Python from the raw decisions in
`compute_schedule_details`. That is what makes the validation layer genuinely
independent: a bug in the internal objective wiring would still show up as
wrong numbers when recomputed, rather than being silently trusted.

Hard constraints enforced in the CP-SAT model:
  - Employee availability (day-of-week + hour window)
  - Required department skill
  - Shift length must not exceed the employee's max daily hours
  - At most one shift per employee per day (this is what prevents
    overlapping shifts, since only one shift can be chosen per day)
  - Max weekly hours (hard cap, enforced per 7-day window of the horizon)

Soft, objective-driven behavior:
  - Labor cost minimization
  - Overtime minimization (hours beyond a configurable weekly threshold,
    which must be <= the hard weekly cap for the incentive to mean anything)
  - Understaffing / overstaffing minimization against required headcount
  - Shift preference matching
"""
from dataclasses import dataclass
from datetime import date as date_type
from typing import Dict, List, Optional, Tuple

from ortools.sat.python import cp_model


@dataclass(frozen=True)
class ShiftDef:
    id: int
    name: str
    start_hour: int
    end_hour: int

    @property
    def duration_hours(self) -> int:
        return self.end_hour - self.start_hour

    def covers_hour(self, hour: int) -> bool:
        return self.start_hour <= hour < self.end_hour


@dataclass(frozen=True)
class EmployeeDef:
    id: int
    name: str
    hourly_cost_cents: int
    max_daily_hours: int
    max_weekly_hours: int
    has_required_skill: bool
    preferred_shift: Optional[str]
    availability: Tuple[Tuple[int, int, int], ...]  # (day_of_week, start_hour, end_hour)

    def is_available_for(self, day_of_week: int, shift: ShiftDef) -> bool:
        for dow, w_start, w_end in self.availability:
            if dow == day_of_week and w_start <= shift.start_hour and w_end >= shift.end_hour:
                return True
        return False


@dataclass
class OptimizationInput:
    employees: List[EmployeeDef]
    shifts: List[ShiftDef]
    dates: List[date_type]  # sorted, consecutive
    required_headcount: Dict[Tuple[date_type, int], int]  # (date, hour) -> required
    overtime_threshold_hours_per_week: int = 32
    overtime_multiplier: float = 1.5
    understaff_penalty_per_unit_cents: int = 5000
    overstaff_penalty_per_unit_cents: int = 2000
    preference_penalty_cents: int = 500
    solver_time_limit_seconds: float = 20.0


@dataclass(frozen=True)
class RawAssignment:
    employee_id: int
    date: date_type
    shift_id: int


@dataclass
class SolveResult:
    feasible: bool
    status: str
    raw_assignments: List[RawAssignment]
    infeasibility_reason: Optional[str] = None


def solve(inp: OptimizationInput) -> SolveResult:
    if not inp.employees:
        return SolveResult(False, "INFEASIBLE", [], "No employees exist for this location/department.")
    if not inp.dates:
        return SolveResult(False, "INFEASIBLE", [], "No scheduling horizon was provided.")

    model = cp_model.CpModel()
    x: Dict[Tuple[int, int, int], cp_model.IntVar] = {}

    for ei, emp in enumerate(inp.employees):
        for di, day in enumerate(inp.dates):
            dow = day.weekday()
            for si, sh in enumerate(inp.shifts):
                if sh.duration_hours > emp.max_daily_hours:
                    continue
                if not emp.has_required_skill:
                    continue
                if not emp.is_available_for(dow, sh):
                    continue
                x[(ei, di, si)] = model.NewBoolVar(f"x_e{emp.id}_d{di}_s{sh.id}")

    if not x:
        return SolveResult(
            False, "INFEASIBLE", [],
            "No employee/shift/day combination satisfies availability, required-skill, "
            "and shift-length constraints - there is no one eligible to schedule at all.",
        )

    # Hard: at most one shift per employee per day (this is what rules out overlapping shifts)
    for ei in range(len(inp.employees)):
        for di in range(len(inp.dates)):
            vars_ = [x[(ei, di, si)] for si in range(len(inp.shifts)) if (ei, di, si) in x]
            if vars_:
                model.Add(sum(vars_) <= 1)

    # Hard: max weekly hours per 7-day window of the horizon; soft: overtime beyond threshold
    week_chunks = [list(range(i, min(i + 7, len(inp.dates)))) for i in range(0, len(inp.dates), 7)]
    overtime_vars: List[Tuple[int, int, cp_model.IntVar]] = []
    for ei, emp in enumerate(inp.employees):
        for wi, day_idxs in enumerate(week_chunks):
            terms = []
            for di in day_idxs:
                for si, sh in enumerate(inp.shifts):
                    if (ei, di, si) in x:
                        terms.append(x[(ei, di, si)] * sh.duration_hours)
            if not terms:
                continue
            weekly_hours = sum(terms)
            model.Add(weekly_hours <= int(emp.max_weekly_hours))
            ot = model.NewIntVar(0, int(emp.max_weekly_hours), f"ot_e{emp.id}_w{wi}")
            model.Add(ot >= weekly_hours - inp.overtime_threshold_hours_per_week)
            model.Add(ot >= 0)
            overtime_vars.append((ei, wi, ot))

    # Soft: coverage - understaffing/overstaffing against required headcount
    under_vars, over_vars = [], []
    max_possible = len(inp.employees)
    dates_index = {d: i for i, d in enumerate(inp.dates)}
    for day in inp.dates:
        di = dates_index[day]
        for hour in range(24):
            required = inp.required_headcount.get((day, hour), 0)
            if required == 0:
                continue
            scheduled_terms = [
                x[(ei, di, si)]
                for ei in range(len(inp.employees))
                for si, sh in enumerate(inp.shifts)
                if sh.covers_hour(hour) and (ei, di, si) in x
            ]
            scheduled = sum(scheduled_terms) if scheduled_terms else 0
            under = model.NewIntVar(0, required, f"under_{di}_{hour}")
            over = model.NewIntVar(0, max_possible, f"over_{di}_{hour}")
            model.Add(under >= required - scheduled)
            model.Add(over >= scheduled - required)
            under_vars.append(under)
            over_vars.append(over)

    # Soft: shift preference
    pref_terms = [
        x[(ei, di, si)]
        for ei, emp in enumerate(inp.employees) if emp.preferred_shift
        for di in range(len(inp.dates))
        for si, sh in enumerate(inp.shifts)
        if (ei, di, si) in x and sh.name != emp.preferred_shift
    ]

    # Objective: minimize labor cost + overtime premium + coverage penalties + preference mismatches
    cost_terms = [
        var * inp.employees[ei].hourly_cost_cents * inp.shifts[si].duration_hours
        for (ei, di, si), var in x.items()
    ]
    overtime_cost_terms = [
        ot * int(round(inp.employees[ei].hourly_cost_cents * (inp.overtime_multiplier - 1)))
        for ei, wi, ot in overtime_vars
    ]

    objective_terms = (
        cost_terms
        + overtime_cost_terms
        + [u * inp.understaff_penalty_per_unit_cents for u in under_vars]
        + [o * inp.overstaff_penalty_per_unit_cents for o in over_vars]
        + [v * inp.preference_penalty_cents for v in pref_terms]
    )
    model.Minimize(sum(objective_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = inp.solver_time_limit_seconds
    solver.parameters.num_search_workers = 8
    status = solver.Solve(model)

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return SolveResult(
            False, solver.StatusName(status), [],
            "The solver could not find any schedule that satisfies employee availability, "
            "required skills, and working-hour limits for this location/department/horizon.",
        )

    raw_assignments = [
        RawAssignment(inp.employees[ei].id, inp.dates[di], inp.shifts[si].id)
        for (ei, di, si), var in x.items()
        if solver.Value(var) == 1
    ]
    return SolveResult(True, solver.StatusName(status), raw_assignments)


# ---------------------------------------------------------------------------
# Independent validation / recomputation layer.
# Takes ONLY the raw yes/no decisions and recomputes everything else from
# scratch - this never reads a solver-internal cost/overtime/coverage value.
# ---------------------------------------------------------------------------

@dataclass
class AssignmentDetail:
    employee_id: int
    employee_name: str
    date: date_type
    shift_id: int
    shift_name: str
    start_hour: int
    end_hour: int
    hours: int
    cost_cents: int
    is_overtime: bool
    overtime_hours: int = 0


def compute_schedule_details(inp: OptimizationInput, raw: List[RawAssignment]) -> dict:
    emp_by_id = {e.id: e for e in inp.employees}
    shift_by_id = {s.id: s for s in inp.shifts}
    errors: List[str] = []

    # 1. one shift per employee per day (rules out overlaps)
    seen = set()
    for a in raw:
        key = (a.employee_id, a.date)
        if key in seen:
            errors.append(f"Employee {a.employee_id} has more than one shift on {a.date}")
        seen.add(key)

    # 2. availability, required skill, max daily hours
    for a in raw:
        emp = emp_by_id[a.employee_id]
        sh = shift_by_id[a.shift_id]
        if not emp.has_required_skill:
            errors.append(f"Employee {a.employee_id} lacks the required skill but was scheduled")
        if sh.duration_hours > emp.max_daily_hours:
            errors.append(f"Employee {a.employee_id} shift on {a.date} exceeds max daily hours")
        if not emp.is_available_for(a.date.weekday(), sh):
            errors.append(f"Employee {a.employee_id} scheduled outside stated availability on {a.date}")

    # 3. weekly hours + chronological overtime attribution, recomputed independently
    dates_sorted = sorted(inp.dates)
    week_index = {d: i // 7 for i, d in enumerate(dates_sorted)}
    by_emp: Dict[int, List[RawAssignment]] = {}
    for a in raw:
        by_emp.setdefault(a.employee_id, []).append(a)

    details: List[AssignmentDetail] = []
    for eid, assignments in by_emp.items():
        emp = emp_by_id[eid]
        assignments_sorted = sorted(assignments, key=lambda a: a.date)
        running_by_week: Dict[int, int] = {}
        for a in assignments_sorted:
            sh = shift_by_id[a.shift_id]
            wi = week_index[a.date]
            hours_before = running_by_week.get(wi, 0)
            hours_after = hours_before + sh.duration_hours
            running_by_week[wi] = hours_after

            if hours_after > emp.max_weekly_hours + 1e-9:
                errors.append(f"Employee {eid} exceeds max weekly hours in week {wi}")

            threshold = inp.overtime_threshold_hours_per_week
            if hours_after <= threshold:
                normal_hours, ot_hours = sh.duration_hours, 0
            elif hours_before >= threshold:
                normal_hours, ot_hours = 0, sh.duration_hours
            else:
                normal_hours = threshold - hours_before
                ot_hours = sh.duration_hours - normal_hours

            cost = normal_hours * emp.hourly_cost_cents + int(
                round(ot_hours * emp.hourly_cost_cents * inp.overtime_multiplier)
            )
            details.append(AssignmentDetail(
                employee_id=eid, employee_name=emp.name, date=a.date,
                shift_id=sh.id, shift_name=sh.name, start_hour=sh.start_hour, end_hour=sh.end_hour,
                hours=sh.duration_hours, cost_cents=cost, is_overtime=ot_hours > 0, overtime_hours=ot_hours,
            ))

    total_cost_cents = sum(d.cost_cents for d in details)
    total_overtime_shifts = sum(1 for d in details if d.is_overtime)
    total_overtime_hours = sum(d.overtime_hours for d in details)

    # 4. coverage recomputed independently from raw decisions
    coverage = []
    for day in inp.dates:
        for hour in range(24):
            required = inp.required_headcount.get((day, hour), 0)
            scheduled = sum(
                1 for a in raw
                if a.date == day and shift_by_id[a.shift_id].covers_hour(hour)
            )
            coverage.append({
                "date": day, "hour": hour, "required": required, "scheduled": scheduled,
                "understaffed": max(0, required - scheduled),
                "overstaffed": max(0, scheduled - required),
            })

    covered_hours = [c for c in coverage if c["required"] > 0]
    understaffed_hours = sum(1 for c in covered_hours if c["understaffed"] > 0)
    overstaffed_hours = sum(1 for c in covered_hours if c["overstaffed"] > 0)
    total_required = sum(c["required"] for c in covered_hours)
    avg_coverage_pct = (
        round(100 * sum(min(c["scheduled"], c["required"]) for c in covered_hours) / total_required, 1)
        if covered_hours and total_required > 0 else 100.0
    )

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "assignments": details,
        "total_cost_cents": total_cost_cents,
        "total_overtime_shifts": total_overtime_shifts,
        "total_overtime_hours": total_overtime_hours,
        "coverage": coverage,
        "understaffed_hours": understaffed_hours,
        "overstaffed_hours": overstaffed_hours,
        "avg_coverage_pct": avg_coverage_pct,
        "total_hours_covered": len(covered_hours),
    }


def compute_soft_constraint_warnings(
    emp: EmployeeDef, shift: Optional[ShiftDef], before_summary: dict, after_summary: dict,
) -> List[str]:
    """Non-blocking, informational messages about a proposed/applied change.
    Never prevents a save - purely advisory, per the spec's soft-constraint
    examples ('Employee preference violated.', 'Overtime increased by 2 hours.',
    'Labor cost increased by $85.', 'Coverage improved but overstaffing increased.')."""
    warnings: List[str] = []

    if shift is not None and emp.preferred_shift and shift.name != emp.preferred_shift:
        warnings.append(f"Employee preference violated: prefers {emp.preferred_shift}, assigned {shift.name}.")

    ot_diff = after_summary["overtime_hours"] - before_summary["overtime_hours"]
    if ot_diff > 0:
        warnings.append(f"Overtime increased by {ot_diff} hour{'s' if ot_diff != 1 else ''}.")
    elif ot_diff < 0:
        warnings.append(f"Overtime decreased by {abs(ot_diff)} hour{'s' if abs(ot_diff) != 1 else ''}.")

    cost_diff = round(after_summary["total_labor_cost"] - before_summary["total_labor_cost"], 2)
    if cost_diff > 0:
        warnings.append(f"Labor cost increased by ${cost_diff:,.2f}.")
    elif cost_diff < 0:
        warnings.append(f"Labor cost decreased by ${abs(cost_diff):,.2f}.")

    cov_diff = round(after_summary["avg_coverage_pct"] - before_summary["avg_coverage_pct"], 1)
    over_diff = after_summary["overstaffed_hours"] - before_summary["overstaffed_hours"]
    if cov_diff > 0 and over_diff > 0:
        warnings.append("Coverage improved but overstaffing increased.")

    return warnings
