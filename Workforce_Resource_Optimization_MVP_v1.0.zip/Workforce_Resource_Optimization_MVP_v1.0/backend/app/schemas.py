from datetime import datetime, date
from typing import Optional
from pydantic import BaseModel, ConfigDict


class LocationOut(BaseModel):
    id: int
    name: str
    region: str

    class Config:
        from_attributes = True


class DepartmentOut(BaseModel):
    id: int
    name: str
    default_productivity_per_hour: float

    class Config:
        from_attributes = True


class EmployeeOut(BaseModel):
    id: int
    name: str
    location_id: int
    department_id: int
    employment_type: str
    hourly_cost: float
    max_weekly_hours: float
    max_daily_hours: float
    preferred_shift: Optional[str]
    active: bool

    class Config:
        from_attributes = True


class DemandPointOut(BaseModel):
    timestamp: datetime
    demand: float
    is_holiday: bool
    is_promotion: bool

    class Config:
        from_attributes = True


class GenerateDataRequest(BaseModel):
    days_of_history: int = 90
    num_locations: int = 2
    num_departments: int = 3
    employees_per_location_dept: int = 5
    seed: Optional[int] = 42


class GenerateDataResponse(BaseModel):
    locations_created: int
    departments_created: int
    employees_created: int
    demand_rows_created: int
    date_range_start: datetime
    date_range_end: datetime


class ForecastGenerateRequest(BaseModel):
    location_id: int
    department_id: int
    horizon_days: int = 7


class ModelComparisonEntry(BaseModel):
    model_config = ConfigDict(protected_namespaces=())
    model_name: str
    wape: Optional[float] = None
    mae: Optional[float] = None
    rmse: Optional[float] = None
    bias: Optional[float] = None
    rank: Optional[int] = None
    is_best: bool
    folds_evaluated: int


class ForecastPointOut(BaseModel):
    model_config = ConfigDict(protected_namespaces=())
    timestamp: datetime
    model_name: str
    predicted_demand: float
    is_best_model: bool


class ForecastResultResponse(BaseModel):
    location_id: int
    department_id: int
    horizon_days: int
    best_model: Optional[str]
    folds_evaluated: int
    model_comparison: list[ModelComparisonEntry]
    forecast_points: list[ForecastPointOut]
    generated_at: datetime


class WorkforceRequirementRequest(BaseModel):
    location_id: int
    department_id: int
    productivity_per_hour: Optional[float] = None  # defaults to department's default if omitted
    absence_pct: float = 0.05
    breaks_pct: float = 0.05
    training_pct: float = 0.03
    other_pct: float = 0.0


class WorkforceRequirementPoint(BaseModel):
    timestamp: datetime
    forecast_demand: float
    productivity_per_hour: float
    shrinkage_pct: float
    base_headcount: int
    required_headcount: int


class WorkforceRequirementSummary(BaseModel):
    peak_required_headcount: int
    avg_required_headcount: float
    total_labor_hours: int
    hours_covered: int


class ShrinkageBreakdown(BaseModel):
    absence_pct: float
    breaks_pct: float
    training_pct: float
    other_pct: float


class WorkforceRequirementResponse(BaseModel):
    location_id: int
    department_id: int
    productivity_per_hour: float
    shrinkage_pct: float
    shrinkage_breakdown: Optional[ShrinkageBreakdown] = None
    summary: WorkforceRequirementSummary
    points: list[WorkforceRequirementPoint]
    generated_at: datetime


class OptimizeRequest(BaseModel):
    location_id: int
    department_id: int
    overtime_threshold_hours_per_week: int = 32
    overtime_multiplier: float = 1.5


class ScheduleAssignmentOut(BaseModel):
    employee_id: int
    employee_name: str
    date: date
    shift_id: int
    shift_name: str
    start_hour: int
    end_hour: int
    hours: int
    cost: float
    is_overtime: bool


class CoveragePointOut(BaseModel):
    date: date
    hour: int
    required: int
    scheduled: int
    understaffed: int
    overstaffed: int


class ScheduleSummary(BaseModel):
    total_labor_cost: float
    total_shifts: int
    overtime_shifts: int
    overtime_hours: int
    avg_coverage_pct: float
    understaffed_hours: int
    overstaffed_hours: int
    total_hours_covered: int


class ScheduleResponse(BaseModel):
    location_id: int
    department_id: int
    feasible: bool
    status: str
    schedule_status: Optional[str] = None
    infeasibility_reason: Optional[str] = None
    assignments: list[ScheduleAssignmentOut]
    summary: Optional[ScheduleSummary] = None
    coverage: list[CoveragePointOut]
    generated_at: datetime


class ScheduleChangeRequest(BaseModel):
    location_id: int
    department_id: int
    employee_id: int
    date: date
    shift_id: Optional[int] = None  # None means "remove this employee's assignment on this date"
    overtime_threshold_hours_per_week: int = 32
    overtime_multiplier: float = 1.5


class ScheduleChangeResponse(BaseModel):
    valid: bool
    errors: list[str]
    warnings: list[str] = []
    before: Optional[ScheduleSummary] = None
    after: Optional[ScheduleSummary] = None
    has_unsaved_changes: bool = False


class EmployeeAvailabilityOut(BaseModel):
    day_of_week: int
    start_hour: int
    end_hour: int


class EmployeeAssignedShiftOut(BaseModel):
    date: date
    shift_name: str
    start_hour: int
    end_hour: int
    hours: int
    cost: float
    is_overtime: bool


class EmployeeDetailResponse(BaseModel):
    employee_id: int
    name: str
    employment_type: str
    hourly_cost: float
    max_daily_hours: float
    max_weekly_hours: float
    preferred_shift: Optional[str]
    skills: list[str]
    availability: list[EmployeeAvailabilityOut]
    assigned_shifts: list[EmployeeAssignedShiftOut]
    total_hours: int
    total_cost: float
    overtime_shifts: int
    preference_conflicts: int


class ReoptimizePreviewRequest(BaseModel):
    location_id: int
    department_id: int
    overtime_threshold_hours_per_week: int = 32
    overtime_multiplier: float = 1.5


class ReoptimizePreviewResponse(BaseModel):
    feasible: bool
    infeasibility_reason: Optional[str] = None
    current: Optional[ScheduleSummary] = None
    proposed: Optional[ScheduleSummary] = None


class UndoRequest(BaseModel):
    location_id: int
    department_id: int
    overtime_threshold_hours_per_week: int = 32
    overtime_multiplier: float = 1.5


class RevertRequest(BaseModel):
    location_id: int
    department_id: int


class DraftScopeRequest(BaseModel):
    location_id: int
    department_id: int


class StagedChangeOut(BaseModel):
    employee_id: int
    date: str
    old_shift_id: Optional[int]
    new_shift_id: Optional[int]
    staged_at: str


class DraftStatusResponse(BaseModel):
    has_unsaved_changes: bool
    changes: list[StagedChangeOut]
    baseline: Optional[ScheduleSummary] = None
    working: Optional[ScheduleSummary] = None


class ScenarioRunRequest(BaseModel):
    location_id: int
    department_id: int
    demand_delta_pct: float = 0.0
    absenteeism_delta_pct: float = 0.0
    productivity_delta_pct: float = 0.0
    cost_delta_pct: float = 0.0
    name: Optional[str] = None


class ScenarioRunResponse(BaseModel):
    scenario_id: int
    name: str
    inputs: dict
    base: dict
    scenario: dict
    delta: dict
    executive_summary: str
    generated_at: str


class ScenarioListEntry(BaseModel):
    scenario_id: int
    name: str
    created_at: str
    demand_delta_pct: float
    absenteeism_delta_pct: float
    productivity_delta_pct: float
    cost_delta_pct: float
    delta: Optional[dict] = None
    executive_summary: Optional[str] = None


class DashboardSummary(BaseModel):
    total_locations: int
    total_departments: int
    total_employees: int
    total_demand_last_7_days: float
    avg_hourly_demand_last_7_days: float
    peak_hourly_demand_last_7_days: float
    data_days_available: int
    has_forecast: bool
    has_workforce_requirement: bool
    has_schedule: bool
