from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, Query, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from fastapi.requests import Request
import json
import logging
from sqlalchemy.orm import Session

from app.database import get_db, init_db
from app import models, schemas
from app.services import data_generator, dashboard as dashboard_service
from app.services import forecast_service
from app.services import workforce_requirement_service as wrs
from app.services import workforce_requirement as wr
from app.services.forecast_service import InsufficientDataError
from app.services.workforce_requirement import InvalidAssumptionError
from app.services.workforce_requirement_service import NoForecastError
from app.services import optimization_service as opt_service
from app.services.optimization_service import NoRequirementError, NoEmployeesError
from app.services import schedule_editor
from app.services.schedule_editor import EmployeeNotFoundError, ShiftNotFoundError, NothingToUndoError, NoDraftError
from app.services import scenario_engine
from app.services.scenario_engine import NoRequirementError as ScenarioNoRequirementError
from app.services import executive_dashboard
from app.services import data_import
from app.services.data_import import UnsupportedDataTypeError, FileParseError
from app.services import data_export
from app.services.data_export import NothingToExportError

app = FastAPI(
    title="Workforce Demand Forecasting & Resource Optimization API",
    version="0.8.0-phase8",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

logger = logging.getLogger("workforce_optimizer")


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """Never leak a Python traceback to the client. The real exception is
    logged server-side for debugging; the client gets a plain, actionable
    message instead of a stack trace."""
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    return Response(
        content=json.dumps({
            "detail": "Something went wrong processing that request. Please check your inputs and try again."
        }),
        status_code=500,
        media_type="application/json",
    )


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/api/health")
def health_check():
    return {"status": "ok", "phase": 8, "time": datetime.utcnow().isoformat()}


@app.post("/api/data/generate", response_model=schemas.GenerateDataResponse)
def generate_data(req: schemas.GenerateDataRequest, db: Session = Depends(get_db)):
    result = data_generator.generate_all(
        db,
        days_of_history=req.days_of_history,
        num_locations=req.num_locations,
        num_departments=req.num_departments,
        employees_per_location_dept=req.employees_per_location_dept,
        seed=req.seed or 42,
    )
    return result


@app.get("/api/locations", response_model=List[schemas.LocationOut])
def list_locations(db: Session = Depends(get_db)):
    return db.query(models.Location).order_by(models.Location.name).all()


@app.get("/api/departments", response_model=List[schemas.DepartmentOut])
def list_departments(db: Session = Depends(get_db)):
    return db.query(models.Department).order_by(models.Department.name).all()


@app.get("/api/employees", response_model=List[schemas.EmployeeOut])
def list_employees(
    location_id: Optional[int] = None,
    department_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    q = db.query(models.Employee)
    if location_id:
        q = q.filter(models.Employee.location_id == location_id)
    if department_id:
        q = q.filter(models.Employee.department_id == department_id)
    return q.order_by(models.Employee.name).all()


@app.get("/api/demand", response_model=List[schemas.DemandPointOut])
def get_demand(
    location_id: int,
    department_id: int,
    days: int = Query(14, ge=1, le=90),
    db: Session = Depends(get_db),
):
    latest = (
        db.query(models.DemandHistory.timestamp)
        .filter(models.DemandHistory.location_id == location_id)
        .filter(models.DemandHistory.department_id == department_id)
        .order_by(models.DemandHistory.timestamp.desc())
        .first()
    )
    if not latest:
        raise HTTPException(status_code=404, detail="No demand data found. Generate data first.")
    latest_ts = latest[0]
    window_start = latest_ts - timedelta(days=days)

    rows = (
        db.query(models.DemandHistory)
        .filter(models.DemandHistory.location_id == location_id)
        .filter(models.DemandHistory.department_id == department_id)
        .filter(models.DemandHistory.timestamp >= window_start)
        .order_by(models.DemandHistory.timestamp.asc())
        .all()
    )
    return rows


@app.get("/api/dashboard", response_model=schemas.DashboardSummary)
def get_dashboard(db: Session = Depends(get_db)):
    return dashboard_service.get_summary(db)


@app.post("/api/forecast", response_model=schemas.ForecastResultResponse)
def generate_forecast(req: schemas.ForecastGenerateRequest, db: Session = Depends(get_db)):
    if req.horizon_days not in (7, 14):
        raise HTTPException(status_code=422, detail="horizon_days must be 7 or 14")
    try:
        return forecast_service.generate_and_store(
            db, req.location_id, req.department_id, req.horizon_days
        )
    except InsufficientDataError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.get("/api/forecast/results", response_model=schemas.ForecastResultResponse)
def get_forecast_results(location_id: int, department_id: int, db: Session = Depends(get_db)):
    result = forecast_service.load_stored(db, location_id, department_id)
    if result is None:
        raise HTTPException(
            status_code=404,
            detail="No forecast generated yet for this location/department. POST /api/forecast first.",
        )
    return result


@app.post("/api/workforce/requirement", response_model=schemas.WorkforceRequirementResponse)
def generate_workforce_requirement(req: schemas.WorkforceRequirementRequest, db: Session = Depends(get_db)):
    shrinkage = wr.ShrinkageInputs(
        absence_pct=req.absence_pct, breaks_pct=req.breaks_pct,
        training_pct=req.training_pct, other_pct=req.other_pct,
    )
    try:
        return wrs.generate_and_store(
            db, req.location_id, req.department_id, req.productivity_per_hour, shrinkage
        )
    except NoForecastError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except InvalidAssumptionError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.get("/api/workforce/requirement/results", response_model=schemas.WorkforceRequirementResponse)
def get_workforce_requirement_results(location_id: int, department_id: int, db: Session = Depends(get_db)):
    result = wrs.load_stored(db, location_id, department_id)
    if result is None:
        raise HTTPException(
            status_code=404,
            detail="No workforce requirement generated yet. POST /api/workforce/requirement first.",
        )
    return result


@app.post("/api/schedule/generate", response_model=schemas.ScheduleResponse)
def generate_schedule(req: schemas.OptimizeRequest, db: Session = Depends(get_db)):
    try:
        return opt_service.generate_and_store(
            db, req.location_id, req.department_id,
            req.overtime_threshold_hours_per_week, req.overtime_multiplier,
        )
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.get("/api/schedule/results", response_model=schemas.ScheduleResponse)
def get_schedule_results(location_id: int, department_id: int, db: Session = Depends(get_db)):
    result = opt_service.load_stored(db, location_id, department_id)
    if result is None:
        raise HTTPException(
            status_code=404,
            detail="No schedule generated yet. POST /api/schedule/generate first.",
        )
    return result


@app.post("/api/schedule/validate-change", response_model=schemas.ScheduleChangeResponse)
def validate_schedule_change(req: schemas.ScheduleChangeRequest, db: Session = Depends(get_db)):
    try:
        return schedule_editor.validate_change(
            db, req.location_id, req.department_id, req.employee_id, req.date, req.shift_id,
            req.overtime_threshold_hours_per_week, req.overtime_multiplier,
        )
    except (EmployeeNotFoundError, ShiftNotFoundError) as e:
        raise HTTPException(status_code=422, detail=str(e))
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.put("/api/schedule/assignment", response_model=schemas.ScheduleChangeResponse)
def update_schedule_assignment(req: schemas.ScheduleChangeRequest, db: Session = Depends(get_db)):
    try:
        result = schedule_editor.commit_change(
            db, req.location_id, req.department_id, req.employee_id, req.date, req.shift_id,
            req.overtime_threshold_hours_per_week, req.overtime_multiplier,
        )
    except (EmployeeNotFoundError, ShiftNotFoundError) as e:
        raise HTTPException(status_code=422, detail=str(e))
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))
    if not result["valid"]:
        raise HTTPException(status_code=422, detail="; ".join(result["errors"]))
    return result


@app.post("/api/schedule/undo", response_model=schemas.ScheduleResponse)
def undo_schedule_change(req: schemas.UndoRequest, db: Session = Depends(get_db)):
    try:
        return schedule_editor.undo_last_change(
            db, req.location_id, req.department_id,
            req.overtime_threshold_hours_per_week, req.overtime_multiplier,
        )
    except NothingToUndoError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/api/schedule/revert", response_model=schemas.ScheduleResponse)
def revert_schedule(req: schemas.RevertRequest, db: Session = Depends(get_db)):
    try:
        return opt_service.revert_to_optimized(db, req.location_id, req.department_id)
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/api/schedule/reoptimize-preview", response_model=schemas.ReoptimizePreviewResponse)
def reoptimize_preview(req: schemas.ReoptimizePreviewRequest, db: Session = Depends(get_db)):
    try:
        return schedule_editor.reoptimize_preview(
            db, req.location_id, req.department_id,
            req.overtime_threshold_hours_per_week, req.overtime_multiplier,
        )
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.get("/api/schedule/employee/{employee_id}", response_model=schemas.EmployeeDetailResponse)
def get_employee_detail(
    employee_id: int, location_id: int, department_id: int, db: Session = Depends(get_db)
):
    try:
        return schedule_editor.get_employee_detail(db, location_id, department_id, employee_id)
    except EmployeeNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/api/schedule/stage-change", response_model=schemas.ScheduleChangeResponse)
def stage_schedule_change(req: schemas.ScheduleChangeRequest, db: Session = Depends(get_db)):
    try:
        result = schedule_editor.stage_change(
            db, req.location_id, req.department_id, req.employee_id, req.date, req.shift_id,
            req.overtime_threshold_hours_per_week, req.overtime_multiplier,
        )
    except (EmployeeNotFoundError, ShiftNotFoundError) as e:
        raise HTTPException(status_code=422, detail=str(e))
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))
    if not result["valid"]:
        raise HTTPException(status_code=422, detail="; ".join(result["errors"]))
    return result


@app.get("/api/schedule/draft", response_model=schemas.DraftStatusResponse)
def get_schedule_draft(location_id: int, department_id: int, db: Session = Depends(get_db)):
    return schedule_editor.get_draft_status(db, location_id, department_id)


@app.post("/api/schedule/save-draft", response_model=schemas.ScheduleResponse)
def save_schedule_draft(req: schemas.DraftScopeRequest, db: Session = Depends(get_db)):
    try:
        return schedule_editor.save_draft(db, req.location_id, req.department_id)
    except NoDraftError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except (NoRequirementError, NoEmployeesError) as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/api/schedule/cancel-draft")
def cancel_schedule_draft(req: schemas.DraftScopeRequest, db: Session = Depends(get_db)):
    try:
        return schedule_editor.cancel_draft(db, req.location_id, req.department_id)
    except NoDraftError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/api/scenario/run", response_model=schemas.ScenarioRunResponse)
def run_scenario(req: schemas.ScenarioRunRequest, db: Session = Depends(get_db)):
    try:
        return scenario_engine.run_scenario(
            db, req.location_id, req.department_id,
            req.demand_delta_pct, req.absenteeism_delta_pct,
            req.productivity_delta_pct, req.cost_delta_pct, req.name,
        )
    except ScenarioNoRequirementError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except InvalidAssumptionError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.get("/api/scenario/results", response_model=List[schemas.ScenarioListEntry])
def get_scenario_results(location_id: int, department_id: int, db: Session = Depends(get_db)):
    return scenario_engine.list_scenarios(db, location_id, department_id)


@app.get("/api/executive/dashboard")
def get_executive_dashboard_endpoint(
    location_id: int, department_id: int, horizon_days: int = 7, db: Session = Depends(get_db)
):
    """
    Aggregation-only endpoint: every number returned here is read or derived
    from data Phases 2-6 already computed and persisted. No response_model
    is declared because the payload's shape is intentionally
    availability-flagged per-section (each section says {"available": bool,
    ...}) rather than force-fitting partial/missing data into a rigid schema.
    """
    location = db.query(models.Location).filter(models.Location.id == location_id).first()
    department = db.query(models.Department).filter(models.Department.id == department_id).first()
    if location is None or department is None:
        raise HTTPException(status_code=404, detail="Location or department not found.")
    return executive_dashboard.get_executive_dashboard(db, location_id, department_id, horizon_days)


@app.post("/api/data/import/preview")
async def preview_data_import(
    data_type: str = Form(...),
    mapping_json: Optional[str] = Form(None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Parses and validates the uploaded file WITHOUT writing anything to
    the database, so the user can review the validation report and confirm
    (or adjust) the column mapping before committing."""
    content = await file.read()
    mapping_override = json.loads(mapping_json) if mapping_json else None
    try:
        return data_import.preview_import(data_type, file.filename, content, db, mapping_override)
    except UnsupportedDataTypeError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except FileParseError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/api/data/import/commit")
async def commit_data_import(
    data_type: str = Form(...),
    mapping_json: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Re-validates (never trusts a stale preview) and only then writes rows."""
    content = await file.read()
    mapping = json.loads(mapping_json)
    try:
        return data_import.commit_import(data_type, file.filename, content, mapping, db)
    except UnsupportedDataTypeError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except FileParseError as e:
        raise HTTPException(status_code=422, detail=str(e))


def _csv_response(content: bytes, filename: str) -> Response:
    return Response(
        content=content, media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/export/forecast")
def export_forecast_endpoint(location_id: int, department_id: int, db: Session = Depends(get_db)):
    try:
        content = data_export.export_forecast(db, location_id, department_id)
    except NothingToExportError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return _csv_response(content, "forecast.csv")


@app.get("/api/export/requirement")
def export_requirement_endpoint(location_id: int, department_id: int, db: Session = Depends(get_db)):
    try:
        content = data_export.export_requirement(db, location_id, department_id)
    except NothingToExportError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return _csv_response(content, "workforce_requirement.csv")


@app.get("/api/export/schedule")
def export_schedule_endpoint(location_id: int, department_id: int, db: Session = Depends(get_db)):
    try:
        content = data_export.export_schedule(db, location_id, department_id)
    except NothingToExportError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return _csv_response(content, "schedule.csv")


@app.get("/api/export/scenario/{scenario_id}")
def export_scenario_endpoint(scenario_id: int, db: Session = Depends(get_db)):
    try:
        content = data_export.export_scenario(db, scenario_id)
    except NothingToExportError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return _csv_response(content, f"scenario_{scenario_id}.csv")


@app.get("/api/export/executive-summary")
def export_executive_summary_endpoint(
    location_id: int, department_id: int, horizon_days: int = 7, db: Session = Depends(get_db)
):
    content = data_export.export_executive_summary(db, location_id, department_id, horizon_days)
    return _csv_response(content, "executive_summary.csv")
