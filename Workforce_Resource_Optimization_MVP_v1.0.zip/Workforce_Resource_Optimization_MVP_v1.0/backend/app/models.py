"""
ORM models.

Phase 1 populates: Location, Department, Skill, Employee, EmployeeSkill,
EmployeeAvailability, DemandHistory.

Forecast / ShiftTemplate / Schedule / ScheduleAssignment / ActualWorkforce /
Scenario tables are created now (so the schema is stable) but populated
starting Phase 2 (Forecast) and Phase 4 (scheduling).
"""
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, ForeignKey, Boolean, Date, Text
)
from sqlalchemy.orm import relationship
from app.database import Base


class Location(Base):
    __tablename__ = "locations"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    region = Column(String, nullable=False)

    employees = relationship("Employee", back_populates="location")


class Department(Base):
    __tablename__ = "departments"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    # transactions an employee can handle per hour in this department (default productivity)
    default_productivity_per_hour = Column(Float, default=8.0)

    employees = relationship("Employee", back_populates="department")


class Skill(Base):
    __tablename__ = "skills"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)


class Employee(Base):
    __tablename__ = "employees"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    external_id = Column(String, nullable=True, index=True)  # source-system ID from imported data, e.g. "Worker_ID"
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    employment_type = Column(String, default="full_time")  # full_time | part_time
    hourly_cost = Column(Float, nullable=False)
    max_weekly_hours = Column(Float, default=40.0)
    max_daily_hours = Column(Float, default=8.0)
    preferred_shift = Column(String, nullable=True)  # e.g. "morning"
    active = Column(Boolean, default=True)

    location = relationship("Location", back_populates="employees")
    department = relationship("Department", back_populates="employees")
    skills = relationship("EmployeeSkill", back_populates="employee")
    availability = relationship("EmployeeAvailability", back_populates="employee")


class EmployeeSkill(Base):
    __tablename__ = "employee_skills"
    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)

    employee = relationship("Employee", back_populates="skills")
    skill = relationship("Skill")


class EmployeeAvailability(Base):
    __tablename__ = "employee_availability"
    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    day_of_week = Column(Integer, nullable=False)  # 0=Monday ... 6=Sunday
    available_start_hour = Column(Integer, nullable=False)  # 0-23
    available_end_hour = Column(Integer, nullable=False)  # 0-23, exclusive

    employee = relationship("Employee", back_populates="availability")


class DemandHistory(Base):
    __tablename__ = "demand_history"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)  # hourly grain
    demand = Column(Float, nullable=False)  # e.g. transactions/interactions in that hour
    is_holiday = Column(Boolean, default=False)
    is_promotion = Column(Boolean, default=False)


class Forecast(Base):
    __tablename__ = "forecast"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    model_name = Column(String, nullable=False)
    predicted_demand = Column(Float, nullable=False)
    lower_bound = Column(Float, nullable=True)
    upper_bound = Column(Float, nullable=True)
    generated_at = Column(DateTime, nullable=False)
    is_best_model = Column(Boolean, default=False)


class ForecastModelRun(Base):
    """
    One row per model per backtest run - the persisted 'model comparison' table
    (Model | WAPE | MAE | Bias | Rank) so /api/forecast/results can be reloaded
    without recomputing the backtest.
    """
    __tablename__ = "forecast_model_runs"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    model_name = Column(String, nullable=False)
    horizon_days = Column(Integer, nullable=False)
    wape = Column(Float, nullable=True)
    mae = Column(Float, nullable=True)
    rmse = Column(Float, nullable=True)
    bias = Column(Float, nullable=True)
    rank = Column(Integer, nullable=True)
    is_best = Column(Boolean, default=False)
    folds_evaluated = Column(Integer, default=0)
    generated_at = Column(DateTime, nullable=False)


class WorkforceRequirement(Base):
    """
    Hourly required headcount derived from the stored best-model forecast.
    One row per (location, department, timestamp) per generation run -
    regenerating wipes and replaces prior rows for that location/department,
    same pattern as Forecast/ForecastModelRun.
    """
    __tablename__ = "workforce_requirements"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    forecast_demand = Column(Float, nullable=False)
    productivity_per_hour = Column(Float, nullable=False)
    shrinkage_pct = Column(Float, nullable=False)  # total shrinkage as a fraction, e.g. 0.13
    base_headcount = Column(Integer, nullable=False)
    required_headcount = Column(Integer, nullable=False)
    generated_at = Column(DateTime, nullable=False)


class ShiftTemplate(Base):
    __tablename__ = "shift_templates"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    start_hour = Column(Integer, nullable=False)
    end_hour = Column(Integer, nullable=False)


class Schedule(Base):
    __tablename__ = "schedules"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    date = Column(Date, nullable=False)
    created_at = Column(DateTime, nullable=False)
    total_cost = Column(Float, default=0.0)
    status = Column(String, default="draft")  # draft | published

    assignments = relationship("ScheduleAssignment", back_populates="schedule")


class ScheduleAssignment(Base):
    __tablename__ = "schedule_assignments"
    id = Column(Integer, primary_key=True)
    schedule_id = Column(Integer, ForeignKey("schedules.id"), nullable=False)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    shift_template_id = Column(Integer, ForeignKey("shift_templates.id"), nullable=True)
    start_hour = Column(Integer, nullable=False)
    end_hour = Column(Integer, nullable=False)
    cost = Column(Float, nullable=False)
    is_overtime = Column(Boolean, default=False)

    schedule = relationship("Schedule", back_populates="assignments")


class ScheduleOptimizedSnapshot(Base):
    """
    The pristine solver output for a location/department, saved whenever a
    feasible schedule is generated. Lets "Revert to Optimized" restore the
    true OR-Tools result even after manual edits, without re-solving.
    """
    __tablename__ = "schedule_optimized_snapshots"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    assignments_json = Column(Text, nullable=False)  # [[employee_id, "YYYY-MM-DD", shift_id], ...]
    overtime_threshold_hours_per_week = Column(Integer, nullable=False)
    overtime_multiplier = Column(Float, nullable=False)
    created_at = Column(DateTime, nullable=False)


class ScheduleDraft(Base):
    """
    A manager's in-progress batch of unsaved schedule edits for a location/
    department. Edits stage here (validated but not yet committed to
    Schedule/ScheduleAssignment) until "Save Changes" commits the whole
    batch, or "Cancel Changes" discards it. Persisted in SQLite - never held
    only in frontend memory, per spec.
    """
    __tablename__ = "schedule_drafts"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    assignments_json = Column(Text, nullable=False)  # working state: [[employee_id, "YYYY-MM-DD", shift_id], ...]
    changes_json = Column(Text, nullable=False)  # ordered log: [{employee_id, date, old_shift_id, new_shift_id, staged_at}, ...]
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)


class ScheduleUndoBuffer(Base):
    """
    Single-level undo: the full assignment state immediately before the most
    recent manual edit for a location/department. Overwritten on each edit.
    """
    __tablename__ = "schedule_undo_buffers"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    assignments_json = Column(Text, nullable=False)
    updated_at = Column(DateTime, nullable=False)


class ActualWorkforce(Base):
    __tablename__ = "actual_workforce"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    timestamp = Column(DateTime, nullable=False, index=True)
    scheduled_headcount = Column(Integer, default=0)
    actual_headcount = Column(Integer, default=0)


class Scenario(Base):
    __tablename__ = "scenarios"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    location_id = Column(Integer, ForeignKey("locations.id"), nullable=True)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=True)
    demand_delta_pct = Column(Float, default=0.0)
    absenteeism_delta_pct = Column(Float, default=0.0)
    productivity_delta_pct = Column(Float, default=0.0)
    cost_delta_pct = Column(Float, default=0.0)
    created_at = Column(DateTime, nullable=False)
    result_json = Column(Text, nullable=True)
