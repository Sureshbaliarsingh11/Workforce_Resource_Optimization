@echo off
REM One-command startup: sets up and runs both backend and frontend locally.
REM No cloud services, no external databases - everything runs on this machine.

echo == Workforce Optimizer - local startup ==

cd /d "%~dp0backend"

echo [1/5] Setting up Python virtual environment...
if not exist venv (
    python -m venv venv
)
call venv\Scripts\activate.bat

echo [2/5] Installing backend dependencies...
pip install -q -r requirements.txt

echo [3/5] Installing frontend dependencies...
cd /d "%~dp0frontend"
if not exist node_modules (
    call npm install --silent
)

echo [4/5] Starting backend (http://localhost:8877)...
cd /d "%~dp0backend"
call venv\Scripts\activate.bat
start "Workforce Optimizer Backend" cmd /k "uvicorn app.main:app --host 0.0.0.0 --port 8877"
timeout /t 2 /nobreak > nul

echo [5/5] Starting frontend (http://localhost:5173)...
cd /d "%~dp0frontend"
start "Workforce Optimizer Frontend" cmd /k "npm run dev -- --port 5173 --host 0.0.0.0"

echo.
echo Backend:  http://localhost:8877  (docs at /docs)
echo Frontend: http://localhost:5173
echo.
echo Open the frontend, click 'Load Demo Data' on the Dashboard, then explore Forecast and Workforce.
echo To stop: run stop.bat, or close the two opened terminal windows directly.
