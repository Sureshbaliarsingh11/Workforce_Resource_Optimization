@echo off
REM Stops the backend and frontend by finding and killing whatever is
REM listening on their ports. Safe to run even if nothing is running.

echo Stopping Workforce Optimizer...

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8877 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5173 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>&1
)

echo Done. If terminal windows are still open, you can also close them directly.
