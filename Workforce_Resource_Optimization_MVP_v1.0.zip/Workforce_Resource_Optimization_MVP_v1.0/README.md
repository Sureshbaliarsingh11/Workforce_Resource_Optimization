# Workforce Demand Forecasting & Resource Optimization Tool

A tool that helps you predict how busy you'll be, figure out how many people
you need, build an optimal staff schedule automatically, and see the
business impact of it all on one dashboard - running entirely on your own
computer.

**Nothing here is a mockup.** Every number you see - forecast accuracy,
required headcount, labor cost, coverage percentages, savings - is computed
live from real data by real calculations. There are no hardcoded demo
numbers anywhere in the application.

---

## Quick Start

1. Extract the ZIP
2. Double-click `start.bat` (Windows) or run `./start.sh` (Mac/Linux)
3. Open the displayed local application URL — **http://localhost:5173**
4. Click **Load Demo Data**
5. Go to **Forecast** and click **Generate forecast**
6. Go to **Workforce** and click **Calculate requirement**
7. Go to **Schedule** and click **Generate optimized schedule**
8. Explore the **Manager Schedule** — edit a shift, see the impact, save it
9. Go to **Scenarios** and run a What-If Scenario
10. Go to **Dashboard** to view the Executive Dashboard

**To stop:** run `stop.bat` (Windows) or `./stop.sh` (Mac/Linux) — or on
Windows you can also just close the two terminal windows directly.

See `docs/INSTALLATION.md` for detailed setup help, `docs/USER_GUIDE.md` for
a full walkthrough of every screen, and `docs/DEMO_GUIDE.md` for a suggested
demonstration script.

---

## What this application does

1. **Predicts demand** - takes your historical demand data (or the built-in
   sample data) and forecasts what's coming, using three different
   statistical models and automatically picking the most accurate one.
2. **Calculates workforce need** - converts that forecast into "how many
   people do I need, hour by hour," accounting for productivity and
   shrinkage (absences, breaks, training).
3. **Builds an optimal schedule** - runs a real constraint-solving optimizer
   (Google OR-Tools) that assigns actual employees to actual shifts,
   respecting availability, skills, and labor-hour limits, while minimizing
   cost and overtime.
4. **Lets a manager fine-tune it** - edit the generated schedule by hand,
   see the cost/coverage impact of each change before committing, undo
   mistakes, or revert to the optimizer's original schedule.
5. **Answers "what if" questions** - model a demand spike, a productivity
   drop, or a cost increase, and see exactly how it would change your
   staffing needs and labor cost, before it happens.
6. **Summarizes it all for leadership** - one executive dashboard with the
   KPIs that matter, plain-English alerts, and concrete recommendations.

## Key capabilities

- Demand forecasting with model comparison and accuracy scoring (WAPE, bias)
- Workforce requirement calculation with adjustable productivity/shrinkage
- Real constraint-based schedule optimization (not a heuristic guess)
- Manager schedule editor with validation, undo, and revert
- What-if scenario modeling with before/after comparisons
- Executive dashboard with automated alerts and recommendations
- CSV/Excel data import with validation and column mapping
- CSV export of every result (forecast, requirement, schedule, scenarios, KPIs)
- Built-in demo dataset so you can try everything immediately

## System requirements

- **Python 3.10+** and **Node.js 18+** installed on your machine
- Windows, Mac, or Linux
- No internet connection required to *run* the app (only to install
  dependencies the first time)
- No Docker, no database server, no cloud account, no API keys

## How to start

**Windows:** double-click `start.bat`, or run it from a command prompt.

**Mac/Linux:**
```bash
./start.sh
```

The first run will take a minute or two while it sets up a Python
environment and installs dependencies - this only happens once. After that,
two things will be running:

- The application backend at `http://localhost:8877`
- The web interface at `http://localhost:5173`

Open **http://localhost:5173** in your browser.

## How to stop

**Windows:** run `stop.bat`, or close the two terminal windows that opened.
**Mac/Linux:** run `./stop.sh`.

## How to load demo data

On the **Dashboard** or **Data** page, click **Load Demo Data**. This
generates a realistic synthetic dataset - 2 locations, 3 departments, ~30
employees, and 90 days of hourly demand with realistic patterns (busier at
certain hours, quieter on weekends, occasional promotional spikes) - so you
can explore every feature immediately without needing your own data.

**Note:** the demo dataset intentionally uses a small employee pool relative
to peak demand, so a freshly generated schedule will often show real
understaffing. This is deliberate, not a bug - it proves the numbers are
genuinely computed rather than always showing a reassuring green result, and
it's exactly the kind of gap the optimization and what-if scenario features
are built to help you close. See `docs/DEMO_GUIDE.md` for details.

## How to upload real data

Go to the **Data** page:

1. Choose the data type you're uploading (Historical Demand, Employees,
   Employee Availability, Employee Skills, or Productivity Assumptions).
2. Choose your CSV or Excel (`.xlsx`) file and click **Validate**.
3. Review the validation report - it tells you how many rows are valid, and
   lists any warnings or errors (missing values, duplicate IDs, invalid
   dates, negative demand, etc.). Nothing is imported yet at this point.
4. If your file's column names don't match what the app expects, adjust the
   mapping table (e.g. tell it your "Store" column means "location").
5. Click **Import** to actually load the valid rows into the application.

Recommended order when uploading your own data: **Employees** first, then
**Employee Availability** and **Employee Skills** (which reference the
employee IDs you just imported), then **Historical Demand**, then
**Productivity Assumptions** if you want to override the defaults.

You can mix demo and real data, or use **Reset Demo Data** (with a
confirmation prompt, since it deletes everything currently loaded) to start
over with a fresh synthetic dataset at any time.

## How to generate a forecast

Go to **Forecast**, pick a location, department, and horizon (7 or 14 days),
and click **Generate forecast**. The app backtests three models (Seasonal
Naive, Moving Average, Exponential Smoothing) against your actual history
and shows you a ranked comparison table - the best-performing model (lowest
WAPE) is used automatically for the forecast you see charted.

## How to optimize workforce

1. Go to **Workforce Requirement**, set your productivity and shrinkage
   assumptions (or use the department defaults), and click **Calculate
   requirement**. This converts the forecast into "how many people do I need
   each hour."
2. Go to **Schedule** and click **Generate optimized schedule**. This runs
   the real OR-Tools solver against your actual employees, their
   availability, and their skills. If there's genuinely no way to staff the
   requirement (e.g. not enough skilled employees), the app tells you that
   honestly instead of making something up.

## How to edit schedules

On the **Schedule** page, use the shift dropdown next to any employee to
change or remove their shift for the selected day. Each change is validated
immediately (you'll see if it would violate an hour limit or availability)
and shows you the before/after impact on cost, coverage, and overtime before
you commit it. Use **Save Changes** to commit everything you've staged, or
**Cancel Changes** to discard it. **Undo** reverts your last saved edit;
**Revert to Optimized** throws away all manual edits and restores the
solver's original schedule. **Re-optimize** lets you preview a fresh solver
run before deciding whether to replace your current schedule with it.

## How to run scenarios

Go to **Scenarios**, pick a preset (e.g. "Demand +20%") or set your own
combination of demand/absenteeism/productivity/cost changes, and click **Run
scenario**. You'll get a real before/after comparison - required headcount,
labor cost, coverage, overtime - computed by actually re-running the
forecast-to-schedule pipeline with your adjusted numbers, plus a plain-
English summary sentence. Past scenarios are kept in a history list below.

## How to interpret the dashboard

The **Dashboard** (home page) is the executive view. It shows:

- **KPIs** at the top: forecast accuracy, required vs. scheduled headcount,
  coverage, labor cost, overtime, estimated savings
- **Demand outlook**: actual vs. forecast, with an automated insight sentence
- **Workforce capacity**: required vs. scheduled vs. available staff
- **Labor cost**: current cost, overtime cost, cost trend
- **Optimization impact**: what manual schedule edits changed, compared to
  the optimizer's original result - or an honest "Baseline unavailable" if
  there's nothing valid to compare yet
- **Latest scenario**: your most recent what-if result
- **Alerts**: specific, data-driven warnings (e.g. "understaffed by 4
  employees between 14:00-16:00")
- **Recommendations**: concrete suggestions based on the same data

Any section that doesn't have data yet says so plainly, rather than showing
an empty chart or a fabricated number.

## How to export results

On the **Data** page (or the Scenarios page, for individual scenarios),
click any **Export** button to download a CSV of the forecast, workforce
requirement, schedule, a scenario, or the executive KPI summary.

## Troubleshooting

**"No feasible schedule exists"** - there genuinely aren't enough
skilled/available employees to meet the requirement. Check the Workforce
Requirement page to see how many people are needed, and compare against your
employee list.

**A page says "No forecast/requirement/schedule available yet"** - you need
to complete the earlier step first. The natural order is: Data → Forecast →
Workforce Requirement → Schedule → Scenarios. Each page tells you which
earlier step to visit if something's missing.

**The startup script seems stuck on the first run** - the first launch
installs all dependencies (including the OR-Tools solver, which is a larger
package), which can take a couple of minutes depending on your connection.
Subsequent launches are much faster.

**Ports already in use** - the app uses ports 8877 (backend) and 5173
(frontend). If something else on your machine is using those, stop it first
or edit the port numbers in `start.sh`/`start.bat` and `frontend/vite.config.ts`.

**I want to start completely fresh** - stop the app, delete
`backend/data/workforce.db`, and restart. The database recreates itself
automatically.

## Technical architecture

```
start.sh / start.bat   One-command local startup
stop.sh                 Stops both servers
backend/                FastAPI (Python) - all business logic and calculations
  app/
    main.py               API routes
    database.py             SQLite connection
    models.py                 Database schema
    services/                   Forecasting, optimization, scenarios, import/export, etc.
  tests/                  166 automated tests
  data/                   The SQLite database file lives here
frontend/                React + TypeScript - display and interaction only
  src/
    pages/                  One file per screen (Dashboard, Forecast, Schedule, etc.)
    lib/api.ts                Typed client for talking to the backend
docs/
  roadmap.md              Full build history, phase by phase
  DEPENDENCY-AUDIT.md      Complete list of every dependency, required vs. optional
  INSTALLATION.md          Detailed setup instructions and troubleshooting
  USER_GUIDE.md            Full walkthrough of every screen
  ARCHITECTURE.md          Technical architecture in depth
  DEMO_GUIDE.md            Suggested demonstration script
```

For the full technical architecture (data flow diagram, design principles,
why each technology was chosen), see [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

All business calculations (forecasting math, workforce requirement formulas,
the optimizer, scenario logic, dashboard KPIs) live in the Python backend.
The React frontend only displays data and sends user actions to the
backend - it never recalculates business numbers on its own.

## Dependencies

See [`docs/DEPENDENCY-AUDIT.md`](docs/DEPENDENCY-AUDIT.md) for the complete
list, with required-vs-optional clearly marked. In short: everything is a
standard, freely available Python/Node library that installs and runs
locally. No Docker, no cloud services, no external databases, no AI APIs.

## Running the test suite

```bash
cd backend
source venv/bin/activate   # if not already active
pytest tests/ -v
```

166 tests across 10 files covering every phase of the application, from data
generation through forecasting, optimization, scheduling, scenarios, the
executive dashboard, and data import/export.

## Manual setup (if you'd rather not use the startup scripts)

### Backend
```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8877
```
Swagger API docs available at `http://localhost:8877/docs`.

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Project history

See [`docs/roadmap.md`](docs/roadmap.md) for the full phase-by-phase build
history, what's implemented in each phase, and known limitations.
